var Is = Object.defineProperty;
var Nt = (t) => {
  throw TypeError(t);
};
var vs = (t, e, s) => e in t ? Is(t, e, { enumerable: !0, configurable: !0, writable: !0, value: s }) : t[e] = s;
var ct = (t, e, s) => vs(t, typeof e != "symbol" ? e + "" : e, s), ut = (t, e, s) => e.has(t) || Nt("Cannot " + s);
var a = (t, e, s) => (ut(t, e, "read from private field"), s ? s.call(t) : e.get(t)), f = (t, e, s) => e.has(t) ? Nt("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, s), h = (t, e, s, n) => (ut(t, e, "write to private field"), n ? n.call(t, s) : e.set(t, s), s), g = (t, e, s) => (ut(t, e, "access private method"), s);
import { RequestSpecRaw as $s } from "caido:utils";
import { Buffer as v } from "buffer";
import { createHash as et } from "crypto";
import { createServer as qs } from "net";
import { fetch as Ns } from "caido:http";
const fe = ["MATCHES", "DOES_NOT_MATCH", "EQUALS", "NOT_EQUALS"], Ms = {
  FILE_EXTENSION: fe,
  HTTP_METHOD: fe,
  URL: [...fe, "IS_IN_TARGET_SCOPE", "IS_NOT_IN_TARGET_SCOPE"],
  CONTENT_TYPE: fe,
  STATUS_CODE: fe,
  HOST: fe,
  REQUEST: ["HAS_PARAMETERS", "HAS_BODY", "DOES_NOT_HAVE_PARAMETERS", "DOES_NOT_HAVE_BODY"]
};
function Ls(t, e) {
  const s = Ms[t];
  return s !== void 0 && s.includes(e);
}
const Us = [
  {
    enabled: !0,
    operator: null,
    matchType: "FILE_EXTENSION",
    relationship: "DOES_NOT_MATCH",
    condition: "woff|woff2|ttf|eot|otf|mp4|webm|ogg|mkv|flv|avi|mov|wmv|m3u8|svg|jpg|jpeg|png|gif|bmp|webp|ico|css|js|pdf|zip|exe|gz|rar|mp3"
  },
  {
    enabled: !0,
    operator: "AND",
    matchType: "HTTP_METHOD",
    relationship: "DOES_NOT_MATCH",
    condition: "OPTIONS|HEAD"
  }
], ks = {
  serverUrl: "http://127.0.0.1:9002",
  apiKey: "",
  customModules: "",
  scanTimeout: "",
  proxyInScopeOnly: !0,
  snapshotAutoEnabled: !1,
  snapshotIntervalMinutes: 5,
  snapshotInScopeOnly: !1,
  // On by default so `--burp-bridge-url` / `--caido-bridge-url` work as soon as
  // the plugin is installed. The listener is unauthenticated, so it stays bound
  // to loopback only and still validates Host/Origin on every request; turn it
  // off in the Bridge tab if you would rather opt in per session.
  bridgeEnabled: !0,
  bridgeListenUrl: "http://127.0.0.1:9009",
  bridgeInScopeOnly: !1
};
function Ps(t) {
  switch ((t ?? "").toLowerCase()) {
    case "critical":
      return "CRITICAL";
    case "high":
      return "HIGH";
    case "medium":
    case "med":
      return "MEDIUM";
    case "low":
      return "LOW";
    case "suspect":
      return "SUSPECT";
    default:
      return "INFO";
  }
}
const Mt = 2e3, yt = 30, xs = "vigolium-burp-bridge", Rt = "vigolium-caido-bridge", Ds = "X-Vigolium-Source", Hs = "caido", Fs = "bridge-status", Gs = "snapshot-status", Vs = "request-stats", Ys = "log";
function B(t) {
  return t instanceof Error ? t.message : String(t);
}
const ss = "https://docs.vigolium.com/getting-started/caido-plugin";
function Ks(t, e) {
  return `Cannot reach the Vigolium server at ${t} (${e}). Start it with \`vigolium server -A\` and try again. Setup guide: ${ss}`;
}
const At = `No Vigolium server URL is configured. Set it under Vigolium → Settings. Setup guide: ${ss}`;
function Ce(t) {
  return v.from(t.buffer, t.byteOffset, t.byteLength);
}
function O(t) {
  return Ce(t).toString("base64");
}
function _t(t) {
  return new Uint8Array(v.from(t, "base64"));
}
function Xs(t, e) {
  const s = t.trim();
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(s) || s.length % 4 !== 0)
    throw new Error(`${e} is not valid base64`);
  return _t(s);
}
function ze(t) {
  return et("sha256").update(Ce(t)).digest("hex");
}
function pe(t, e) {
  const s = e !== void 0 ? t.subarray(0, e) : t;
  return Ce(s).toString("latin1");
}
function Lt(t) {
  return new Uint8Array(v.from(t, "latin1"));
}
function Ut(t) {
  return new Uint8Array(v.from(t, "utf8"));
}
const zs = 4 * 1024 * 1024, Qs = 4 / 3, Js = 256 * 1024, St = Math.floor(
  (zs - Js) / Qs
), ns = 500;
function kt(t) {
  return t >= 1024 * 1024 ? `${(t / (1024 * 1024)).toFixed(1)} MB` : `${Math.round(t / 1024)} KB`;
}
function Bt(t) {
  return t >= 1024 * 1024 ? `${Math.floor(t / (1024 * 1024))} MiB` : `${Math.floor(t / 1024)} KiB`;
}
function rs(t) {
  const e = pe(t, 8192), s = e.search(/\r?\n/), r = (s >= 0 ? e.slice(0, s) : e).split(" "), o = (r[0] ?? "GET").trim() || "GET", i = (r[1] ?? "/").trim() || "/", c = i.indexOf("?");
  return c < 0 ? { method: o, path: i, query: "" } : {
    method: o,
    path: i.slice(0, c),
    query: i.slice(c + 1)
  };
}
function Ws(t) {
  const e = pe(t, 256), s = /^HTTP\/\d(?:\.\d)?\s+(\d{3})/.exec(e);
  return s != null && s[1] ? Number(s[1]) : 0;
}
function Zs(t) {
  const s = pe(t, 8192).split(/\r?\n\r?\n/, 1)[0] ?? "", n = /^host:[ \t]*(\S+)[ \t]*$/im.exec(s);
  return (n == null ? void 0 : n[1]) ?? "";
}
function js(t, e) {
  const { path: s, query: n } = rs(t), r = n ? `${s}?${n}` : s;
  if (/^https?:\/\//i.test(s)) return r;
  const o = en(e), i = Zs(t);
  if (!i) {
    if (!o) throw new Error("Cannot tell where this request was sent: no Host header");
    return `${o.origin}${r}`;
  }
  return `${i.endsWith(":80") ? "http" : i.endsWith(":443") ? "https" : (o == null ? void 0 : o.protocol.replace(":", "")) ?? "https"}://${i}${r}`;
}
function en(t) {
  try {
    const e = new URL(t);
    return e.protocol === "http:" || e.protocol === "https:" ? e : void 0;
  } catch {
    return;
  }
}
function tn(t) {
  const e = new URL(t), s = e.protocol === "https:", n = e.port ? Number(e.port) : s ? 443 : 80;
  return { host: e.hostname, port: n, isTls: s };
}
function sn(t) {
  let e;
  try {
    e = new URL(t);
  } catch {
    throw new Error("url must be an absolute http or https URL");
  }
  if (e.protocol !== "http:" && e.protocol !== "https:" || !e.hostname)
    throw new Error("url must be an absolute http or https URL");
  return t;
}
function u(t, e, s = "") {
  const n = t[e];
  return typeof n == "string" ? n : s;
}
function b(t, e, s) {
  const n = t[e];
  return typeof n == "number" && Number.isFinite(n) ? n : s;
}
function Ne(t, e, s) {
  const n = t[e];
  return typeof n == "number" && Number.isFinite(n) ? Math.trunc(n) : s;
}
function ye(t, e, s = !1) {
  const n = t[e];
  return typeof n == "boolean" ? n : s;
}
function ee(t, e) {
  const s = t[e];
  return Array.isArray(s) ? s.filter((n) => typeof n == "string") : [];
}
function Pt(t) {
  const e = (t ?? "").trim();
  let s;
  try {
    s = new URL(e);
  } catch {
    throw new Error("Bridge listener URL must be a valid http:// URL");
  }
  if (s.protocol !== "http:")
    throw new Error("Bridge listener URL must use http://");
  if (s.pathname && s.pathname !== "/")
    throw new Error("Bridge listener URL must not include a path");
  if (s.search || s.hash || s.username || s.password)
    throw new Error("Bridge listener URL must not include credentials, a query, or a fragment");
  const n = Number(s.port);
  if (!Number.isInteger(n) || n < 1 || n > 65535)
    throw new Error("Bridge listener URL must include a host and port");
  const r = Ot(s.hostname).toLowerCase(), o = nn(r);
  if (o === void 0)
    throw new Error("Bridge listener must bind to a loopback address");
  return { host: o, port: n, configuredHost: r };
}
function nn(t) {
  if (t === "localhost") return "127.0.0.1";
  if (t === "::1" || t === "0:0:0:0:0:0:0:1") return "::1";
  if (/^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(t) && t.split(".").map(Number).every((s) => s >= 0 && s <= 255))
    return t;
}
function Ot(t) {
  return t.startsWith("[") && t.endsWith("]") ? t.slice(1, -1) : t;
}
function _e(t) {
  let e = (t ?? "").trim().toLowerCase();
  for (e = Ot(e); e.endsWith("."); ) e = e.slice(0, -1);
  return e;
}
function rn(t, e) {
  if (!t || !t.trim() || t.includes(",")) return;
  let s;
  try {
    s = new URL(`http://${t.trim()}`);
  } catch {
    return;
  }
  if (!s.hostname || s.username || s.password || s.pathname && s.pathname !== "/" || s.search || s.hash || t.includes("/")) return;
  const n = s.port ? Number(s.port) : e;
  if (Number.isInteger(n))
    return { host: Ot(s.hostname), port: n };
}
var N;
class on {
  constructor(e) {
    f(this, N);
    h(this, N, e);
  }
  acceptsHost(e) {
    const s = rn(e, 80);
    if (!s || s.port !== a(this, N).port) return !1;
    const n = _e(s.host);
    return n === _e(a(this, N).configuredHost) || n === _e(a(this, N).host);
  }
  acceptsOrigin(e) {
    if (!e || !e.trim()) return !0;
    let s;
    try {
      s = new URL(e.trim());
    } catch {
      return !1;
    }
    if (s.protocol !== "http:" || !s.hostname || s.username || s.password || s.pathname && s.pathname !== "/" || s.search || s.hash) return !1;
    const n = s.port ? Number(s.port) : 80;
    return this.acceptsHost(`${s.hostname}:${n}`);
  }
  displayUrl() {
    return `http://${a(this, N).host.includes(":") ? `[${a(this, N).host}]` : a(this, N).host}:${a(this, N).port}`;
  }
}
N = new WeakMap();
function an(t, e) {
  const s = u(t, "location") === "proxy_history" ? "proxy_history" : "sitemap", n = /* @__PURE__ */ new Set();
  for (const d of lt(t, "methods")) n.add(d.toUpperCase());
  const r = /* @__PURE__ */ new Set();
  if (Array.isArray(t.status))
    for (const d of t.status) {
      const m = Number(d);
      Number.isInteger(m) && r.add(m);
    }
  const o = lt(t, "search_terms");
  ve(o, u(t, "text")), ve(o, u(t, "header")), ve(o, u(t, "body"));
  const i = lt(t, "exclude_terms");
  ve(i, u(t, "exclude_header")), ve(i, u(t, "exclude_body"));
  const c = Ne(t, "limit", 50), l = Ne(t, "offset", 0);
  return {
    location: s,
    host: u(t, "host"),
    methods: n,
    path: u(t, "path"),
    statuses: r,
    mimeType: u(t, "mime_type"),
    searchTerms: o,
    excludeTerms: i,
    fromTime: Ht(u(t, "from")),
    toTime: Ht(u(t, "to")),
    inScopeOnly: e || t.in_scope_only === !0,
    limit: Math.max(0, Math.min(c, 5e3)),
    offset: Math.max(0, l),
    sortBy: u(t, "sort"),
    sortAscending: u(t, "order").toLowerCase() === "asc"
  };
}
function cn(t) {
  return {
    criteria: t,
    host: hn(t.host),
    // Burp treated `*` as decoration around a substring rather than a real glob.
    path: t.path.replace(/\*/g, "").toLowerCase(),
    mimeType: t.mimeType.toLowerCase(),
    searchTerms: t.searchTerms.filter(Boolean).map((e) => e.toLowerCase()),
    excludeTerms: t.excludeTerms.filter(Boolean).map((e) => e.toLowerCase())
  };
}
function un(t, e, s) {
  const { criteria: n } = t;
  if (n.inScopeOnly && !s || n.fromTime !== void 0 && e.createdAt < n.fromTime || n.toTime !== void 0 && e.createdAt > n.toTime || t.host && !t.host(e.request.getHost()) || n.methods.size > 0 && !n.methods.has(e.request.getMethod().toUpperCase()) || t.path && !e.request.getPath().toLowerCase().includes(t.path) || n.statuses.size > 0 && (!e.response || !n.statuses.has(e.response.getCode())) || t.mimeType && (!e.response || !os(e.response, "content-type").toLowerCase().includes(t.mimeType)))
    return !1;
  for (const r of t.searchTerms)
    if (!xt(e, r)) return !1;
  for (const r of t.excludeTerms)
    if (xt(e, r)) return !1;
  return !0;
}
function xt(t, e) {
  const s = ln(t);
  return s.request.includes(e) || s.response.includes(e);
}
function ln(t) {
  return t.text || (t.text = {
    request: pe(t.request.getRaw().toBytes()).toLowerCase(),
    response: t.response ? pe(t.response.getRaw().toBytes()).toLowerCase() : ""
  }), t.text;
}
function os(t, e) {
  const s = t.getHeader(e);
  return (s == null ? void 0 : s[0]) ?? "";
}
const dn = /[\\.[\]{}()+\-^$|?]/g;
function hn(t) {
  const e = _e(t);
  if (!e) return;
  if (!e.includes("*")) return (r) => _e(r) === e;
  const s = e.split("*").map((r) => r.replace(dn, "\\$&")).join(".*"), n = new RegExp(`^${s}$`);
  return (r) => n.test(_e(r));
}
function pn(t, e, s) {
  var r, o;
  let n;
  switch (t.sortBy) {
    case "method":
      n = Je(e.request.getMethod(), s.request.getMethod());
      break;
    case "path":
      n = Je(e.request.getPath(), s.request.getPath());
      break;
    case "status":
    case "status_code":
      n = (((r = e.response) == null ? void 0 : r.getCode()) ?? 0) - (((o = s.response) == null ? void 0 : o.getCode()) ?? 0);
      break;
    case "url":
      n = Je(e.request.getUrl(), s.request.getUrl());
      break;
    default:
      n = e.createdAt - s.createdAt;
      break;
  }
  return n === 0 && t.sortBy !== "url" && (n = Je(e.request.getUrl(), s.request.getUrl())), t.sortAscending ? n : -n;
}
function Je(t, e) {
  const s = t.toLowerCase(), n = e.toLowerCase();
  return s < n ? -1 : s > n ? 1 : 0;
}
function fn(t) {
  const e = [];
  if (t.location === "proxy_history" && e.push('source:"intercept"'), t.host && !t.host.includes("*") && e.push(`req.host.eq:${Dt(t.host)}`), t.methods.size === 1) {
    const [s] = [...t.methods];
    e.push(`req.method.eq:${Dt(s)}`);
  }
  if (t.statuses.size === 1) {
    const [s] = [...t.statuses];
    e.push(`resp.code.eq:${s}`);
  }
  return e.join(" and ");
}
function Dt(t) {
  return `"${t.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}
function lt(t, e) {
  return ee(t, e).filter((s) => s.trim().length > 0);
}
function ve(t, e) {
  e && e.trim() && t.push(e);
}
function Ht(t) {
  if (!t || !t.trim()) return;
  const e = Date.parse(t);
  return Number.isNaN(e) ? void 0 : e;
}
const gn = 2e4;
async function mn(t, e) {
  const s = fn(e), n = cn(e);
  let r, o = 0, i = !1;
  const c = [];
  let l = s, d = !1;
  for (; ; ) {
    let m;
    try {
      let p = t.requests.query().first(ns);
      l && !d && (p = p.filter(l)), r && (p = p.after(r)), p = e.sortAscending ? p.ascending("req", "created_at") : p.descending("req", "created_at"), m = await p.execute();
    } catch (p) {
      if (!d && l) {
        t.console.warn(
          `[Vigolium] HTTPQL prefilter rejected (${B(p)}); scanning unfiltered`
        ), d = !0, r = void 0, o = 0, c.length = 0;
        continue;
      }
      throw p;
    }
    if (m.items.length === 0) break;
    for (const p of m.items) {
      o += 1;
      const _ = is(p.request, p.response), w = e.inScopeOnly ? t.requests.inScope(p.request) : !0;
      un(n, _, w) && c.push(_);
    }
    if (r = m.pageInfo.endCursor, !m.pageInfo.hasNextPage) break;
    if (o >= gn) {
      i = !0;
      break;
    }
  }
  return c.sort((m, p) => pn(e, m, p)), { candidates: c, truncated: i, scanned: o };
}
function is(t, e) {
  return { request: t, response: e, createdAt: t.getCreatedAt().getTime() };
}
async function as(t, e) {
  const s = await t.requests.get(e);
  if (!(s != null && s.request)) throw new Error("Caido ref expired or unknown; search again");
  return is(s.request, s.response);
}
const yn = `
  mutation VigoliumCreateRequest($input: CreateRequestInput!) {
    createRequest(input: $input) {
      id
      responseId
    }
  }
`, _n = `
  mutation VigoliumCreateSitemapEntries($requestId: ID!) {
    createSitemapEntries(requestId: $requestId) {
      __typename
    }
  }
`;
async function Ct(t, e) {
  var p, _, w;
  const { host: s, port: n, isTls: r } = tn(e.url), { method: o, path: i, query: c } = rs(e.requestBytes), l = {
    input: {
      host: s,
      port: n,
      isTls: r,
      method: o,
      path: i,
      query: c,
      raw: O(e.requestBytes),
      source: "PLUGIN",
      alteration: "NONE",
      ...r ? { sni: s } : {},
      ...e.responseBytes && e.responseBytes.length > 0 ? {
        response: {
          raw: O(e.responseBytes),
          statusCode: Ws(e.responseBytes),
          roundtripTime: Math.max(0, Math.trunc(e.roundtripTimeMs ?? 0)),
          source: "PLUGIN",
          alteration: "NONE"
        }
      } : {}
    }
  }, d = await t.graphql.execute(yn, l);
  if (d.errors && d.errors.length > 0)
    throw new Error(`Caido rejected the request import: ${((p = d.errors[0]) == null ? void 0 : p.message) ?? "unknown"}`);
  const m = (w = (_ = d.data) == null ? void 0 : _.createRequest) == null ? void 0 : w.id;
  if (!m) throw new Error("Caido did not return an id for the imported request");
  return m;
}
async function cs(t, e) {
  var n;
  const s = await t.graphql.execute(_n, { requestId: e });
  if (s.errors && s.errors.length > 0)
    throw new Error(`Caido rejected the sitemap entry: ${((n = s.errors[0]) == null ? void 0 : n.message) ?? "unknown"}`);
}
async function Sn(t, e) {
  var i, c, l;
  const s = e.trim();
  if (!s) return;
  const r = (await t.replay.getCollections()).find((d) => d.getName() === s);
  if (r) return r.getId();
  const o = await t.graphql.execute(
    `mutation VigoliumCreateCollection($input: CreateReplaySessionCollectionInput!) {
       createReplaySessionCollection(input: $input) { collection { id } }
     }`,
    { input: { name: s } }
  );
  if (!(o.errors && o.errors.length > 0))
    return ((l = (c = (i = o.data) == null ? void 0 : i.createReplaySessionCollection) == null ? void 0 : c.collection) == null ? void 0 : l.id) ?? void 0;
}
async function wn(t, e, s) {
  const n = s.trim();
  n && await t.graphql.execute(
    `mutation VigoliumRenameSession($id: ID!, $name: String!) {
       renameReplaySession(id: $id, name: $name) { session { id } }
     }`,
    { id: e, name: n }
  );
}
async function rt(t, e, s, n) {
  const r = await Ct(t, e), o = n === void 0 ? await t.replay.createSession(r) : await t.replay.createSession(r, n);
  return await wn(t, o.getId(), s), o.getId();
}
const En = {
  blocked: !0,
  sent: !1,
  statusCode: 0,
  responseBytes: new Uint8Array(0),
  elapsedMs: void 0,
  error: void 0
};
async function Tn(t, e, s, n) {
  var i;
  const r = new $s(e);
  if (r.setRaw(s), n.enforceInScope && !t.requests.inScope(r.toSpec()))
    return En;
  const o = Date.now();
  try {
    const l = (await t.requests.send(r, {
      timeouts: { global: n.timeoutMs },
      save: n.save
    })).response;
    return {
      blocked: !1,
      sent: !0,
      statusCode: (l == null ? void 0 : l.getCode()) ?? 0,
      responseBytes: l ? l.getRaw().toBytes() : new Uint8Array(0),
      elapsedMs: ((i = l == null ? void 0 : l.getRoundtripTime) == null ? void 0 : i.call(l)) ?? Date.now() - o,
      error: void 0
    };
  } catch (c) {
    return {
      blocked: !1,
      sent: !1,
      statusCode: 0,
      responseBytes: new Uint8Array(0),
      elapsedMs: void 0,
      error: B(c)
    };
  }
}
function ot(t, e, ...s) {
  try {
    t.api.send(e, ...s);
  } catch {
  }
}
const bn = {
  200: "OK",
  400: "Bad Request",
  403: "Forbidden",
  404: "Not Found",
  405: "Method Not Allowed",
  413: "Payload Too Large",
  429: "Too Many Requests",
  500: "Internal Server Error",
  503: "Service Unavailable"
}, Rn = 64 * 1024, us = 4, An = 3e4;
function Bn(t, e) {
  const s = Math.max(0, e - (us - 1));
  for (let n = s; n + 3 < t.length; n++)
    if (t[n] === 13 && t[n + 1] === 10 && t[n + 2] === 13 && t[n + 3] === 10)
      return n;
  return -1;
}
var Se, Ue, ke, we, tt, ls;
class On {
  constructor(e, s, n) {
    f(this, tt);
    f(this, Se);
    f(this, Ue);
    f(this, ke);
    f(this, we);
    h(this, Ue, e), h(this, ke, s), h(this, we, n);
  }
  listen(e, s) {
    return new Promise((n, r) => {
      let o = !1;
      const i = qs((c) => g(this, tt, ls).call(this, c));
      i.on("error", (c) => {
        if (!o) {
          o = !0, r(c);
          return;
        }
        a(this, we).call(this, c.message);
      }), i.listen(s, e, () => {
        o = !0, h(this, Se, i), n();
      });
    });
  }
  close() {
    const e = a(this, Se);
    if (h(this, Se, void 0), !!e)
      try {
        e.close();
      } catch {
      }
  }
}
Se = new WeakMap(), Ue = new WeakMap(), ke = new WeakMap(), we = new WeakMap(), tt = new WeakSet(), ls = function(e) {
  const s = [];
  let n = 0, r = v.alloc(0), o = 0, i = -1, c = 0, l, d = !1;
  const m = setTimeout(() => {
    p({ status: 400, json: { error: "request timed out" } });
  }, An), p = (w) => {
    d || (d = !0, clearTimeout(m), In(e, w));
  };
  e.on("error", () => {
    d = !0, clearTimeout(m);
  });
  const _ = () => s.length === 1 ? s[0] : v.concat(s, n);
  e.on("data", (w) => {
    if (d) return;
    if (s.push(w), n += w.length, i < 0) {
      if (r = _(), i = Bn(r, o), o = r.length, i < 0) {
        n > Rn && p({ status: 400, json: { error: "request headers too large" } });
        return;
      }
      const L = Cn(r.toString("latin1", 0, i));
      if (!L) {
        p({ status: 400, json: { error: "malformed request line" } });
        return;
      }
      l = L;
      const q = a(this, ke).call(this, L.path), Ie = L.headers.get("content-length");
      if (L.method === "POST") {
        if (Ie === void 0) {
          p({ status: 400, json: { error: "content-length is required" } });
          return;
        }
        const Qe = Number(Ie);
        if (!Number.isInteger(Qe) || Qe < 0) {
          p({ status: 400, json: { error: "invalid content-length" } });
          return;
        }
        if (Qe > q) {
          p({ status: 400, json: { error: `request exceeds ${Bt(q)}` } });
          return;
        }
        c = Qe;
      }
    }
    const T = i + us;
    if (n - T < c) return;
    const A = _(), F = {
      method: l.method,
      path: l.path,
      headers: l.headers,
      body: new Uint8Array(A.subarray(T, T + c))
    };
    a(this, Ue).call(this, F).then(p).catch((L) => {
      const q = B(L);
      a(this, we).call(this, `request failed: ${q}`), p({ status: 500, json: { error: q } });
    });
  });
};
function Cn(t) {
  const e = t.split(`\r
`), s = e.shift();
  if (!s) return;
  const n = s.split(" ");
  if (n.length < 3) return;
  const [r, o] = n;
  if (!r || !o) return;
  const i = /* @__PURE__ */ new Map();
  for (const d of e) {
    const m = d.indexOf(":");
    if (m <= 0) continue;
    const p = d.slice(0, m).trim().toLowerCase(), _ = d.slice(m + 1).trim();
    i.has(p) || i.set(p, _);
  }
  const c = o.indexOf("?"), l = c >= 0 ? o.slice(0, c) : o;
  return { method: r.toUpperCase(), path: l, headers: i };
}
function In(t, e) {
  const s = v.from(JSON.stringify(e.json ?? {}), "utf-8"), n = bn[e.status] ?? "Unknown", r = `HTTP/1.1 ${e.status} ${n}\r
Content-Type: application/json; charset=utf-8\r
Content-Length: ${s.length}\r
Cache-Control: no-store\r
X-Content-Type-Options: nosniff\r
Connection: close\r
\r
`;
  try {
    t.write(v.concat([v.from(r, "latin1"), s])), t.end();
  } catch {
  }
}
const vn = 1e4;
var U, Pe, st, ds;
class $n {
  constructor() {
    f(this, st);
    f(this, U, /* @__PURE__ */ new Map());
    f(this, Pe, 0);
  }
  remember(e) {
    const s = g(this, st, ds).call(this);
    for (a(this, U).set(s, e); a(this, U).size > vn; ) {
      const n = a(this, U).keys().next();
      if (n.done) break;
      a(this, U).delete(n.value);
    }
    return s;
  }
  require(e) {
    const s = a(this, U).get(e);
    if (!s) throw new Error("Caido ref expired or unknown; search again");
    return s;
  }
  clear() {
    a(this, U).clear();
  }
  size() {
    return a(this, U).size;
  }
}
U = new WeakMap(), Pe = new WeakMap(), st = new WeakSet(), /**
 * Monotonic, unguessable-enough identifier. These never leave the loopback
 * interface and expire with the listener, so a counter plus randomness is
 * sufficient without pulling in a UUID dependency.
 */
ds = function() {
  h(this, Pe, a(this, Pe) + 1);
  const e = Math.random().toString(36).slice(2, 10);
  return `${a(this, Pe).toString(36)}-${e}`;
};
const Me = 64 * 1024, hs = 4 * 1024 * 1024, dt = hs, Le = 8 * 1024 * 1024, ht = 24 * 1024 * 1024, qn = 1024 * 1024, Nn = 2 * 1024 * 1024, Mn = 3e4, Ln = 12e4, ps = "target is out of Caido scope; disable in-scope-only or add it to the project scope";
class C extends Error {
  constructor(s, n) {
    super(n);
    ct(this, "status");
    this.name = "BridgeError", this.status = s;
  }
}
function Un(t) {
  const e = t.project();
  return {
    status: "ok",
    // Kept as the Burp listener's identifier so existing tooling that sniffs
    // this field keeps working; `implementation` says what actually answered.
    service: xs,
    implementation: Rt,
    read_only: !1,
    loopback_only: !0,
    in_scope_only: t.inScopeOnly(),
    authentication: "none",
    // Derived from the route table rather than listed separately: a capability
    // the listener does not actually serve is a lie the CLI acts on.
    capabilities: Object.values(It).map((s) => s.capability),
    repeater_tabs_per_minute: yt,
    send_respects_in_scope_only: t.inScopeOnly(),
    // Caido scopes traffic per project, so which project is active changes what
    // /search returns. Reported here so CLI output stays explainable.
    project_id: e.id,
    project_name: e.name
  };
}
async function kn(t, e) {
  const s = an(e, t.inScopeOnly()), { candidates: n, truncated: r, scanned: o } = await mn(t.sdk, s), i = n.length, c = Math.min(s.offset, i), l = s.limit === 0 ? i : Math.min(i, c + s.limit), d = n.slice(c, l).map((m) => {
    var w;
    const _ = {
      ref: t.refs.remember({
        requestId: m.request.getId(),
        url: m.request.getUrl()
      }),
      location: s.location,
      method: m.request.getMethod(),
      url: m.request.getUrl(),
      request_hash: ze(m.request.getRaw().toBytes()),
      status: m.response ? m.response.getCode() : 0,
      time: new Date(m.createdAt).toISOString()
    };
    if (m.response) {
      const T = os(m.response, "content-type");
      T && (_.mime_type = ((w = T.split(";")[0]) == null ? void 0 : w.trim()) ?? T);
    }
    return _;
  });
  return r && t.log.warn(
    `[Bridge] Search examined the first ${o} requests and stopped at the scan cap; totals are a floor. Narrow the filter for exact counts.`
  ), {
    total: i,
    // Echoed per reply, not read once off /health, so Vigolium's read path pays
    // no extra round trip to learn that these records came from Caido.
    implementation: Rt,
    offset: c,
    returned: d.length,
    has_more: l < i,
    records: d,
    ...r ? { truncated: !0, scanned: o } : {}
  };
}
async function Pn(t, e) {
  const s = u(e, "ref");
  if (!s) throw new C(400, "ref is required");
  const n = t.refs.require(s), r = await as(t.sdk, n.requestId), o = Ne(e, "max_bytes", 16384), i = Math.max(1024, Math.min(o, hs)), c = r.request.getRaw().toBytes(), l = r.response ? r.response.getRaw().toBytes() : new Uint8Array(0), d = {
    ref: s,
    // Repeated here rather than left to /search: an inspect can be the first
    // and only call of a session (Vigolium's single-record read has no
    // preceding search), and without it that record would fall back to `burp`.
    implementation: Rt,
    url: r.request.getUrl(),
    request_base64: O(c.subarray(0, Math.min(c.length, i))),
    request_truncated: c.length > i
  };
  return i <= Me && (d.request = pe(c, i)), r.response && (i <= Me && (d.response = pe(l, i)), d.response_base64 = O(
    l.subarray(0, Math.min(l.length, i))
  ), d.response_truncated = l.length > i), d;
}
async function xn(t, e) {
  const s = await it(t, e, Le), n = fs(
    qt(e, "http_response_base64"),
    Le,
    "response"
  );
  at(e, "source", 80, "vigolium");
  const r = await Ct(t.sdk, {
    url: s.url,
    requestBytes: s.requestBytes,
    responseBytes: n.length > 0 ? n : null
  });
  return await cs(t.sdk, r), {
    added: 1,
    url: s.url,
    request_hash: ze(s.requestBytes),
    message: "added 1 item to Caido Sitemap"
  };
}
var G;
class Dn {
  constructor() {
    f(this, G, []);
  }
  reserve() {
    const e = Date.now(), s = e - 6e4;
    for (; a(this, G).length > 0 && a(this, G)[0] < s; )
      a(this, G).shift();
    if (a(this, G).length >= yt)
      throw new C(
        429,
        `Replay session limit reached (${yt} per minute); retry shortly`
      );
    a(this, G).push(e);
  }
  clear() {
    h(this, G, []);
  }
}
G = new WeakMap();
async function Hn(t, e) {
  const s = await it(t, e, qn), n = at(e, "tab_name", 64, "vigolium"), r = e.send === !0;
  t.limiter.reserve();
  const o = r ? await vt(t, s, e, !1) : void 0;
  await rt(
    t.sdk,
    {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: o != null && o.responseBytes.length ? o.responseBytes : null,
      roundtripTimeMs: o == null ? void 0 : o.elapsedMs
    },
    n
  );
  const i = {
    sent: 1,
    url: s.url,
    tab_name: n,
    request_hash: ze(s.requestBytes)
  };
  return o && (o.blocked ? (i.executed = !1, i.error = "target is out of Caido scope; not auto-sent") : (i.executed = o.sent, $t(i, o))), i.message = "sent 1 request to Caido Replay", i;
}
async function Fn(t, e) {
  const s = await it(t, e, Le), n = zn(u(e, "http_mode")), r = e.add_to_sitemap === !0, o = await vt(t, s, e, r);
  if (o.blocked) throw new C(403, ps);
  const i = {
    sent: o.sent ? 1 : 0,
    url: s.url,
    request_hash: ze(s.requestBytes),
    http_mode: n
  };
  if ($t(i, o), r && o.sent) {
    const c = await Ct(t.sdk, {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: o.responseBytes.length > 0 ? o.responseBytes : null,
      source: at(e, "source", 80, "vigolium-send"),
      roundtripTimeMs: o.elapsedMs
    });
    await cs(t.sdk, c), i.added_to_sitemap = !0;
  } else
    i.added_to_sitemap = !1;
  return o.sent || t.log.warn(
    `[Bridge] Send via Caido to ${s.url} failed: ${o.error ?? "unknown"}`
  ), i;
}
const Gn = /* @__PURE__ */ new Set([
  "none",
  "red",
  "orange",
  "yellow",
  "green",
  "cyan",
  "blue",
  "pink",
  "magenta",
  "gray"
]);
async function Vn(t, e) {
  const s = await it(t, e, Le);
  let n = qt(e, "http_response_base64");
  const r = e.send === !0, o = u(e, "highlight").trim().toLowerCase();
  if (o && !Gn.has(o))
    throw new C(
      400,
      "highlight must be one of none, red, orange, yellow, green, cyan, blue, pink, magenta, gray"
    );
  let i;
  if (r && n.length === 0) {
    if (i = await vt(t, s, e, !1), i.blocked) throw new C(403, ps);
    i.responseBytes.length > 0 && (n = i.responseBytes);
  }
  fs(n, Le, "response");
  const c = gs(u(e, "notes"), 200), l = at(e, "source", 80, "vigolium"), d = c || (o && o !== "none" ? o : "") || "vigolium", m = await Sn(t.sdk, d);
  await rt(
    t.sdk,
    {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: n.length > 0 ? n : null,
      roundtripTimeMs: i == null ? void 0 : i.elapsedMs
    },
    c || l,
    m
  );
  const p = {
    added: 1,
    url: s.url,
    request_hash: ze(s.requestBytes),
    has_response: n.length > 0,
    collection: d,
    message: `added 1 item to Caido Replay collection "${d}"`
  };
  return c && (p.notes = c), i && $t(p, i), p;
}
const It = {
  "/api/burp-bridge/search": {
    handler: kn,
    bodyLimit: Me,
    capability: "search_burp_items"
  },
  "/api/burp-bridge/inspect": {
    handler: Pn,
    bodyLimit: Me,
    capability: "inspect_burp_item"
  },
  "/api/burp-bridge/sitemap": {
    handler: xn,
    bodyLimit: ht,
    capability: "add_sitemap_item"
  },
  "/api/burp-bridge/repeater": {
    handler: Hn,
    // Every call opens a visible tab, so this one is capped far lower.
    bodyLimit: Nn,
    capability: "send_to_repeater"
  },
  "/api/burp-bridge/send": {
    handler: Fn,
    bodyLimit: ht,
    capability: "send_request"
  },
  "/api/burp-bridge/organizer": {
    handler: Vn,
    bodyLimit: ht,
    capability: "add_organizer_item"
  }
};
function Yn(t) {
  var e;
  return ((e = It[t]) == null ? void 0 : e.bodyLimit) ?? Me;
}
async function it(t, e, s) {
  const n = u(e, "input_mode");
  if (n && n !== "burp_base64")
    throw new C(400, "input_mode must be burp_base64");
  const r = u(e, "ref").trim();
  let o, i;
  if (r) {
    const c = t.refs.require(r), l = await as(t.sdk, c.requestId);
    o = l.request.getUrl(), i = l.request.getRaw().toBytes();
  } else {
    if (o = u(e, "url"), !o.trim()) throw new C(400, "url is required when ref is not supplied");
    i = Qn(e, "http_request_base64");
  }
  try {
    sn(o);
  } catch (c) {
    throw new C(400, B(c));
  }
  if (i.length > s)
    throw new C(400, `request exceeds ${Bt(s)}`);
  return { url: o, requestBytes: i };
}
async function vt(t, e, s, n) {
  return Tn(t.sdk, e.url, e.requestBytes, {
    timeoutMs: Kn(s),
    enforceInScope: t.inScopeOnly(),
    save: n
  });
}
function $t(t, e) {
  if (e.error && (t.error = e.error), e.responseBytes.length > 0) {
    const s = e.responseBytes;
    t.status_code = e.statusCode;
    const n = s.length <= dt ? s : s.subarray(0, dt);
    t.response_base64 = O(n), t.response_length = s.length, t.response_truncated = s.length > dt, e.elapsedMs !== void 0 && (t.elapsed_ms = e.elapsedMs);
  }
}
function Kn(t) {
  const e = Ne(t, "timeout_ms", Mn);
  return Math.max(1, Math.min(e, Ln));
}
const Xn = /* @__PURE__ */ new Set([
  "",
  "auto",
  "http1",
  "http_1",
  "http/1",
  "http/1.1",
  "http2",
  "http_2",
  "http/2",
  "http2_ignore_alpn",
  "http_2_ignore_alpn"
]);
function zn(t) {
  if (!Xn.has(t.toLowerCase()))
    throw new C(400, "http_mode must be one of auto, http1, http2, http2_ignore_alpn");
  return "HTTP_1";
}
function fs(t, e, s) {
  if (t.length > e) throw new C(400, `${s} exceeds ${Bt(e)}`);
  return t;
}
function qt(t, e) {
  const s = u(t, e);
  if (!s.trim()) return new Uint8Array(0);
  try {
    return Xs(s, e);
  } catch (n) {
    throw new C(400, B(n));
  }
}
function Qn(t, e) {
  const s = qt(t, e);
  if (s.length === 0) throw new C(400, `${e} is required`);
  return s;
}
function at(t, e, s, n) {
  return gs(u(t, e), s) || n;
}
function gs(t, e) {
  const s = t.replace(/[\r\n]/g, " ").trim();
  return s.length > e ? s.slice(0, e) : s;
}
var Ee, se, k, ne, xe, Te, re, P, oe, R, je, ms, ys, _s, j;
class Jn {
  constructor(e, s, n) {
    f(this, R);
    f(this, Ee);
    f(this, se);
    f(this, k);
    f(this, ne, new $n());
    f(this, xe, new Dn());
    f(this, Te);
    f(this, re);
    f(this, P);
    f(this, oe, { id: null, name: null });
    h(this, Ee, e), h(this, se, s), h(this, k, n), h(this, P, Ft(s.get().bridgeListenUrl));
  }
  status() {
    return { ...a(this, P) };
  }
  /**
   * Refs point at request IDs, which only mean something inside the project
   * they came from - so switching project invalidates every outstanding ref.
   */
  onProjectChange(e) {
    h(this, oe, e ? { id: e.id, name: e.name } : { id: null, name: null });
    const s = a(this, ne).size();
    a(this, ne).clear(), s > 0 && a(this, k).info(
      `[Bridge] Project changed to ${(e == null ? void 0 : e.name) ?? "none"}; expired ${s} search refs`
    ), g(this, R, j).call(this, { ...a(this, P), ...g(this, R, je).call(this) });
  }
  async restart() {
    g(this, R, _s).call(this);
    const e = a(this, se).get();
    if (!e.bridgeEnabled) {
      g(this, R, j).call(this, Ft(e.bridgeListenUrl));
      return;
    }
    g(this, R, j).call(this, {
      ...a(this, P),
      state: "STARTING",
      message: "Starting bridge listener…",
      listenUrl: e.bridgeListenUrl
    });
    try {
      const s = Pt(e.bridgeListenUrl), n = new on(s), r = new On(
        (i) => g(this, R, ms).call(this, i),
        Yn,
        (i) => a(this, k).error(`[Bridge] ${i}`)
      );
      await r.listen(s.host, s.port), h(this, re, n), h(this, Te, r);
      const o = n.displayUrl();
      g(this, R, j).call(this, {
        state: "LISTENING",
        message: `Bridge listening on ${o}`,
        listenUrl: o,
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        lastRequestAt: null,
        ...g(this, R, je).call(this),
        inProcess: !0
      }), a(this, k).info(`[Bridge] Listening on ${o}`);
    } catch (s) {
      const n = B(s);
      h(this, re, void 0), g(this, R, j).call(this, {
        state: "ERROR",
        message: `Bridge listener failed: ${n}`,
        listenUrl: e.bridgeListenUrl,
        startedAt: null,
        lastRequestAt: null,
        ...g(this, R, je).call(this),
        inProcess: !0
      }), a(this, k).error(`[Bridge] ${n}`);
    }
  }
  /** Probes the configured listener the same way the Vigolium client would. */
  async testConnection() {
    const e = a(this, se).get();
    try {
      const s = Pt(e.bridgeListenUrl), n = s.host.includes(":") ? `[${s.host}]` : s.host, { fetch: r } = await import("caido:http"), o = await r(`http://${n}:${s.port}/health`);
      return o.status !== 200 ? { successful: !1, message: `Bridge connection failed: HTTP ${o.status}` } : (await o.json()).status !== "ok" ? {
        successful: !1,
        message: "Bridge connection failed: unexpected health response"
      } : { successful: !0, message: "Bridge connection successful" };
    } catch (s) {
      return { successful: !1, message: `Bridge connection failed: ${B(s)}` };
    }
  }
}
Ee = new WeakMap(), se = new WeakMap(), k = new WeakMap(), ne = new WeakMap(), xe = new WeakMap(), Te = new WeakMap(), re = new WeakMap(), P = new WeakMap(), oe = new WeakMap(), R = new WeakSet(), je = function() {
  return { projectId: a(this, oe).id, projectName: a(this, oe).name };
}, ms = async function(e) {
  const s = a(this, re);
  if (!s)
    return pt(503, "bridge is not ready");
  if (!s.acceptsHost(e.headers.get("host")))
    return pt(403, "unexpected Host header");
  if (!s.acceptsOrigin(e.headers.get("origin")))
    return pt(403, "unexpected Origin header");
  const n = {
    sdk: a(this, Ee),
    log: a(this, k),
    refs: a(this, ne),
    limiter: a(this, xe),
    inScopeOnly: () => a(this, se).get().bridgeInScopeOnly,
    project: () => a(this, oe)
  };
  if (e.path === "/" || e.path === "/health")
    return e.method !== "GET" ? Z(405, "method not allowed") : Gt(Un(n));
  const r = It[e.path];
  if (!r) return Z(404, "not found");
  if (e.method !== "POST") return Z(405, "method not allowed");
  let o;
  try {
    const i = Ce(e.body).toString("utf-8"), c = i.trim() ? JSON.parse(i) : {};
    if (typeof c != "object" || c === null || Array.isArray(c))
      return Z(400, "request body must be a JSON object");
    o = c;
  } catch {
    return Z(400, "request body is not valid JSON");
  }
  try {
    const i = await r.handler(n, o);
    return g(this, R, ys).call(this), Gt(i);
  } catch (i) {
    if (i instanceof C) return Z(i.status, i.message);
    const c = B(i);
    return a(this, k).error(`[Bridge] Request failed: ${c}`), Z(500, c);
  }
}, ys = function() {
  a(this, P).state === "LISTENING" && g(this, R, j).call(this, { ...a(this, P), lastRequestAt: (/* @__PURE__ */ new Date()).toISOString() });
}, _s = function() {
  var e;
  (e = a(this, Te)) == null || e.close(), h(this, Te, void 0), h(this, re, void 0), a(this, ne).clear(), a(this, xe).clear();
}, j = function(e) {
  h(this, P, e), ot(a(this, Ee), Fs, e);
};
function Ft(t) {
  return {
    state: "DISABLED",
    message: "Bridge disabled",
    listenUrl: t,
    startedAt: null,
    lastRequestAt: null,
    projectId: null,
    projectName: null,
    inProcess: !0
  };
}
function Gt(t) {
  return { status: 200, json: t };
}
function Z(t, e) {
  return { status: t, json: { error: e } };
}
function pt(t, e) {
  return { status: t, json: { error: e }, close: !0 };
}
var be, x, Re, Y;
class Vt {
  constructor() {
    f(this, be, 0);
    f(this, x, 0);
    f(this, Re, 0);
    f(this, Y);
  }
  setOnChange(e) {
    h(this, Y, e);
  }
  /** Queues `count` requests as pending in one step, so a batch fires one event. */
  incrementPending(e = 1) {
    var s;
    h(this, x, a(this, x) + e), (s = a(this, Y)) == null || s.call(this);
  }
  markSent() {
    var e;
    a(this, x) > 0 && h(this, x, a(this, x) - 1), h(this, be, a(this, be) + 1), (e = a(this, Y)) == null || e.call(this);
  }
  markFailed() {
    var e;
    a(this, x) > 0 && h(this, x, a(this, x) - 1), h(this, Re, a(this, Re) + 1), (e = a(this, Y)) == null || e.call(this);
  }
  reset() {
    var e;
    h(this, be, 0), h(this, x, 0), h(this, Re, 0), (e = a(this, Y)) == null || e.call(this);
  }
  snapshot() {
    return { sent: a(this, be), pending: a(this, x), failed: a(this, Re) };
  }
}
be = new WeakMap(), x = new WeakMap(), Re = new WeakMap(), Y = new WeakMap();
var K, V;
class Wn {
  constructor(e) {
    f(this, K);
    f(this, V, []);
    h(this, K, e);
  }
  add(e, s) {
    const n = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: e,
      message: s
    };
    a(this, V).push(n), a(this, V).length > Mt && a(this, V).splice(0, a(this, V).length - Mt);
    const r = `[Vigolium] ${s}`;
    e === "ERROR" ? a(this, K).console.error(r) : e === "WARN" ? a(this, K).console.warn(r) : a(this, K).console.log(r), ot(a(this, K), Ys, n);
  }
  info(e) {
    this.add("INFO", e);
  }
  warn(e) {
    this.add("WARN", e);
  }
  error(e) {
    this.add("ERROR", e);
  }
  entries() {
    return [...a(this, V)];
  }
  clear() {
    h(this, V, []);
  }
}
K = new WeakMap(), V = new WeakMap();
function Zn(t, e) {
  const s = t.filter((r) => r.enabled);
  if (s.length === 0) return !0;
  let n = Kt(s[0], e);
  for (let r = 1; r < s.length; r++) {
    const o = s[r], i = Kt(o, e);
    n = o.operator === "OR" ? n || i : n && i;
  }
  return n;
}
const Yt = /* @__PURE__ */ new Set(["DOES_NOT_MATCH", "NOT_EQUALS"]);
function Kt(t, e) {
  switch (t.matchType) {
    case "FILE_EXTENSION":
      return ge(t.relationship, t.condition, jn(e.path), !0);
    case "HTTP_METHOD":
      return ge(t.relationship, t.condition, e.method, !0);
    case "URL":
      return t.relationship === "IS_IN_TARGET_SCOPE" ? e.inScope : t.relationship === "IS_NOT_IN_TARGET_SCOPE" ? !e.inScope : ge(t.relationship, t.condition, e.url, !1);
    case "CONTENT_TYPE":
      return e.contentType === void 0 ? Yt.has(t.relationship) : ge(t.relationship, t.condition, e.contentType, !0, !0);
    case "STATUS_CODE":
      return e.statusCode === void 0 ? Yt.has(t.relationship) : ge(t.relationship, t.condition, String(e.statusCode), !1);
    case "HOST":
      return ge(t.relationship, t.condition, e.host, !0);
    case "REQUEST":
      return er(t.relationship, e);
    default:
      return !1;
  }
}
function jn(t) {
  const e = t.lastIndexOf(".");
  return e < 0 || e >= t.length - 1 || t.indexOf("/", e) >= 0 ? "" : t.slice(e + 1).toLowerCase();
}
function er(t, e) {
  const s = e.query.length > 0 || e.hasBody || e.hasCookies;
  switch (t) {
    case "HAS_PARAMETERS":
      return s;
    case "DOES_NOT_HAVE_PARAMETERS":
      return !s;
    case "HAS_BODY":
      return e.hasBody;
    case "DOES_NOT_HAVE_BODY":
      return !e.hasBody;
    default:
      return !1;
  }
}
function ge(t, e, s, n, r = !1) {
  switch (t) {
    case "MATCHES":
      return Xt(e, s, n, r);
    case "DOES_NOT_MATCH":
      return !Xt(e, s, n, r);
    case "EQUALS":
      return n ? s.toLowerCase() === e.toLowerCase() : s === e;
    case "NOT_EQUALS":
      return n ? s.toLowerCase() !== e.toLowerCase() : s !== e;
    default:
      return !1;
  }
}
function Xt(t, e, s, n) {
  const r = tr(n ? t : `^(?:${t})$`, s);
  return r ? r.test(e) : !1;
}
const ft = /* @__PURE__ */ new Map();
function tr(t, e) {
  const s = e ? "i" : "", n = `${s}\0${t}`;
  if (ft.has(n)) return ft.get(n);
  let r;
  try {
    r = new RegExp(t, s);
  } catch {
    r = void 0;
  }
  return ft.set(n, r), r;
}
var Ae, ie, De, ae;
class sr {
  constructor(e, s, n, r) {
    f(this, Ae);
    f(this, ie);
    f(this, De);
    f(this, ae);
    h(this, Ae, e), h(this, ie, s), h(this, De, n), h(this, ae, r);
  }
  async handle(e, s, n) {
    const r = a(this, De).get();
    if (r.proxyEnabled)
      try {
        const o = e.requests.inScope(s);
        if (r.proxyInScopeOnly && !o) return;
        if (!a(this, Ae).isConfigured()) {
          a(this, ie).error("[Proxy] Skipped: Vigolium server URL is not configured");
          return;
        }
        if (!Zn(r.proxyFilterRules, nr(s, n, o))) return;
        const i = s.getUrl(), c = O(s.getRaw().toBytes()), l = O(n.getRaw().toBytes());
        a(this, ae).incrementPending();
        try {
          await a(this, Ae).ingest({
            input_mode: "burp_base64",
            url: i,
            http_request_base64: c,
            http_response_base64: l
          }), a(this, ae).markSent();
        } catch (d) {
          a(this, ae).markFailed(), a(this, ie).error(`[Proxy] Request failed: ${B(d)}`);
        }
      } catch (o) {
        a(this, ie).error(`[Proxy] Handler error: ${B(o)}`);
      }
  }
}
Ae = new WeakMap(), ie = new WeakMap(), De = new WeakMap(), ae = new WeakMap();
function nr(t, e, s) {
  return {
    method: t.getMethod(),
    url: t.getUrl(),
    path: t.getPath(),
    query: t.getQuery() ?? "",
    host: t.getHost(),
    get hasBody() {
      var n;
      return (((n = t.getBody()) == null ? void 0 : n.toRaw().length) ?? 0) > 0;
    },
    get hasCookies() {
      return (t.getHeader("Cookie") ?? []).length > 0;
    },
    statusCode: e == null ? void 0 : e.getCode(),
    get contentType() {
      var n;
      return (n = e == null ? void 0 : e.getHeader("Content-Type")) == null ? void 0 : n[0];
    },
    inScope: s
  };
}
const gt = "settings", rr = [
  "serverUrl",
  "apiKey",
  "customModules",
  "scanTimeout",
  "bridgeListenUrl"
], or = ["serverUrl", "bridgeListenUrl"];
var X, D, z, He, Fe, nt, Ss;
class ir {
  constructor(e) {
    f(this, nt);
    f(this, X);
    f(this, D, zt({}));
    /**
     * The object handed to every `get()` caller, rebuilt on write rather than
     * cloned on read. `get()` sits on the proxy interception path, where
     * serialising and reparsing the whole object once per exchange is pure waste.
     */
    f(this, z);
    f(this, He, []);
    f(this, Fe, !1);
    h(this, X, e), h(this, z, mt(a(this, D)));
  }
  async init() {
    const e = await a(this, X).meta.db();
    await e.exec(
      `CREATE TABLE IF NOT EXISTS ${gt} (key TEXT PRIMARY KEY, value TEXT NOT NULL)`
    );
    const n = await (await e.prepare(`SELECT key, value FROM ${gt}`)).all(), r = {};
    for (const o of n)
      try {
        r[o.key] = JSON.parse(o.value);
      } catch {
        a(this, X).console.warn(`[Vigolium] Ignoring unreadable setting "${o.key}"`);
      }
    h(this, D, zt(r)), h(this, z, mt(a(this, D))), h(this, Fe, !0);
  }
  /**
   * The current settings. Callers must treat the result as read-only: it is one
   * shared object rather than a per-call copy.
   */
  get() {
    return a(this, z);
  }
  /** Applies a partial update, persists only the changed keys, and notifies listeners. */
  async update(e) {
    a(this, Fe) || await this.init();
    const s = [];
    for (const o of Object.keys(e)) {
      const i = Es(o, e[o]);
      i !== void 0 && JSON.stringify(i) !== JSON.stringify(a(this, D)[o]) && (a(this, D)[o] = i, s.push(o));
    }
    if (s.length === 0) return this.get();
    h(this, z, mt(a(this, D)));
    const r = await (await a(this, X).meta.db()).prepare(
      `INSERT INTO ${gt} (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    );
    for (const o of s)
      await r.run(o, JSON.stringify(a(this, D)[o]));
    return g(this, nt, Ss).call(this), this.get();
  }
  /** The configured scan modules, split once here rather than at each call site. */
  moduleList() {
    return ws(a(this, z).customModules);
  }
  onChange(e) {
    a(this, He).push(e);
  }
}
X = new WeakMap(), D = new WeakMap(), z = new WeakMap(), He = new WeakMap(), Fe = new WeakMap(), nt = new WeakSet(), Ss = function() {
  const e = this.get();
  for (const s of a(this, He))
    try {
      s(e);
    } catch (n) {
      a(this, X).console.error(`[Vigolium] settings listener failed: ${B(n)}`);
    }
};
function ws(t) {
  return t.split(",").map((e) => e.trim()).filter(Boolean);
}
function wt(t) {
  return t.trim() || null;
}
function mt(t) {
  return JSON.parse(JSON.stringify(t));
}
function Es(t, e) {
  if (typeof e != "string" || !rr.includes(t)) return e;
  const s = e.trim();
  return or.includes(t) ? s.replace(/\/+$/, "") : s;
}
function zt(t) {
  const e = ks;
  return {
    serverUrl: $e(t, "serverUrl", e.serverUrl),
    apiKey: $e(t, "apiKey", e.apiKey),
    customModules: $e(t, "customModules", e.customModules),
    scanTimeout: $e(t, "scanTimeout", e.scanTimeout),
    // Deliberately not restored from disk: forwarding restarts off on every
    // load, matching the Burp extension, so a reload never silently resumes
    // shipping traffic to a scanner.
    proxyEnabled: !1,
    proxyInScopeOnly: ye(t, "proxyInScopeOnly", e.proxyInScopeOnly),
    proxyFilterRules: cr(t.proxyFilterRules),
    snapshotAutoEnabled: ye(t, "snapshotAutoEnabled", e.snapshotAutoEnabled),
    snapshotIntervalMinutes: ar(
      t,
      "snapshotIntervalMinutes",
      e.snapshotIntervalMinutes,
      1,
      1440
    ),
    snapshotInScopeOnly: ye(t, "snapshotInScopeOnly", e.snapshotInScopeOnly),
    bridgeEnabled: ye(t, "bridgeEnabled", e.bridgeEnabled),
    bridgeListenUrl: $e(t, "bridgeListenUrl", e.bridgeListenUrl),
    bridgeInScopeOnly: ye(t, "bridgeInScopeOnly", e.bridgeInScopeOnly)
  };
}
function $e(t, e, s) {
  return Es(e, u(t, e, s));
}
function ar(t, e, s, n, r) {
  return Math.min(r, Math.max(n, Ne(t, e, s)));
}
function cr(t) {
  if (!Array.isArray(t)) return Us.map((s) => ({ ...s }));
  const e = [];
  for (const s of t) {
    if (typeof s != "object" || s === null) continue;
    const n = s;
    typeof n.matchType != "string" || typeof n.relationship != "string" || Ls(n.matchType, n.relationship) && e.push({
      enabled: n.enabled !== !1,
      operator: n.operator === "AND" || n.operator === "OR" ? n.operator : null,
      matchType: n.matchType,
      relationship: n.relationship,
      condition: typeof n.condition == "string" ? n.condition : ""
    });
  }
  return e;
}
const ur = 100, Ts = St;
function lr(t) {
  const e = [];
  let s = 0;
  for (; s < t.length; ) {
    const n = [];
    let r = 0;
    for (; s < t.length && n.length < ur; ) {
      const o = t[s];
      if (n.length > 0 && r + o.rawBytes > Ts) break;
      n.push(o), r += o.rawBytes, s++;
    }
    e.push(n);
  }
  return e;
}
var ce, Q, ue, J, Be, Ge, Oe, le, de, M, bs, Rs, qe;
class dr {
  constructor(e, s, n, r) {
    f(this, M);
    f(this, ce);
    f(this, Q);
    f(this, ue);
    f(this, J);
    f(this, Be, /* @__PURE__ */ new Map());
    f(this, Ge);
    f(this, Oe, !1);
    f(this, le);
    f(this, de, We());
    h(this, ce, e), h(this, Q, s), h(this, ue, n), h(this, J, r);
  }
  status() {
    return { ...a(this, de) };
  }
  start() {
    this.reschedule();
  }
  reschedule() {
    a(this, le) !== void 0 && (clearInterval(a(this, le)), h(this, le, void 0));
    const e = a(this, Q).get();
    if (!e.snapshotAutoEnabled) {
      g(this, M, qe).call(this, {
        ...a(this, de),
        state: "DISABLED",
        message: "Automatic snapshots disabled",
        nextRunAt: null
      });
      return;
    }
    h(this, le, setInterval(
      () => void this.snapshotNow("Auto"),
      e.snapshotIntervalMinutes * 6e4
    )), this.snapshotNow("Auto");
  }
  async snapshotNow(e) {
    if (a(this, Oe))
      return a(this, J).warn("[Sitemap Snapshot] Skipped: another snapshot is running"), this.status();
    h(this, Oe, !0), g(this, M, qe).call(this, {
      ...We(),
      state: "RUNNING",
      message: "Reading the Caido Sitemap…",
      completedAt: a(this, de).completedAt
    });
    try {
      if (!a(this, ue).isConfigured())
        throw new Error(At);
      await g(this, M, Rs).call(this);
      const s = a(this, Q).get(), { pending: n, discovered: r, oversized: o } = await g(this, M, bs).call(this, s.snapshotInScopeOnly);
      let i = 0, c = 0, l = 0, d = o, m = 0;
      const p = fr(), _ = (/* @__PURE__ */ new Date()).toISOString(), w = lr(n);
      for (let A = 0; A < w.length; A++) {
        const F = w[A], L = F.map(pr), q = await a(this, ue).snapshotSitemap({
          snapshot_id: p,
          chunk_index: A,
          final_chunk: A === w.length - 1,
          captured_at: _,
          records: L
        });
        if (m += L.length, i += q.inserted, c += q.updated, l += q.unchanged, d += q.skipped, q.skipped === 0)
          for (const Ie of F)
            a(this, Be).set(Ie.identityFingerprint, Ie.contentFingerprint);
      }
      const T = {
        ...We(),
        state: "SUCCESS",
        message: n.length === 0 && o === 0 ? "Sitemap already synchronized" : "Sitemap snapshot completed",
        discovered: r,
        uploaded: m,
        inserted: i,
        updated: c,
        unchanged: l,
        failed: d,
        completedAt: (/* @__PURE__ */ new Date()).toISOString(),
        nextRunAt: Qt(a(this, Q).get())
      };
      return g(this, M, qe).call(this, T), a(this, J).info(
        `[Sitemap Snapshot:${e}] discovered=${r} uploaded=${m} inserted=${i} updated=${c} unchanged=${l} failed=${d}`
      ), T;
    } catch (s) {
      const n = B(s), r = {
        ...We(),
        state: "FAILED",
        message: `Snapshot failed: ${n}`,
        failed: 1,
        completedAt: (/* @__PURE__ */ new Date()).toISOString(),
        nextRunAt: Qt(a(this, Q).get())
      };
      return g(this, M, qe).call(this, r), a(this, J).error(`[Sitemap Snapshot:${e}] ${n}`), r;
    } finally {
      h(this, Oe, !1);
    }
  }
}
ce = new WeakMap(), Q = new WeakMap(), ue = new WeakMap(), J = new WeakMap(), Be = new WeakMap(), Ge = new WeakMap(), Oe = new WeakMap(), le = new WeakMap(), de = new WeakMap(), M = new WeakSet(), bs = async function(e) {
  const s = [];
  let n = 0, r = 0, o;
  for (; ; ) {
    let i = a(this, ce).requests.query().first(ns).ascending("req", "created_at");
    o && (i = i.after(o));
    const c = await i.execute();
    if (c.items.length === 0) break;
    for (const l of c.items) {
      if (e && !a(this, ce).requests.inScope(l.request)) continue;
      n++;
      const d = hr(l.request, l.response);
      if (!d) {
        r++, a(this, J).warn(`[Sitemap Snapshot] Skipped oversized record: ${l.request.getUrl()}`);
        continue;
      }
      a(this, Be).get(d.identityFingerprint) !== d.contentFingerprint && s.push(d);
    }
    if (o = c.pageInfo.endCursor, !c.pageInfo.hasNextPage) break;
  }
  return { pending: s, discovered: n, oversized: r };
}, Rs = async function() {
  const e = await a(this, ue).destinationIdentity();
  a(this, Ge) !== e && (a(this, Be).clear(), h(this, Ge, e));
}, qe = function(e) {
  h(this, de, e), ot(a(this, ce), Gs, e);
};
function Qt(t) {
  return t.snapshotAutoEnabled ? new Date(Date.now() + t.snapshotIntervalMinutes * 6e4).toISOString() : null;
}
const Jt = v.from([0]);
function hr(t, e) {
  const s = t.getRaw().toBytes(), n = e ? e.getRaw().toBytes() : new Uint8Array(0), r = s.length + n.length;
  if (r > Ts) return;
  const o = t.getUrl(), i = et("sha256").update(v.from(o, "utf-8")).update(Jt).update(Ce(s)).digest("hex"), c = et("sha256").update(v.from(i, "ascii")).update(Jt).update(Ce(n)).digest("hex");
  return { url: o, requestBytes: s, responseBytes: n, identityFingerprint: i, contentFingerprint: c, rawBytes: r };
}
function pr(t) {
  const e = {
    url: t.url,
    request_base64: O(t.requestBytes),
    identity_fingerprint: t.identityFingerprint,
    content_fingerprint: t.contentFingerprint
  };
  return t.responseBytes.length > 0 && (e.response_base64 = O(t.responseBytes)), e;
}
function We() {
  return {
    state: "IDLE",
    message: "Idle",
    discovered: 0,
    uploaded: 0,
    inserted: 0,
    updated: 0,
    unchanged: 0,
    failed: 0,
    completedAt: null,
    nextRunAt: null
  };
}
function fr() {
  const t = () => Math.random().toString(16).slice(2, 10);
  return `${t()}-${t()}-${t()}-${t()}`;
}
const Wt = 2, gr = [1e3, 2e3];
class te extends Error {
  constructor(s, n) {
    super(n);
    ct(this, "statusCode");
    this.name = "VigoliumApiError", this.statusCode = s;
  }
}
var he, S, E;
class mr {
  constructor(e) {
    f(this, S);
    f(this, he);
    h(this, he, e);
  }
  // The settings store canonicalises `serverUrl` and `apiKey` on the way in, so
  // nothing here trims or strips a trailing slash. That is what keeps the
  // identity below hashing exactly the credentials requests are sent with -
  // trimming at some call sites and not others silently split the two apart.
  isConfigured() {
    return a(this, he).call(this).serverUrl.length > 0;
  }
  /** Stable identity of "where records are being sent", for snapshot cache invalidation. */
  async destinationIdentity() {
    const { serverUrl: e, apiKey: s } = a(this, he).call(this);
    return et("sha256").update(`${e}\0${s}`).digest("hex");
  }
  async health() {
    const e = Date.now(), s = await g(this, S, E).call(this, "GET", "/health"), n = I(s);
    return {
      status: u(n, "status", "unknown"),
      version: u(n, "version", "unknown"),
      latencyMs: Date.now() - e
    };
  }
  async ingest(e) {
    await g(this, S, E).call(this, "POST", "/api/ingest-http", e);
  }
  async scan(e) {
    const s = await g(this, S, E).call(this, "POST", "/api/scan-request", e), n = I(s);
    return {
      scanId: u(n, "scan_id", ""),
      message: u(n, "message", "")
    };
  }
  async agentScan(e) {
    return g(this, S, E).call(this, "POST", "/api/agent/run/swarm", e);
  }
  async scanAllRecords(e, s) {
    const n = {};
    e.length > 0 && (n.modules = e), s && s.trim() && (n.timeout = s.trim());
    const r = await g(this, S, E).call(this, "POST", "/api/scan-all-records", n), o = I(r);
    return u(o, "scan_uuid", "") || u(o, "scan_id", "");
  }
  async scanRecords(e, s) {
    const n = { record_uuids: e };
    s.length > 0 && (n.enable_modules = s);
    const r = await g(this, S, E).call(this, "POST", "/api/scan-records", n);
    return u(I(r), "scan_id", "");
  }
  async snapshotSitemap(e) {
    const s = await g(this, S, E).call(this, "POST", "/api/burp/sitemap/snapshot", e), n = I(s);
    return {
      inserted: b(n, "inserted", 0),
      updated: b(n, "updated", 0),
      unchanged: b(n, "unchanged", 0),
      skipped: b(n, "skipped", 0)
    };
  }
  // ---------------------------------------------------------------- Findings
  async findings(e) {
    const s = me("/api/findings", {
      limit: e.limit,
      offset: e.offset,
      domain: e.domain,
      severity: e.severity,
      module_type: e.moduleType,
      finding_source: e.findingSource,
      scan_id: e.scanId,
      repo_name: e.repoName,
      search: e.search,
      sort: e.sort,
      order: e.order
    }), n = I(await g(this, S, E).call(this, "GET", s));
    return Ze(n, Zt, e.limit, e.offset);
  }
  async findingById(e) {
    return Zt(I(await g(this, S, E).call(this, "GET", `/api/findings/${e}`)));
  }
  async deleteFinding(e) {
    await g(this, S, E).call(this, "DELETE", `/api/findings/${e}`);
  }
  // ------------------------------------------------------------ HTTP records
  async httpRecords(e) {
    const s = me("/api/http-records", {
      limit: e.limit,
      offset: e.offset,
      domain: e.domain,
      method: e.method,
      path: e.path,
      status_code: e.statusCode,
      content_type: e.contentType,
      search: e.search,
      source: e.source,
      min_risk: e.minRisk,
      sort: e.sort,
      order: e.order
    }), n = I(await g(this, S, E).call(this, "GET", s));
    return Ze(n, jt, e.limit, e.offset);
  }
  async httpRecordByUuid(e) {
    return jt(I(await g(this, S, E).call(this, "GET", `/api/http-records/${e}`)));
  }
  async deleteHttpRecord(e) {
    await g(this, S, E).call(this, "DELETE", `/api/http-records/${e}`);
  }
  // ------------------------------------------------------------------- Scans
  async scans(e, s) {
    const n = I(await g(this, S, E).call(this, "GET", me("/api/scans", { limit: e, offset: s })));
    return Ze(n, _r, e, s);
  }
  async stopScan(e) {
    await g(this, S, E).call(this, "POST", `/api/scans/${e}/stop`, {});
  }
  async pauseScan(e) {
    await g(this, S, E).call(this, "POST", `/api/scans/${e}/pause`, {});
  }
  async resumeScan(e) {
    await g(this, S, E).call(this, "POST", `/api/scans/${e}/resume`, {});
  }
  async deleteScan(e) {
    await g(this, S, E).call(this, "DELETE", `/api/scans/${e}`);
  }
  async scanLogs(e, s, n, r, o) {
    const i = me(`/api/scans/${e}/logs`, { limit: r, offset: o, level: s, phase: n }), c = I(await g(this, S, E).call(this, "GET", i)), l = As(c.logs).map((d) => ({
      id: b(d, "id", 0),
      scanUuid: u(d, "scan_uuid", ""),
      level: u(d, "level", ""),
      phase: u(d, "phase", ""),
      message: u(d, "message", ""),
      createdAt: u(d, "created_at", "")
    }));
    return { logs: l, total: b(c, "total", l.length) };
  }
  // ---------------------------------------------------------- Agent sessions
  async agentSessions(e, s, n) {
    const r = me("/api/agent/sessions", { limit: s, offset: n, mode: e }), o = I(await g(this, S, E).call(this, "GET", r));
    return Ze(o, Sr, s, n);
  }
  async agentSessionLogs(e) {
    return g(this, S, E).call(this, "GET", me(`/api/agent/sessions/${e}/logs`, { strip: 1 }));
  }
}
he = new WeakMap(), S = new WeakSet(), E = async function(e, s, n) {
  const { serverUrl: r, apiKey: o } = a(this, he).call(this);
  if (!r) throw new te(0, At);
  const i = {
    // Set on every call rather than only on the ingest path: it is advisory
    // (the server allowlists it and falls back to `ingest-server`), and a
    // per-endpoint opt-in is the kind of thing a new dispatch route silently
    // forgets. Without it, traffic pushed from Caido is indistinguishable
    // from traffic pushed by curl.
    [Ds]: Hs
  };
  o && (i.Authorization = `Bearer ${o}`);
  let c = { method: e, headers: i };
  n !== void 0 && (i["Content-Type"] = "application/json", c = { ...c, body: JSON.stringify(n) });
  let l = "unknown error", d = !1;
  for (let m = 0; m <= Wt; m++) {
    m > 0 && await yr(gr[m - 1] ?? 2e3);
    try {
      const p = await Ns(`${r}${s}`, c), _ = await p.text();
      if (p.ok) return _;
      if (p.status >= 400 && p.status < 500)
        throw new te(
          p.status,
          `API error: ${p.status} - ${_.trim()}`
        );
      l = `Server error: ${p.status} - ${_.trim()}`, d = !1;
    } catch (p) {
      if (p instanceof te) throw p;
      l = B(p), d = !0;
    }
  }
  throw new te(
    0,
    d ? Ks(r, l) : `Request failed after ${Wt} retries: ${l}`
  );
};
function yr(t) {
  return new Promise((e) => setTimeout(e, t));
}
function I(t) {
  if (!t.trim()) return {};
  try {
    const e = JSON.parse(t);
    return typeof e == "object" && e !== null ? e : {};
  } catch {
    return {};
  }
}
function As(t) {
  return Array.isArray(t) ? t.filter((e) => typeof e == "object" && e !== null) : [];
}
function Ze(t, e, s, n) {
  return {
    data: As(t.data).map(e),
    total: b(t, "total", 0),
    limit: b(t, "limit", s),
    offset: b(t, "offset", n),
    hasMore: ye(t, "has_more", !1)
  };
}
function Zt(t) {
  return {
    id: b(t, "id", 0),
    httpRecordUuids: ee(t, "http_record_uuids"),
    scanUuid: u(t, "scan_uuid", ""),
    url: u(t, "url", ""),
    hostname: u(t, "hostname", ""),
    moduleId: u(t, "module_id", ""),
    moduleName: u(t, "module_name", ""),
    description: u(t, "description", ""),
    severity: Ps(u(t, "severity", "")),
    confidence: u(t, "confidence", ""),
    tags: ee(t, "tags"),
    matchedAt: ee(t, "matched_at"),
    foundAt: u(t, "found_at", ""),
    request: u(t, "request", ""),
    response: u(t, "response", ""),
    moduleType: u(t, "module_type", ""),
    moduleShort: u(t, "module_short", ""),
    findingSource: u(t, "finding_source", ""),
    sourceFile: u(t, "source_file", ""),
    repoName: u(t, "repo_name", ""),
    extractedResults: ee(t, "extracted_results"),
    additionalEvidence: ee(t, "additional_evidence"),
    findingHash: u(t, "finding_hash", ""),
    createdAt: u(t, "created_at", "")
  };
}
function jt(t) {
  return {
    uuid: u(t, "uuid", ""),
    scheme: u(t, "scheme", ""),
    hostname: u(t, "hostname", ""),
    port: b(t, "port", 0),
    method: u(t, "method", ""),
    path: u(t, "path", ""),
    url: u(t, "url", ""),
    statusCode: b(t, "status_code", 0),
    statusPhrase: u(t, "status_phrase", ""),
    responseHttpVersion: u(t, "response_http_version", ""),
    responseContentLength: b(t, "response_content_length", 0),
    responseTimeMs: b(t, "response_time_ms", 0),
    sentAt: u(t, "sent_at", ""),
    createdAt: u(t, "created_at", ""),
    source: u(t, "source", ""),
    riskScore: b(t, "risk_score", 0),
    // Left base64-encoded: the frontend renders them through Caido's editors,
    // and decoding here would force a lossy string round trip.
    rawRequestBase64: u(t, "raw_request", ""),
    rawResponseBase64: u(t, "raw_response", "")
  };
}
function _r(t) {
  return {
    uuid: u(t, "uuid", ""),
    name: u(t, "name", ""),
    status: u(t, "status", ""),
    scanSource: u(t, "scan_source", ""),
    scanMode: u(t, "scan_mode", ""),
    sourceType: u(t, "source_type", ""),
    modules: u(t, "modules", ""),
    totalFindings: b(t, "total_findings", 0),
    processedCount: b(t, "processed_count", 0),
    startedAt: u(t, "started_at", ""),
    finishedAt: u(t, "finished_at", ""),
    createdAt: u(t, "created_at", "")
  };
}
function Sr(t) {
  return {
    uuid: u(t, "uuid", ""),
    mode: u(t, "mode", ""),
    status: u(t, "status", ""),
    agentName: u(t, "agent_name", ""),
    templateId: u(t, "template_id", ""),
    targetUrl: u(t, "target_url", ""),
    inputType: u(t, "input_type", ""),
    currentPhase: u(t, "current_phase", ""),
    phasesRun: ee(t, "phases_run"),
    findingCount: b(t, "finding_count", 0),
    recordCount: b(t, "record_count", 0),
    savedCount: b(t, "saved_count", 0),
    durationMs: b(t, "duration_ms", 0),
    startedAt: u(t, "started_at", ""),
    completedAt: u(t, "completed_at", ""),
    createdAt: u(t, "created_at", "")
  };
}
function me(t, e) {
  const s = [];
  for (const [n, r] of Object.entries(e)) {
    if (r == null) continue;
    const o = String(r);
    o.trim() && s.push(`${encodeURIComponent(n)}=${encodeURIComponent(o)}`);
  }
  return s.length > 0 ? `${t}?${s.join("&")}` : t;
}
const wr = 8;
async function Er(t, e) {
  const s = new Array(e.length);
  let n = 0;
  const r = async () => {
    for (let i = n++; i < e.length; i = n++) {
      const c = await t.requests.get(e[i]);
      c != null && c.request && (s[i] = {
        url: c.request.getUrl(),
        requestBytes: c.request.getRaw().toBytes(),
        responseBytes: c.response ? c.response.getRaw().toBytes() : null
      });
    }
  }, o = Math.min(wr, e.length);
  return await Promise.all(Array.from({ length: o }, r)), s.filter((i) => i !== void 0);
}
var Ve, W, H, Ye, Ke, Xe, $, Et, Tt, Bs, Os;
class Tr {
  constructor(e, s, n, r, o, i) {
    f(this, $);
    f(this, Ve);
    f(this, W);
    f(this, H);
    f(this, Ye);
    f(this, Ke);
    f(this, Xe);
    h(this, Ve, e), h(this, W, s), h(this, H, n), h(this, Ye, r), h(this, Ke, o), h(this, Xe, i);
  }
  /** Resolves Caido request IDs then dispatches - the row-selection entry point. */
  async dispatchIds(e, s, n) {
    return g(this, $, Et).call(this, n) ? g(this, $, Tt).call(this, e, await Er(a(this, Ve), s), n) : 0;
  }
  /**
   * Dispatches requests carried as raw text - the request/response editor entry
   * point, where the message may be an unsaved draft with no id.
   */
  async dispatchRaw(e, s, n) {
    if (!g(this, $, Et).call(this, n)) return 0;
    const r = s.filter((o) => o.request.length > 0).map((o) => ({
      url: o.url,
      requestBytes: Lt(o.request),
      responseBytes: o.response ? Lt(o.response) : null
    }));
    return g(this, $, Tt).call(this, e, r, n);
  }
}
Ve = new WeakMap(), W = new WeakMap(), H = new WeakMap(), Ye = new WeakMap(), Ke = new WeakMap(), Xe = new WeakMap(), $ = new WeakSet(), Et = function(e) {
  return a(this, W).isConfigured() ? !0 : (a(this, H).error(`[${e}] Skipped: ${At}`), !1);
}, Tt = async function(e, s, n) {
  var c, l, d, m;
  if (s.length === 0)
    return a(this, H).warn(`[${n}] Nothing to send: no request bytes available`), 0;
  const r = g(this, $, Bs).call(this, e), o = `[${n}:${r.label}]`;
  (c = r.counters) == null || c.incrementPending(s.length);
  let i = 0;
  for (const p of s) {
    if (g(this, $, Os).call(this, p, o)) {
      (l = r.counters) == null || l.markFailed();
      continue;
    }
    try {
      const _ = await r.send(p);
      (d = r.counters) == null || d.markSent(), i++, _ && a(this, H).info(`${o} ${_}`);
    } catch (_) {
      (m = r.counters) == null || m.markFailed();
      const w = r.describeError(_);
      a(this, H)[w.level](`${o} ${w.message}`);
    }
  }
  return a(this, H).info(`${o} Sent ${i}/${s.length} requests`), i;
}, Bs = function(e) {
  switch (e) {
    case "ingest":
      return {
        label: "Ingest",
        counters: a(this, Ke),
        send: async (s) => {
          await a(this, W).ingest({
            input_mode: "burp_base64",
            url: s.url,
            http_request_base64: O(s.requestBytes),
            http_response_base64: s.responseBytes ? O(s.responseBytes) : null
          });
        },
        describeError: (s) => ({
          level: "error",
          message: `Failed to send request: ${B(s)}`
        })
      };
    case "scan": {
      const s = a(this, Ye).get(), n = wt(s.customModules), r = wt(s.scanTimeout);
      return {
        label: "Scan",
        counters: a(this, Xe),
        send: async (o) => {
          const i = await a(this, W).scan({
            url: o.url,
            http_request_base64: O(o.requestBytes),
            http_response_base64: o.responseBytes ? O(o.responseBytes) : null,
            modules: n,
            timeout: r
          });
          return `${i.message} (scan_id: ${i.scanId})`;
        },
        describeError: (o) => o instanceof te && o.statusCode === 409 ? { level: "warn", message: "A scan is already running" } : { level: "error", message: `Scan failed: ${B(o)}` }
      };
    }
    case "agentScan":
      return {
        label: "AgentScan",
        counters: void 0,
        send: async (s) => `Started: ${await a(this, W).agentScan({
          url: s.url,
          http_request_base64: O(s.requestBytes),
          http_response_base64: s.responseBytes ? O(s.responseBytes) : null,
          save_findings: !0,
          mode: "balanced"
        })}`,
        describeError: (s) => ({
          level: "error",
          message: `Agent scan failed: ${B(s)}`
        })
      };
  }
}, /**
 * Reports an over-limit record instead of letting the server answer 413.
 *
 * The raw status code says nothing about which record was at fault or by how
 * much, which makes a partial batch failure very hard to act on.
 */
Os = function(e, s) {
  var r;
  const n = e.requestBytes.length + (((r = e.responseBytes) == null ? void 0 : r.length) ?? 0);
  return n <= St ? !1 : (a(this, H).warn(
    `${s} Skipped ${e.url}: ${kt(n)} exceeds the ${kt(St)} the server accepts once base64-encoded`
  ), !0);
};
let bt;
function y() {
  if (!bt) throw new Error("Vigolium backend is not initialised");
  return bt;
}
async function br() {
  return y().settings.get();
}
async function Rr(t, e) {
  return y().settings.update(e);
}
async function Ar() {
  try {
    return { ok: !0, health: await y().api.health() };
  } catch (t) {
    return { ok: !1, message: B(t) };
  }
}
async function Br() {
  return y().bridge.testConnection();
}
async function Or() {
  const { bridge: t } = y();
  return await t.restart(), t.status();
}
async function Cr() {
  return y().bridge.status();
}
async function Ir() {
  return y().snapshot.status();
}
async function vr(t, e) {
  return y().snapshot.snapshotNow(e || "Manual");
}
async function $r() {
  const { snapshot: t } = y();
  return t.reschedule(), t.status();
}
async function Cs() {
  const { ingestCounters: t, scanCounters: e } = y();
  return { ingest: t.snapshot(), scan: e.snapshot() };
}
async function qr() {
  const { ingestCounters: t, scanCounters: e } = y();
  return t.reset(), e.reset(), Cs();
}
async function Nr() {
  return y().log.entries();
}
async function Mr() {
  y().log.clear();
}
async function Lr(t, e, s, n) {
  return y().dispatch.dispatchIds(e, s, n);
}
async function Ur(t, e, s, n) {
  return y().dispatch.dispatchRaw(e, s, n);
}
async function kr(t, e) {
  return y().api.findings(e);
}
async function Pr(t, e) {
  return y().api.findingById(e);
}
async function xr(t, e) {
  return y().api.deleteFinding(e);
}
async function Dr(t, e) {
  return y().api.httpRecords(e);
}
async function Hr(t, e) {
  return y().api.httpRecordByUuid(e);
}
async function Fr(t, e) {
  return y().api.deleteHttpRecord(e);
}
async function Gr(t, e) {
  const { api: s, settings: n } = y();
  return s.scanRecords([e], n.moduleList());
}
async function Vr(t, e, s) {
  return y().api.scanAllRecords(ws(e), wt(s));
}
async function Yr(t, e, s) {
  return y().api.scans(e, s);
}
async function Kr(t, e, s, n, r, o) {
  return y().api.scanLogs(e, s || void 0, n || void 0, r, o);
}
async function Xr(t, e) {
  return y().api.pauseScan(e);
}
async function zr(t, e) {
  return y().api.resumeScan(e);
}
async function Qr(t, e) {
  return y().api.stopScan(e);
}
async function Jr(t, e) {
  return y().api.deleteScan(e);
}
async function Wr(t, e, s, n) {
  return y().api.agentSessions(e || void 0, s, n);
}
async function Zr(t, e) {
  return y().api.agentSessionLogs(e);
}
async function jr(t, e) {
  const { api: s, log: n } = y(), r = await s.httpRecordByUuid(e);
  if (!r.rawRequestBase64)
    throw new te(0, "Record has no raw request to replay");
  const o = await rt(
    t,
    {
      url: r.url,
      requestBytes: _t(r.rawRequestBase64),
      responseBytes: r.rawResponseBase64 ? _t(r.rawResponseBase64) : null,
      roundtripTimeMs: r.responseTimeMs
    },
    `vigolium-${r.uuid.slice(0, 8)}`
  );
  return n.info(`[HTTP Records] Opened Replay session for ${r.url}`), o;
}
async function eo(t, e, s, n, r) {
  const { log: o } = y(), i = Ut(s);
  if (i.length === 0)
    throw new te(0, "There is no request to replay");
  const c = js(i, e), l = n ? Ut(n) : null, d = await rt(
    t,
    {
      url: c,
      requestBytes: i,
      responseBytes: l && l.length > 0 ? l : null
    },
    r || "vigolium"
  );
  return o.info(`[Findings] Opened Replay session for ${c}`), d;
}
const to = {
  getSettings: br,
  updateSettings: Rr,
  testServerConnection: Ar,
  testBridgeConnection: Br,
  restartBridge: Or,
  getBridgeStatus: Cr,
  getSnapshotStatus: Ir,
  snapshotNow: vr,
  rescheduleSnapshot: $r,
  getRequestStats: Cs,
  resetRequestStats: qr,
  getLogs: Nr,
  clearLogs: Mr,
  dispatch: Lr,
  dispatchRaw: Ur,
  findings: kr,
  findingById: Pr,
  deleteFinding: xr,
  httpRecords: Dr,
  httpRecordByUuid: Hr,
  deleteHttpRecord: Fr,
  scanRecord: Gr,
  scanAllRecords: Vr,
  scans: Yr,
  scanLogs: Kr,
  pauseScan: Xr,
  resumeScan: zr,
  stopScan: Qr,
  deleteScan: Jr,
  agentSessions: Wr,
  agentSessionLogs: Zr,
  sendRecordToReplay: jr,
  sendRawToReplay: eo
};
async function co(t) {
  const e = new ir(t);
  await e.init();
  const s = new Wn(t), n = new mr(() => {
    const T = e.get();
    return { serverUrl: T.serverUrl, apiKey: T.apiKey };
  }), r = new Vt(), o = new Vt(), i = () => ot(t, Vs, {
    ingest: r.snapshot(),
    scan: o.snapshot()
  });
  r.setOnChange(i), o.setOnChange(i);
  const c = new Jn(t, e, s), l = new dr(t, e, n, s), d = new Tr(
    t,
    n,
    s,
    e,
    r,
    o
  ), m = new sr(n, s, e, r);
  bt = {
    settings: e,
    log: s,
    api: n,
    bridge: c,
    snapshot: l,
    dispatch: d,
    ingestCounters: r,
    scanCounters: o
  };
  for (const [T, A] of Object.entries(to))
    t.api.register(T, A);
  t.events.onInterceptResponse(
    (T, A, F) => m.handle(T, A, F)
  ), t.events.onProjectChange((T, A) => {
    c.onProjectChange(A ? { id: A.getId(), name: A.getName() } : null);
  });
  let p = es(e.get()), _ = ts(e.get());
  e.onChange((T) => {
    const A = es(T);
    A !== p && (p = A, c.restart());
    const F = ts(T);
    F !== _ && (_ = F, l.reschedule());
  });
  const [w] = await Promise.all([t.projects.getCurrent(), c.restart()]);
  c.onProjectChange(w ? { id: w.getId(), name: w.getName() } : null), l.start(), s.info(`Plugin v${t.meta.version()} loaded successfully.`);
}
function es(t) {
  return `${t.bridgeEnabled}|${t.bridgeListenUrl}`;
}
function ts(t) {
  return `${t.snapshotAutoEnabled}|${t.snapshotIntervalMinutes}`;
}
export {
  co as init
};
