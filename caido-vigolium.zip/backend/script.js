var As = Object.defineProperty;
var qt = (t) => {
  throw TypeError(t);
};
var Bs = (t, e, s) => e in t ? As(t, e, { enumerable: !0, configurable: !0, writable: !0, value: s }) : t[e] = s;
var at = (t, e, s) => Bs(t, typeof e != "symbol" ? e + "" : e, s), ct = (t, e, s) => e.has(t) || qt("Cannot " + s);
var i = (t, e, s) => (ct(t, e, "read from private field"), s ? s.call(t) : e.get(t)), p = (t, e, s) => e.has(t) ? qt("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, s), h = (t, e, s, n) => (ct(t, e, "write to private field"), n ? n.call(t, s) : e.set(t, s), s), m = (t, e, s) => (ct(t, e, "access private method"), s);
import { RequestSpecRaw as Cs } from "caido:utils";
import { Buffer as L } from "buffer";
import { createHash as et } from "crypto";
import { createServer as Os } from "net";
import { fetch as Is } from "caido:http";
const he = ["MATCHES", "DOES_NOT_MATCH", "EQUALS", "NOT_EQUALS"], vs = {
  FILE_EXTENSION: he,
  HTTP_METHOD: he,
  URL: [...he, "IS_IN_TARGET_SCOPE", "IS_NOT_IN_TARGET_SCOPE"],
  CONTENT_TYPE: he,
  STATUS_CODE: he,
  HOST: he,
  REQUEST: ["HAS_PARAMETERS", "HAS_BODY", "DOES_NOT_HAVE_PARAMETERS", "DOES_NOT_HAVE_BODY"]
};
function $s(t, e) {
  const s = vs[t];
  return s !== void 0 && s.includes(e);
}
const qs = [
  {
    enabled: !0,
    operator: null,
    matchType: "FILE_EXTENSION",
    relationship: "DOES_NOT_MATCH",
    condition: "woff|woff2|ttf|eot|otf|mp4|webm|ogg|mkv|flv|avi|mov|wmv|m3u8|svg|jpg|jpeg|png|gif|bmp|webp|ico|css|js|pdf|zip|exe|gz|rar|mp3"
  },
  {
    enabled: !0,
    operator: "AND",
    matchType: "HTTP_METHOD",
    relationship: "DOES_NOT_MATCH",
    condition: "OPTIONS|HEAD"
  }
], Ms = {
  serverUrl: "http://127.0.0.1:9002",
  apiKey: "",
  customModules: "",
  scanTimeout: "",
  proxyInScopeOnly: !0,
  snapshotAutoEnabled: !1,
  snapshotIntervalMinutes: 5,
  snapshotInScopeOnly: !1,
  // On by default so `--burp-bridge-url` / `--caido-bridge-url` work as soon as
  // the plugin is installed. The listener is unauthenticated, so it stays bound
  // to loopback only and still validates Host/Origin on every request; turn it
  // off in the Bridge tab if you would rather opt in per session.
  bridgeEnabled: !0,
  bridgeListenUrl: "http://127.0.0.1:9009",
  bridgeInScopeOnly: !1
};
function Ls(t) {
  switch ((t ?? "").toLowerCase()) {
    case "critical":
      return "CRITICAL";
    case "high":
      return "HIGH";
    case "medium":
    case "med":
      return "MEDIUM";
    case "low":
      return "LOW";
    case "suspect":
      return "SUSPECT";
    default:
      return "INFO";
  }
}
const Mt = 2e3, mt = 30, Ns = "vigolium-burp-bridge", bt = "vigolium-caido-bridge", Us = "X-Vigolium-Source", ks = "caido", Ps = "bridge-status", xs = "snapshot-status", Ds = "request-stats", Hs = "log";
function B(t) {
  return t instanceof Error ? t.message : String(t);
}
function Ce(t) {
  return L.from(t.buffer, t.byteOffset, t.byteLength);
}
function C(t) {
  return Ce(t).toString("base64");
}
function yt(t) {
  return new Uint8Array(L.from(t, "base64"));
}
function Fs(t, e) {
  const s = t.trim();
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(s) || s.length % 4 !== 0)
    throw new Error(`${e} is not valid base64`);
  return yt(s);
}
function ze(t) {
  return et("sha256").update(Ce(t)).digest("hex");
}
function Oe(t, e) {
  const s = e !== void 0 ? t.subarray(0, e) : t;
  return Ce(s).toString("latin1");
}
function Lt(t) {
  return new Uint8Array(L.from(t, "latin1"));
}
const Gs = 4 * 1024 * 1024, Vs = 4 / 3, Ys = 256 * 1024, _t = Math.floor(
  (Gs - Ys) / Vs
), es = 500;
function Nt(t) {
  return t >= 1024 * 1024 ? `${(t / (1024 * 1024)).toFixed(1)} MB` : `${Math.round(t / 1024)} KB`;
}
function Rt(t) {
  return t >= 1024 * 1024 ? `${Math.floor(t / (1024 * 1024))} MiB` : `${Math.floor(t / 1024)} KiB`;
}
function Ks(t) {
  const e = Oe(t, 8192), s = e.search(/\r?\n/), r = (s >= 0 ? e.slice(0, s) : e).split(" "), o = (r[0] ?? "GET").trim() || "GET", a = (r[1] ?? "/").trim() || "/", c = a.indexOf("?");
  return c < 0 ? { method: o, path: a, query: "" } : {
    method: o,
    path: a.slice(0, c),
    query: a.slice(c + 1)
  };
}
function Xs(t) {
  const e = Oe(t, 256), s = /^HTTP\/\d(?:\.\d)?\s+(\d{3})/.exec(e);
  return s != null && s[1] ? Number(s[1]) : 0;
}
function zs(t) {
  const e = new URL(t), s = e.protocol === "https:", n = e.port ? Number(e.port) : s ? 443 : 80;
  return { host: e.hostname, port: n, isTls: s };
}
function Qs(t) {
  let e;
  try {
    e = new URL(t);
  } catch {
    throw new Error("url must be an absolute http or https URL");
  }
  if (e.protocol !== "http:" && e.protocol !== "https:" || !e.hostname)
    throw new Error("url must be an absolute http or https URL");
  return t;
}
function u(t, e, s = "") {
  const n = t[e];
  return typeof n == "string" ? n : s;
}
function b(t, e, s) {
  const n = t[e];
  return typeof n == "number" && Number.isFinite(n) ? n : s;
}
function Me(t, e, s) {
  const n = t[e];
  return typeof n == "number" && Number.isFinite(n) ? Math.trunc(n) : s;
}
function ge(t, e, s = !1) {
  const n = t[e];
  return typeof n == "boolean" ? n : s;
}
function te(t, e) {
  const s = t[e];
  return Array.isArray(s) ? s.filter((n) => typeof n == "string") : [];
}
function Ut(t) {
  const e = (t ?? "").trim();
  let s;
  try {
    s = new URL(e);
  } catch {
    throw new Error("Bridge listener URL must be a valid http:// URL");
  }
  if (s.protocol !== "http:")
    throw new Error("Bridge listener URL must use http://");
  if (s.pathname && s.pathname !== "/")
    throw new Error("Bridge listener URL must not include a path");
  if (s.search || s.hash || s.username || s.password)
    throw new Error("Bridge listener URL must not include credentials, a query, or a fragment");
  const n = Number(s.port);
  if (!Number.isInteger(n) || n < 1 || n > 65535)
    throw new Error("Bridge listener URL must include a host and port");
  const r = At(s.hostname).toLowerCase(), o = Js(r);
  if (o === void 0)
    throw new Error("Bridge listener must bind to a loopback address");
  return { host: o, port: n, configuredHost: r };
}
function Js(t) {
  if (t === "localhost") return "127.0.0.1";
  if (t === "::1" || t === "0:0:0:0:0:0:0:1") return "::1";
  if (/^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(t) && t.split(".").map(Number).every((s) => s >= 0 && s <= 255))
    return t;
}
function At(t) {
  return t.startsWith("[") && t.endsWith("]") ? t.slice(1, -1) : t;
}
function ye(t) {
  let e = (t ?? "").trim().toLowerCase();
  for (e = At(e); e.endsWith("."); ) e = e.slice(0, -1);
  return e;
}
function Ws(t, e) {
  if (!t || !t.trim() || t.includes(",")) return;
  let s;
  try {
    s = new URL(`http://${t.trim()}`);
  } catch {
    return;
  }
  if (!s.hostname || s.username || s.password || s.pathname && s.pathname !== "/" || s.search || s.hash || t.includes("/")) return;
  const n = s.port ? Number(s.port) : e;
  if (Number.isInteger(n))
    return { host: At(s.hostname), port: n };
}
var q;
class Zs {
  constructor(e) {
    p(this, q);
    h(this, q, e);
  }
  acceptsHost(e) {
    const s = Ws(e, 80);
    if (!s || s.port !== i(this, q).port) return !1;
    const n = ye(s.host);
    return n === ye(i(this, q).configuredHost) || n === ye(i(this, q).host);
  }
  acceptsOrigin(e) {
    if (!e || !e.trim()) return !0;
    let s;
    try {
      s = new URL(e.trim());
    } catch {
      return !1;
    }
    if (s.protocol !== "http:" || !s.hostname || s.username || s.password || s.pathname && s.pathname !== "/" || s.search || s.hash) return !1;
    const n = s.port ? Number(s.port) : 80;
    return this.acceptsHost(`${s.hostname}:${n}`);
  }
  displayUrl() {
    return `http://${i(this, q).host.includes(":") ? `[${i(this, q).host}]` : i(this, q).host}:${i(this, q).port}`;
  }
}
q = new WeakMap();
function js(t, e) {
  const s = u(t, "location") === "proxy_history" ? "proxy_history" : "sitemap", n = /* @__PURE__ */ new Set();
  for (const d of ut(t, "methods")) n.add(d.toUpperCase());
  const r = /* @__PURE__ */ new Set();
  if (Array.isArray(t.status))
    for (const d of t.status) {
      const f = Number(d);
      Number.isInteger(f) && r.add(f);
    }
  const o = ut(t, "search_terms");
  ve(o, u(t, "text")), ve(o, u(t, "header")), ve(o, u(t, "body"));
  const a = ut(t, "exclude_terms");
  ve(a, u(t, "exclude_header")), ve(a, u(t, "exclude_body"));
  const c = Me(t, "limit", 50), l = Me(t, "offset", 0);
  return {
    location: s,
    host: u(t, "host"),
    methods: n,
    path: u(t, "path"),
    statuses: r,
    mimeType: u(t, "mime_type"),
    searchTerms: o,
    excludeTerms: a,
    fromTime: xt(u(t, "from")),
    toTime: xt(u(t, "to")),
    inScopeOnly: e || t.in_scope_only === !0,
    limit: Math.max(0, Math.min(c, 5e3)),
    offset: Math.max(0, l),
    sortBy: u(t, "sort"),
    sortAscending: u(t, "order").toLowerCase() === "asc"
  };
}
function en(t) {
  return {
    criteria: t,
    host: rn(t.host),
    // Burp treated `*` as decoration around a substring rather than a real glob.
    path: t.path.replace(/\*/g, "").toLowerCase(),
    mimeType: t.mimeType.toLowerCase(),
    searchTerms: t.searchTerms.filter(Boolean).map((e) => e.toLowerCase()),
    excludeTerms: t.excludeTerms.filter(Boolean).map((e) => e.toLowerCase())
  };
}
function tn(t, e, s) {
  const { criteria: n } = t;
  if (n.inScopeOnly && !s || n.fromTime !== void 0 && e.createdAt < n.fromTime || n.toTime !== void 0 && e.createdAt > n.toTime || t.host && !t.host(e.request.getHost()) || n.methods.size > 0 && !n.methods.has(e.request.getMethod().toUpperCase()) || t.path && !e.request.getPath().toLowerCase().includes(t.path) || n.statuses.size > 0 && (!e.response || !n.statuses.has(e.response.getCode())) || t.mimeType && (!e.response || !ts(e.response, "content-type").toLowerCase().includes(t.mimeType)))
    return !1;
  for (const r of t.searchTerms)
    if (!kt(e, r)) return !1;
  for (const r of t.excludeTerms)
    if (kt(e, r)) return !1;
  return !0;
}
function kt(t, e) {
  const s = sn(t);
  return s.request.includes(e) || s.response.includes(e);
}
function sn(t) {
  return t.text || (t.text = {
    request: Oe(t.request.getRaw().toBytes()).toLowerCase(),
    response: t.response ? Oe(t.response.getRaw().toBytes()).toLowerCase() : ""
  }), t.text;
}
function ts(t, e) {
  const s = t.getHeader(e);
  return (s == null ? void 0 : s[0]) ?? "";
}
const nn = /[\\.[\]{}()+\-^$|?]/g;
function rn(t) {
  const e = ye(t);
  if (!e) return;
  if (!e.includes("*")) return (r) => ye(r) === e;
  const s = e.split("*").map((r) => r.replace(nn, "\\$&")).join(".*"), n = new RegExp(`^${s}$`);
  return (r) => n.test(ye(r));
}
function on(t, e, s) {
  var r, o;
  let n;
  switch (t.sortBy) {
    case "method":
      n = Je(e.request.getMethod(), s.request.getMethod());
      break;
    case "path":
      n = Je(e.request.getPath(), s.request.getPath());
      break;
    case "status":
    case "status_code":
      n = (((r = e.response) == null ? void 0 : r.getCode()) ?? 0) - (((o = s.response) == null ? void 0 : o.getCode()) ?? 0);
      break;
    case "url":
      n = Je(e.request.getUrl(), s.request.getUrl());
      break;
    default:
      n = e.createdAt - s.createdAt;
      break;
  }
  return n === 0 && t.sortBy !== "url" && (n = Je(e.request.getUrl(), s.request.getUrl())), t.sortAscending ? n : -n;
}
function Je(t, e) {
  const s = t.toLowerCase(), n = e.toLowerCase();
  return s < n ? -1 : s > n ? 1 : 0;
}
function an(t) {
  const e = [];
  if (t.location === "proxy_history" && e.push('source:"intercept"'), t.host && !t.host.includes("*") && e.push(`req.host.eq:${Pt(t.host)}`), t.methods.size === 1) {
    const [s] = [...t.methods];
    e.push(`req.method.eq:${Pt(s)}`);
  }
  if (t.statuses.size === 1) {
    const [s] = [...t.statuses];
    e.push(`resp.code.eq:${s}`);
  }
  return e.join(" and ");
}
function Pt(t) {
  return `"${t.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}
function ut(t, e) {
  return te(t, e).filter((s) => s.trim().length > 0);
}
function ve(t, e) {
  e && e.trim() && t.push(e);
}
function xt(t) {
  if (!t || !t.trim()) return;
  const e = Date.parse(t);
  return Number.isNaN(e) ? void 0 : e;
}
const cn = 2e4;
async function un(t, e) {
  const s = an(e), n = en(e);
  let r, o = 0, a = !1;
  const c = [];
  let l = s, d = !1;
  for (; ; ) {
    let f;
    try {
      let g = t.requests.query().first(es);
      l && !d && (g = g.filter(l)), r && (g = g.after(r)), g = e.sortAscending ? g.ascending("req", "created_at") : g.descending("req", "created_at"), f = await g.execute();
    } catch (g) {
      if (!d && l) {
        t.console.warn(
          `[Vigolium] HTTPQL prefilter rejected (${B(g)}); scanning unfiltered`
        ), d = !0, r = void 0, o = 0, c.length = 0;
        continue;
      }
      throw g;
    }
    if (f.items.length === 0) break;
    for (const g of f.items) {
      o += 1;
      const S = ss(g.request, g.response), w = e.inScopeOnly ? t.requests.inScope(g.request) : !0;
      tn(n, S, w) && c.push(S);
    }
    if (r = f.pageInfo.endCursor, !f.pageInfo.hasNextPage) break;
    if (o >= cn) {
      a = !0;
      break;
    }
  }
  return c.sort((f, g) => on(e, f, g)), { candidates: c, truncated: a, scanned: o };
}
function ss(t, e) {
  return { request: t, response: e, createdAt: t.getCreatedAt().getTime() };
}
async function ns(t, e) {
  const s = await t.requests.get(e);
  if (!(s != null && s.request)) throw new Error("Caido ref expired or unknown; search again");
  return ss(s.request, s.response);
}
const ln = `
  mutation VigoliumCreateRequest($input: CreateRequestInput!) {
    createRequest(input: $input) {
      id
      responseId
    }
  }
`, dn = `
  mutation VigoliumCreateSitemapEntries($requestId: ID!) {
    createSitemapEntries(requestId: $requestId) {
      __typename
    }
  }
`;
async function Bt(t, e) {
  var g, S, w;
  const { host: s, port: n, isTls: r } = zs(e.url), { method: o, path: a, query: c } = Ks(e.requestBytes), l = {
    input: {
      host: s,
      port: n,
      isTls: r,
      method: o,
      path: a,
      query: c,
      raw: C(e.requestBytes),
      source: "PLUGIN",
      alteration: "NONE",
      ...r ? { sni: s } : {},
      ...e.responseBytes && e.responseBytes.length > 0 ? {
        response: {
          raw: C(e.responseBytes),
          statusCode: Xs(e.responseBytes),
          roundtripTime: Math.max(0, Math.trunc(e.roundtripTimeMs ?? 0)),
          source: "PLUGIN",
          alteration: "NONE"
        }
      } : {}
    }
  }, d = await t.graphql.execute(ln, l);
  if (d.errors && d.errors.length > 0)
    throw new Error(`Caido rejected the request import: ${((g = d.errors[0]) == null ? void 0 : g.message) ?? "unknown"}`);
  const f = (w = (S = d.data) == null ? void 0 : S.createRequest) == null ? void 0 : w.id;
  if (!f) throw new Error("Caido did not return an id for the imported request");
  return f;
}
async function rs(t, e) {
  var n;
  const s = await t.graphql.execute(dn, { requestId: e });
  if (s.errors && s.errors.length > 0)
    throw new Error(`Caido rejected the sitemap entry: ${((n = s.errors[0]) == null ? void 0 : n.message) ?? "unknown"}`);
}
async function hn(t, e) {
  var a, c, l;
  const s = e.trim();
  if (!s) return;
  const r = (await t.replay.getCollections()).find((d) => d.getName() === s);
  if (r) return r.getId();
  const o = await t.graphql.execute(
    `mutation VigoliumCreateCollection($input: CreateReplaySessionCollectionInput!) {
       createReplaySessionCollection(input: $input) { collection { id } }
     }`,
    { input: { name: s } }
  );
  if (!(o.errors && o.errors.length > 0))
    return ((l = (c = (a = o.data) == null ? void 0 : a.createReplaySessionCollection) == null ? void 0 : c.collection) == null ? void 0 : l.id) ?? void 0;
}
async function pn(t, e, s) {
  const n = s.trim();
  n && await t.graphql.execute(
    `mutation VigoliumRenameSession($id: ID!, $name: String!) {
       renameReplaySession(id: $id, name: $name) { session { id } }
     }`,
    { id: e, name: n }
  );
}
async function Ct(t, e, s, n) {
  const r = await Bt(t, e), o = await t.replay.createSession(r, n);
  return await pn(t, o.getId(), s), o.getId();
}
const fn = {
  blocked: !0,
  sent: !1,
  statusCode: 0,
  responseBytes: new Uint8Array(0),
  elapsedMs: void 0,
  error: void 0
};
async function gn(t, e, s, n) {
  var a;
  const r = new Cs(e);
  if (r.setRaw(s), n.enforceInScope && !t.requests.inScope(r.toSpec()))
    return fn;
  const o = Date.now();
  try {
    const l = (await t.requests.send(r, {
      timeouts: { global: n.timeoutMs },
      save: n.save
    })).response;
    return {
      blocked: !1,
      sent: !0,
      statusCode: (l == null ? void 0 : l.getCode()) ?? 0,
      responseBytes: l ? l.getRaw().toBytes() : new Uint8Array(0),
      elapsedMs: ((a = l == null ? void 0 : l.getRoundtripTime) == null ? void 0 : a.call(l)) ?? Date.now() - o,
      error: void 0
    };
  } catch (c) {
    return {
      blocked: !1,
      sent: !1,
      statusCode: 0,
      responseBytes: new Uint8Array(0),
      elapsedMs: void 0,
      error: B(c)
    };
  }
}
function rt(t, e, ...s) {
  try {
    t.api.send(e, ...s);
  } catch {
  }
}
const mn = {
  200: "OK",
  400: "Bad Request",
  403: "Forbidden",
  404: "Not Found",
  405: "Method Not Allowed",
  413: "Payload Too Large",
  429: "Too Many Requests",
  500: "Internal Server Error",
  503: "Service Unavailable"
}, yn = 64 * 1024, os = 4, _n = 3e4;
function Sn(t, e) {
  const s = Math.max(0, e - (os - 1));
  for (let n = s; n + 3 < t.length; n++)
    if (t[n] === 13 && t[n + 1] === 10 && t[n + 2] === 13 && t[n + 3] === 10)
      return n;
  return -1;
}
var _e, Ue, ke, Se, tt, is;
class wn {
  constructor(e, s, n) {
    p(this, tt);
    p(this, _e);
    p(this, Ue);
    p(this, ke);
    p(this, Se);
    h(this, Ue, e), h(this, ke, s), h(this, Se, n);
  }
  listen(e, s) {
    return new Promise((n, r) => {
      let o = !1;
      const a = Os((c) => m(this, tt, is).call(this, c));
      a.on("error", (c) => {
        if (!o) {
          o = !0, r(c);
          return;
        }
        i(this, Se).call(this, c.message);
      }), a.listen(s, e, () => {
        o = !0, h(this, _e, a), n();
      });
    });
  }
  close() {
    const e = i(this, _e);
    if (h(this, _e, void 0), !!e)
      try {
        e.close();
      } catch {
      }
  }
}
_e = new WeakMap(), Ue = new WeakMap(), ke = new WeakMap(), Se = new WeakMap(), tt = new WeakSet(), is = function(e) {
  const s = [];
  let n = 0, r = L.alloc(0), o = 0, a = -1, c = 0, l, d = !1;
  const f = setTimeout(() => {
    g({ status: 400, json: { error: "request timed out" } });
  }, _n), g = (w) => {
    d || (d = !0, clearTimeout(f), Tn(e, w));
  };
  e.on("error", () => {
    d = !0, clearTimeout(f);
  });
  const S = () => s.length === 1 ? s[0] : L.concat(s, n);
  e.on("data", (w) => {
    if (d) return;
    if (s.push(w), n += w.length, a < 0) {
      if (r = S(), a = Sn(r, o), o = r.length, a < 0) {
        n > yn && g({ status: 400, json: { error: "request headers too large" } });
        return;
      }
      const N = En(r.toString("latin1", 0, a));
      if (!N) {
        g({ status: 400, json: { error: "malformed request line" } });
        return;
      }
      l = N;
      const $ = i(this, ke).call(this, N.path), Ie = N.headers.get("content-length");
      if (N.method === "POST") {
        if (Ie === void 0) {
          g({ status: 400, json: { error: "content-length is required" } });
          return;
        }
        const Qe = Number(Ie);
        if (!Number.isInteger(Qe) || Qe < 0) {
          g({ status: 400, json: { error: "invalid content-length" } });
          return;
        }
        if (Qe > $) {
          g({ status: 400, json: { error: `request exceeds ${Rt($)}` } });
          return;
        }
        c = Qe;
      }
    }
    const T = a + os;
    if (n - T < c) return;
    const A = S(), F = {
      method: l.method,
      path: l.path,
      headers: l.headers,
      body: new Uint8Array(A.subarray(T, T + c))
    };
    i(this, Ue).call(this, F).then(g).catch((N) => {
      const $ = B(N);
      i(this, Se).call(this, `request failed: ${$}`), g({ status: 500, json: { error: $ } });
    });
  });
};
function En(t) {
  const e = t.split(`\r
`), s = e.shift();
  if (!s) return;
  const n = s.split(" ");
  if (n.length < 3) return;
  const [r, o] = n;
  if (!r || !o) return;
  const a = /* @__PURE__ */ new Map();
  for (const d of e) {
    const f = d.indexOf(":");
    if (f <= 0) continue;
    const g = d.slice(0, f).trim().toLowerCase(), S = d.slice(f + 1).trim();
    a.has(g) || a.set(g, S);
  }
  const c = o.indexOf("?"), l = c >= 0 ? o.slice(0, c) : o;
  return { method: r.toUpperCase(), path: l, headers: a };
}
function Tn(t, e) {
  const s = L.from(JSON.stringify(e.json ?? {}), "utf-8"), n = mn[e.status] ?? "Unknown", r = `HTTP/1.1 ${e.status} ${n}\r
Content-Type: application/json; charset=utf-8\r
Content-Length: ${s.length}\r
Cache-Control: no-store\r
X-Content-Type-Options: nosniff\r
Connection: close\r
\r
`;
  try {
    t.write(L.concat([L.from(r, "latin1"), s])), t.end();
  } catch {
  }
}
const bn = 1e4;
var U, Pe, st, as;
class Rn {
  constructor() {
    p(this, st);
    p(this, U, /* @__PURE__ */ new Map());
    p(this, Pe, 0);
  }
  remember(e) {
    const s = m(this, st, as).call(this);
    for (i(this, U).set(s, e); i(this, U).size > bn; ) {
      const n = i(this, U).keys().next();
      if (n.done) break;
      i(this, U).delete(n.value);
    }
    return s;
  }
  require(e) {
    const s = i(this, U).get(e);
    if (!s) throw new Error("Caido ref expired or unknown; search again");
    return s;
  }
  clear() {
    i(this, U).clear();
  }
  size() {
    return i(this, U).size;
  }
}
U = new WeakMap(), Pe = new WeakMap(), st = new WeakSet(), /**
 * Monotonic, unguessable-enough identifier. These never leave the loopback
 * interface and expire with the listener, so a counter plus randomness is
 * sufficient without pulling in a UUID dependency.
 */
as = function() {
  h(this, Pe, i(this, Pe) + 1);
  const e = Math.random().toString(36).slice(2, 10);
  return `${i(this, Pe).toString(36)}-${e}`;
};
const Le = 64 * 1024, cs = 4 * 1024 * 1024, lt = cs, Ne = 8 * 1024 * 1024, dt = 24 * 1024 * 1024, An = 1024 * 1024, Bn = 2 * 1024 * 1024, Cn = 3e4, On = 12e4, us = "target is out of Caido scope; disable in-scope-only or add it to the project scope";
class O extends Error {
  constructor(s, n) {
    super(n);
    at(this, "status");
    this.name = "BridgeError", this.status = s;
  }
}
function In(t) {
  const e = t.project();
  return {
    status: "ok",
    // Kept as the Burp listener's identifier so existing tooling that sniffs
    // this field keeps working; `implementation` says what actually answered.
    service: Ns,
    implementation: bt,
    read_only: !1,
    loopback_only: !0,
    in_scope_only: t.inScopeOnly(),
    authentication: "none",
    // Derived from the route table rather than listed separately: a capability
    // the listener does not actually serve is a lie the CLI acts on.
    capabilities: Object.values(Ot).map((s) => s.capability),
    repeater_tabs_per_minute: mt,
    send_respects_in_scope_only: t.inScopeOnly(),
    // Caido scopes traffic per project, so which project is active changes what
    // /search returns. Reported here so CLI output stays explainable.
    project_id: e.id,
    project_name: e.name
  };
}
async function vn(t, e) {
  const s = js(e, t.inScopeOnly()), { candidates: n, truncated: r, scanned: o } = await un(t.sdk, s), a = n.length, c = Math.min(s.offset, a), l = s.limit === 0 ? a : Math.min(a, c + s.limit), d = n.slice(c, l).map((f) => {
    var w;
    const S = {
      ref: t.refs.remember({
        requestId: f.request.getId(),
        url: f.request.getUrl()
      }),
      location: s.location,
      method: f.request.getMethod(),
      url: f.request.getUrl(),
      request_hash: ze(f.request.getRaw().toBytes()),
      status: f.response ? f.response.getCode() : 0,
      time: new Date(f.createdAt).toISOString()
    };
    if (f.response) {
      const T = ts(f.response, "content-type");
      T && (S.mime_type = ((w = T.split(";")[0]) == null ? void 0 : w.trim()) ?? T);
    }
    return S;
  });
  return r && t.log.warn(
    `[Bridge] Search examined the first ${o} requests and stopped at the scan cap; totals are a floor. Narrow the filter for exact counts.`
  ), {
    total: a,
    // Echoed per reply, not read once off /health, so Vigolium's read path pays
    // no extra round trip to learn that these records came from Caido.
    implementation: bt,
    offset: c,
    returned: d.length,
    has_more: l < a,
    records: d,
    ...r ? { truncated: !0, scanned: o } : {}
  };
}
async function $n(t, e) {
  const s = u(e, "ref");
  if (!s) throw new O(400, "ref is required");
  const n = t.refs.require(s), r = await ns(t.sdk, n.requestId), o = Me(e, "max_bytes", 16384), a = Math.max(1024, Math.min(o, cs)), c = r.request.getRaw().toBytes(), l = r.response ? r.response.getRaw().toBytes() : new Uint8Array(0), d = {
    ref: s,
    // Repeated here rather than left to /search: an inspect can be the first
    // and only call of a session (Vigolium's single-record read has no
    // preceding search), and without it that record would fall back to `burp`.
    implementation: bt,
    url: r.request.getUrl(),
    request_base64: C(c.subarray(0, Math.min(c.length, a))),
    request_truncated: c.length > a
  };
  return a <= Le && (d.request = Oe(c, a)), r.response && (a <= Le && (d.response = Oe(l, a)), d.response_base64 = C(
    l.subarray(0, Math.min(l.length, a))
  ), d.response_truncated = l.length > a), d;
}
async function qn(t, e) {
  const s = await ot(t, e, Ne), n = ls(
    $t(e, "http_response_base64"),
    Ne,
    "response"
  ), r = it(e, "source", 80, "vigolium"), o = await Bt(t.sdk, {
    url: s.url,
    requestBytes: s.requestBytes,
    responseBytes: n.length > 0 ? n : null
  });
  return await rs(t.sdk, o), t.log.info(`[Bridge] Added 1 item to the Sitemap from ${r}`), {
    added: 1,
    url: s.url,
    request_hash: ze(s.requestBytes),
    message: "added 1 item to Caido Sitemap"
  };
}
var G;
class Mn {
  constructor() {
    p(this, G, []);
  }
  reserve() {
    const e = Date.now(), s = e - 6e4;
    for (; i(this, G).length > 0 && i(this, G)[0] < s; )
      i(this, G).shift();
    if (i(this, G).length >= mt)
      throw new O(
        429,
        `Replay session limit reached (${mt} per minute); retry shortly`
      );
    i(this, G).push(e);
  }
  clear() {
    h(this, G, []);
  }
}
G = new WeakMap();
async function Ln(t, e) {
  const s = await ot(t, e, An), n = it(e, "tab_name", 64, "vigolium"), r = e.send === !0;
  t.limiter.reserve();
  const o = r ? await It(t, s, e, !1) : void 0;
  await Ct(
    t.sdk,
    {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: o != null && o.responseBytes.length ? o.responseBytes : null,
      roundtripTimeMs: o == null ? void 0 : o.elapsedMs
    },
    n
  ), t.log.info(`[Bridge] Opened Replay session "${n}"`);
  const a = {
    sent: 1,
    url: s.url,
    tab_name: n,
    request_hash: ze(s.requestBytes)
  };
  return o && (o.blocked ? (a.executed = !1, a.error = "target is out of Caido scope; not auto-sent") : (a.executed = o.sent, vt(a, o))), a.message = "sent 1 request to Caido Replay", a;
}
async function Nn(t, e) {
  const s = await ot(t, e, Ne), n = Hn(u(e, "http_mode")), r = e.add_to_sitemap === !0, o = await It(t, s, e, r);
  if (o.blocked) throw new O(403, us);
  const a = {
    sent: o.sent ? 1 : 0,
    url: s.url,
    request_hash: ze(s.requestBytes),
    http_mode: n
  };
  if (vt(a, o), r && o.sent) {
    const c = await Bt(t.sdk, {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: o.responseBytes.length > 0 ? o.responseBytes : null,
      source: it(e, "source", 80, "vigolium-send"),
      roundtripTimeMs: o.elapsedMs
    });
    await rs(t.sdk, c), a.added_to_sitemap = !0;
  } else
    a.added_to_sitemap = !1;
  return t.log.info(
    o.sent ? `[Bridge] Sent 1 request via Caido to ${s.url} (HTTP ${o.statusCode})` : `[Bridge] Send via Caido to ${s.url} failed: ${o.error ?? "unknown"}`
  ), a;
}
const Un = /* @__PURE__ */ new Set([
  "none",
  "red",
  "orange",
  "yellow",
  "green",
  "cyan",
  "blue",
  "pink",
  "magenta",
  "gray"
]);
async function kn(t, e) {
  const s = await ot(t, e, Ne);
  let n = $t(e, "http_response_base64");
  const r = e.send === !0, o = u(e, "highlight").trim().toLowerCase();
  if (o && !Un.has(o))
    throw new O(
      400,
      "highlight must be one of none, red, orange, yellow, green, cyan, blue, pink, magenta, gray"
    );
  let a;
  if (r && n.length === 0) {
    if (a = await It(t, s, e, !1), a.blocked) throw new O(403, us);
    a.responseBytes.length > 0 && (n = a.responseBytes);
  }
  ls(n, Ne, "response");
  const c = ds(u(e, "notes"), 200), l = it(e, "source", 80, "vigolium"), d = c || (o && o !== "none" ? o : "") || "vigolium", f = await hn(t.sdk, d);
  await Ct(
    t.sdk,
    {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: n.length > 0 ? n : null,
      roundtripTimeMs: a == null ? void 0 : a.elapsedMs
    },
    c || l,
    f
  ), t.log.info(`[Bridge] Added 1 item to Replay collection "${d}" from ${l}`);
  const g = {
    added: 1,
    url: s.url,
    request_hash: ze(s.requestBytes),
    has_response: n.length > 0,
    collection: d,
    message: `added 1 item to Caido Replay collection "${d}"`
  };
  return c && (g.notes = c), a && vt(g, a), g;
}
const Ot = {
  "/api/burp-bridge/search": {
    handler: vn,
    bodyLimit: Le,
    capability: "search_burp_items"
  },
  "/api/burp-bridge/inspect": {
    handler: $n,
    bodyLimit: Le,
    capability: "inspect_burp_item"
  },
  "/api/burp-bridge/sitemap": {
    handler: qn,
    bodyLimit: dt,
    capability: "add_sitemap_item"
  },
  "/api/burp-bridge/repeater": {
    handler: Ln,
    // Every call opens a visible tab, so this one is capped far lower.
    bodyLimit: Bn,
    capability: "send_to_repeater"
  },
  "/api/burp-bridge/send": {
    handler: Nn,
    bodyLimit: dt,
    capability: "send_request"
  },
  "/api/burp-bridge/organizer": {
    handler: kn,
    bodyLimit: dt,
    capability: "add_organizer_item"
  }
};
function Pn(t) {
  var e;
  return ((e = Ot[t]) == null ? void 0 : e.bodyLimit) ?? Le;
}
async function ot(t, e, s) {
  const n = u(e, "input_mode");
  if (n && n !== "burp_base64")
    throw new O(400, "input_mode must be burp_base64");
  const r = u(e, "ref").trim();
  let o, a;
  if (r) {
    const c = t.refs.require(r), l = await ns(t.sdk, c.requestId);
    o = l.request.getUrl(), a = l.request.getRaw().toBytes();
  } else {
    if (o = u(e, "url"), !o.trim()) throw new O(400, "url is required when ref is not supplied");
    a = Fn(e, "http_request_base64");
  }
  try {
    Qs(o);
  } catch (c) {
    throw new O(400, B(c));
  }
  if (a.length > s)
    throw new O(400, `request exceeds ${Rt(s)}`);
  return { url: o, requestBytes: a };
}
async function It(t, e, s, n) {
  return gn(t.sdk, e.url, e.requestBytes, {
    timeoutMs: xn(s),
    enforceInScope: t.inScopeOnly(),
    save: n
  });
}
function vt(t, e) {
  if (e.error && (t.error = e.error), e.responseBytes.length > 0) {
    const s = e.responseBytes;
    t.status_code = e.statusCode;
    const n = s.length <= lt ? s : s.subarray(0, lt);
    t.response_base64 = C(n), t.response_length = s.length, t.response_truncated = s.length > lt, e.elapsedMs !== void 0 && (t.elapsed_ms = e.elapsedMs);
  }
}
function xn(t) {
  const e = Me(t, "timeout_ms", Cn);
  return Math.max(1, Math.min(e, On));
}
const Dn = /* @__PURE__ */ new Set([
  "",
  "auto",
  "http1",
  "http_1",
  "http/1",
  "http/1.1",
  "http2",
  "http_2",
  "http/2",
  "http2_ignore_alpn",
  "http_2_ignore_alpn"
]);
function Hn(t) {
  if (!Dn.has(t.toLowerCase()))
    throw new O(400, "http_mode must be one of auto, http1, http2, http2_ignore_alpn");
  return "HTTP_1";
}
function ls(t, e, s) {
  if (t.length > e) throw new O(400, `${s} exceeds ${Rt(e)}`);
  return t;
}
function $t(t, e) {
  const s = u(t, e);
  if (!s.trim()) return new Uint8Array(0);
  try {
    return Fs(s, e);
  } catch (n) {
    throw new O(400, B(n));
  }
}
function Fn(t, e) {
  const s = $t(t, e);
  if (s.length === 0) throw new O(400, `${e} is required`);
  return s;
}
function it(t, e, s, n) {
  return ds(u(t, e), s) || n;
}
function ds(t, e) {
  const s = t.replace(/[\r\n]/g, " ").trim();
  return s.length > e ? s.slice(0, e) : s;
}
var we, se, k, ne, xe, Ee, re, P, oe, R, je, hs, ps, fs, ee;
class Gn {
  constructor(e, s, n) {
    p(this, R);
    p(this, we);
    p(this, se);
    p(this, k);
    p(this, ne, new Rn());
    p(this, xe, new Mn());
    p(this, Ee);
    p(this, re);
    p(this, P);
    p(this, oe, { id: null, name: null });
    h(this, we, e), h(this, se, s), h(this, k, n), h(this, P, Dt(s.get().bridgeListenUrl));
  }
  status() {
    return { ...i(this, P) };
  }
  /**
   * Refs point at request IDs, which only mean something inside the project
   * they came from - so switching project invalidates every outstanding ref.
   */
  onProjectChange(e) {
    h(this, oe, e ? { id: e.id, name: e.name } : { id: null, name: null });
    const s = i(this, ne).size();
    i(this, ne).clear(), s > 0 && i(this, k).info(
      `[Bridge] Project changed to ${(e == null ? void 0 : e.name) ?? "none"}; expired ${s} search refs`
    ), m(this, R, ee).call(this, { ...i(this, P), ...m(this, R, je).call(this) });
  }
  async restart() {
    m(this, R, fs).call(this);
    const e = i(this, se).get();
    if (!e.bridgeEnabled) {
      m(this, R, ee).call(this, Dt(e.bridgeListenUrl));
      return;
    }
    m(this, R, ee).call(this, {
      ...i(this, P),
      state: "STARTING",
      message: "Starting bridge listener…",
      listenUrl: e.bridgeListenUrl
    });
    try {
      const s = Ut(e.bridgeListenUrl), n = new Zs(s), r = new wn(
        (a) => m(this, R, hs).call(this, a),
        Pn,
        (a) => i(this, k).error(`[Bridge] ${a}`)
      );
      await r.listen(s.host, s.port), h(this, re, n), h(this, Ee, r);
      const o = n.displayUrl();
      m(this, R, ee).call(this, {
        state: "LISTENING",
        message: `Bridge listening on ${o}`,
        listenUrl: o,
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        lastRequestAt: null,
        ...m(this, R, je).call(this),
        inProcess: !0
      }), i(this, k).info(`[Bridge] Listening on ${o}`);
    } catch (s) {
      const n = B(s);
      h(this, re, void 0), m(this, R, ee).call(this, {
        state: "ERROR",
        message: `Bridge listener failed: ${n}`,
        listenUrl: e.bridgeListenUrl,
        startedAt: null,
        lastRequestAt: null,
        ...m(this, R, je).call(this),
        inProcess: !0
      }), i(this, k).error(`[Bridge] ${n}`);
    }
  }
  /** Probes the configured listener the same way the Vigolium client would. */
  async testConnection() {
    const e = i(this, se).get();
    try {
      const s = Ut(e.bridgeListenUrl), n = s.host.includes(":") ? `[${s.host}]` : s.host, { fetch: r } = await import("caido:http"), o = await r(`http://${n}:${s.port}/health`);
      return o.status !== 200 ? { successful: !1, message: `Bridge connection failed: HTTP ${o.status}` } : (await o.json()).status !== "ok" ? {
        successful: !1,
        message: "Bridge connection failed: unexpected health response"
      } : { successful: !0, message: "Bridge connection successful" };
    } catch (s) {
      return { successful: !1, message: `Bridge connection failed: ${B(s)}` };
    }
  }
}
we = new WeakMap(), se = new WeakMap(), k = new WeakMap(), ne = new WeakMap(), xe = new WeakMap(), Ee = new WeakMap(), re = new WeakMap(), P = new WeakMap(), oe = new WeakMap(), R = new WeakSet(), je = function() {
  return { projectId: i(this, oe).id, projectName: i(this, oe).name };
}, hs = async function(e) {
  const s = i(this, re);
  if (!s)
    return ht(503, "bridge is not ready");
  if (!s.acceptsHost(e.headers.get("host")))
    return ht(403, "unexpected Host header");
  if (!s.acceptsOrigin(e.headers.get("origin")))
    return ht(403, "unexpected Origin header");
  const n = {
    sdk: i(this, we),
    log: i(this, k),
    refs: i(this, ne),
    limiter: i(this, xe),
    inScopeOnly: () => i(this, se).get().bridgeInScopeOnly,
    project: () => i(this, oe)
  };
  if (e.path === "/" || e.path === "/health")
    return e.method !== "GET" ? j(405, "method not allowed") : Ht(In(n));
  const r = Ot[e.path];
  if (!r) return j(404, "not found");
  if (e.method !== "POST") return j(405, "method not allowed");
  let o;
  try {
    const a = Ce(e.body).toString("utf-8"), c = a.trim() ? JSON.parse(a) : {};
    if (typeof c != "object" || c === null || Array.isArray(c))
      return j(400, "request body must be a JSON object");
    o = c;
  } catch {
    return j(400, "request body is not valid JSON");
  }
  try {
    const a = await r.handler(n, o);
    return m(this, R, ps).call(this), Ht(a);
  } catch (a) {
    if (a instanceof O) return j(a.status, a.message);
    const c = B(a);
    return i(this, k).error(`[Bridge] Request failed: ${c}`), j(500, c);
  }
}, ps = function() {
  i(this, P).state === "LISTENING" && m(this, R, ee).call(this, { ...i(this, P), lastRequestAt: (/* @__PURE__ */ new Date()).toISOString() });
}, fs = function() {
  var e;
  (e = i(this, Ee)) == null || e.close(), h(this, Ee, void 0), h(this, re, void 0), i(this, ne).clear(), i(this, xe).clear();
}, ee = function(e) {
  h(this, P, e), rt(i(this, we), Ps, e);
};
function Dt(t) {
  return {
    state: "DISABLED",
    message: "Bridge disabled",
    listenUrl: t,
    startedAt: null,
    lastRequestAt: null,
    projectId: null,
    projectName: null,
    inProcess: !0
  };
}
function Ht(t) {
  return { status: 200, json: t };
}
function j(t, e) {
  return { status: t, json: { error: e } };
}
function ht(t, e) {
  return { status: t, json: { error: e }, close: !0 };
}
var Te, x, be, Y;
class Ft {
  constructor() {
    p(this, Te, 0);
    p(this, x, 0);
    p(this, be, 0);
    p(this, Y);
  }
  setOnChange(e) {
    h(this, Y, e);
  }
  /** Queues `count` requests as pending in one step, so a batch fires one event. */
  incrementPending(e = 1) {
    var s;
    h(this, x, i(this, x) + e), (s = i(this, Y)) == null || s.call(this);
  }
  markSent() {
    var e;
    i(this, x) > 0 && h(this, x, i(this, x) - 1), h(this, Te, i(this, Te) + 1), (e = i(this, Y)) == null || e.call(this);
  }
  markFailed() {
    var e;
    i(this, x) > 0 && h(this, x, i(this, x) - 1), h(this, be, i(this, be) + 1), (e = i(this, Y)) == null || e.call(this);
  }
  reset() {
    var e;
    h(this, Te, 0), h(this, x, 0), h(this, be, 0), (e = i(this, Y)) == null || e.call(this);
  }
  snapshot() {
    return { sent: i(this, Te), pending: i(this, x), failed: i(this, be) };
  }
}
Te = new WeakMap(), x = new WeakMap(), be = new WeakMap(), Y = new WeakMap();
var K, V;
class Vn {
  constructor(e) {
    p(this, K);
    p(this, V, []);
    h(this, K, e);
  }
  add(e, s) {
    const n = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: e,
      message: s
    };
    i(this, V).push(n), i(this, V).length > Mt && i(this, V).splice(0, i(this, V).length - Mt);
    const r = `[Vigolium] ${s}`;
    e === "ERROR" ? i(this, K).console.error(r) : e === "WARN" ? i(this, K).console.warn(r) : i(this, K).console.log(r), rt(i(this, K), Hs, n);
  }
  info(e) {
    this.add("INFO", e);
  }
  warn(e) {
    this.add("WARN", e);
  }
  error(e) {
    this.add("ERROR", e);
  }
  entries() {
    return [...i(this, V)];
  }
  clear() {
    h(this, V, []);
  }
}
K = new WeakMap(), V = new WeakMap();
function Yn(t, e) {
  const s = t.filter((r) => r.enabled);
  if (s.length === 0) return !0;
  let n = Vt(s[0], e);
  for (let r = 1; r < s.length; r++) {
    const o = s[r], a = Vt(o, e);
    n = o.operator === "OR" ? n || a : n && a;
  }
  return n;
}
const Gt = /* @__PURE__ */ new Set(["DOES_NOT_MATCH", "NOT_EQUALS"]);
function Vt(t, e) {
  switch (t.matchType) {
    case "FILE_EXTENSION":
      return pe(t.relationship, t.condition, Kn(e.path), !0);
    case "HTTP_METHOD":
      return pe(t.relationship, t.condition, e.method, !0);
    case "URL":
      return t.relationship === "IS_IN_TARGET_SCOPE" ? e.inScope : t.relationship === "IS_NOT_IN_TARGET_SCOPE" ? !e.inScope : pe(t.relationship, t.condition, e.url, !1);
    case "CONTENT_TYPE":
      return e.contentType === void 0 ? Gt.has(t.relationship) : pe(t.relationship, t.condition, e.contentType, !0, !0);
    case "STATUS_CODE":
      return e.statusCode === void 0 ? Gt.has(t.relationship) : pe(t.relationship, t.condition, String(e.statusCode), !1);
    case "HOST":
      return pe(t.relationship, t.condition, e.host, !0);
    case "REQUEST":
      return Xn(t.relationship, e);
    default:
      return !1;
  }
}
function Kn(t) {
  const e = t.lastIndexOf(".");
  return e < 0 || e >= t.length - 1 || t.indexOf("/", e) >= 0 ? "" : t.slice(e + 1).toLowerCase();
}
function Xn(t, e) {
  const s = e.query.length > 0 || e.hasBody || e.hasCookies;
  switch (t) {
    case "HAS_PARAMETERS":
      return s;
    case "DOES_NOT_HAVE_PARAMETERS":
      return !s;
    case "HAS_BODY":
      return e.hasBody;
    case "DOES_NOT_HAVE_BODY":
      return !e.hasBody;
    default:
      return !1;
  }
}
function pe(t, e, s, n, r = !1) {
  switch (t) {
    case "MATCHES":
      return Yt(e, s, n, r);
    case "DOES_NOT_MATCH":
      return !Yt(e, s, n, r);
    case "EQUALS":
      return n ? s.toLowerCase() === e.toLowerCase() : s === e;
    case "NOT_EQUALS":
      return n ? s.toLowerCase() !== e.toLowerCase() : s !== e;
    default:
      return !1;
  }
}
function Yt(t, e, s, n) {
  const r = zn(n ? t : `^(?:${t})$`, s);
  return r ? r.test(e) : !1;
}
const pt = /* @__PURE__ */ new Map();
function zn(t, e) {
  const s = e ? "i" : "", n = `${s}\0${t}`;
  if (pt.has(n)) return pt.get(n);
  let r;
  try {
    r = new RegExp(t, s);
  } catch {
    r = void 0;
  }
  return pt.set(n, r), r;
}
var Re, X, De, ie;
class Qn {
  constructor(e, s, n, r) {
    p(this, Re);
    p(this, X);
    p(this, De);
    p(this, ie);
    h(this, Re, e), h(this, X, s), h(this, De, n), h(this, ie, r);
  }
  async handle(e, s, n) {
    const r = i(this, De).get();
    if (r.proxyEnabled)
      try {
        const o = e.requests.inScope(s);
        if (r.proxyInScopeOnly && !o) return;
        if (!i(this, Re).isConfigured()) {
          i(this, X).error("[Proxy] Skipped: Vigolium server URL is not configured");
          return;
        }
        if (!Yn(r.proxyFilterRules, Jn(s, n, o))) return;
        const a = s.getUrl(), c = C(s.getRaw().toBytes()), l = C(n.getRaw().toBytes());
        i(this, ie).incrementPending();
        try {
          await i(this, Re).ingest({
            input_mode: "burp_base64",
            url: a,
            http_request_base64: c,
            http_response_base64: l
          }), i(this, ie).markSent(), i(this, X).info("[Proxy] Sent 1 request");
        } catch (d) {
          i(this, ie).markFailed(), i(this, X).error(`[Proxy] Request failed: ${B(d)}`);
        }
      } catch (o) {
        i(this, X).error(`[Proxy] Handler error: ${B(o)}`);
      }
  }
}
Re = new WeakMap(), X = new WeakMap(), De = new WeakMap(), ie = new WeakMap();
function Jn(t, e, s) {
  return {
    method: t.getMethod(),
    url: t.getUrl(),
    path: t.getPath(),
    query: t.getQuery() ?? "",
    host: t.getHost(),
    get hasBody() {
      var n;
      return (((n = t.getBody()) == null ? void 0 : n.toRaw().length) ?? 0) > 0;
    },
    get hasCookies() {
      return (t.getHeader("Cookie") ?? []).length > 0;
    },
    statusCode: e == null ? void 0 : e.getCode(),
    get contentType() {
      var n;
      return (n = e == null ? void 0 : e.getHeader("Content-Type")) == null ? void 0 : n[0];
    },
    inScope: s
  };
}
const ft = "settings", Wn = [
  "serverUrl",
  "apiKey",
  "customModules",
  "scanTimeout",
  "bridgeListenUrl"
], Zn = ["serverUrl", "bridgeListenUrl"];
var z, D, Q, He, Fe, nt, gs;
class jn {
  constructor(e) {
    p(this, nt);
    p(this, z);
    p(this, D, Kt({}));
    /**
     * The object handed to every `get()` caller, rebuilt on write rather than
     * cloned on read. `get()` sits on the proxy interception path, where
     * serialising and reparsing the whole object once per exchange is pure waste.
     */
    p(this, Q);
    p(this, He, []);
    p(this, Fe, !1);
    h(this, z, e), h(this, Q, gt(i(this, D)));
  }
  async init() {
    const e = await i(this, z).meta.db();
    await e.exec(
      `CREATE TABLE IF NOT EXISTS ${ft} (key TEXT PRIMARY KEY, value TEXT NOT NULL)`
    );
    const n = await (await e.prepare(`SELECT key, value FROM ${ft}`)).all(), r = {};
    for (const o of n)
      try {
        r[o.key] = JSON.parse(o.value);
      } catch {
        i(this, z).console.warn(`[Vigolium] Ignoring unreadable setting "${o.key}"`);
      }
    h(this, D, Kt(r)), h(this, Q, gt(i(this, D))), h(this, Fe, !0);
  }
  /**
   * The current settings. Callers must treat the result as read-only: it is one
   * shared object rather than a per-call copy.
   */
  get() {
    return i(this, Q);
  }
  /** Applies a partial update, persists only the changed keys, and notifies listeners. */
  async update(e) {
    i(this, Fe) || await this.init();
    const s = [];
    for (const o of Object.keys(e)) {
      const a = ys(o, e[o]);
      a !== void 0 && JSON.stringify(a) !== JSON.stringify(i(this, D)[o]) && (i(this, D)[o] = a, s.push(o));
    }
    if (s.length === 0) return this.get();
    h(this, Q, gt(i(this, D)));
    const r = await (await i(this, z).meta.db()).prepare(
      `INSERT INTO ${ft} (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    );
    for (const o of s)
      await r.run(o, JSON.stringify(i(this, D)[o]));
    return m(this, nt, gs).call(this), this.get();
  }
  /** The configured scan modules, split once here rather than at each call site. */
  moduleList() {
    return ms(i(this, Q).customModules);
  }
  onChange(e) {
    i(this, He).push(e);
  }
}
z = new WeakMap(), D = new WeakMap(), Q = new WeakMap(), He = new WeakMap(), Fe = new WeakMap(), nt = new WeakSet(), gs = function() {
  const e = this.get();
  for (const s of i(this, He))
    try {
      s(e);
    } catch (n) {
      i(this, z).console.error(`[Vigolium] settings listener failed: ${B(n)}`);
    }
};
function ms(t) {
  return t.split(",").map((e) => e.trim()).filter(Boolean);
}
function St(t) {
  return t.trim() || null;
}
function gt(t) {
  return JSON.parse(JSON.stringify(t));
}
function ys(t, e) {
  if (typeof e != "string" || !Wn.includes(t)) return e;
  const s = e.trim();
  return Zn.includes(t) ? s.replace(/\/+$/, "") : s;
}
function Kt(t) {
  const e = Ms;
  return {
    serverUrl: $e(t, "serverUrl", e.serverUrl),
    apiKey: $e(t, "apiKey", e.apiKey),
    customModules: $e(t, "customModules", e.customModules),
    scanTimeout: $e(t, "scanTimeout", e.scanTimeout),
    // Deliberately not restored from disk: forwarding restarts off on every
    // load, matching the Burp extension, so a reload never silently resumes
    // shipping traffic to a scanner.
    proxyEnabled: !1,
    proxyInScopeOnly: ge(t, "proxyInScopeOnly", e.proxyInScopeOnly),
    proxyFilterRules: tr(t.proxyFilterRules),
    snapshotAutoEnabled: ge(t, "snapshotAutoEnabled", e.snapshotAutoEnabled),
    snapshotIntervalMinutes: er(t, "snapshotIntervalMinutes", e.snapshotIntervalMinutes, 1, 1440),
    snapshotInScopeOnly: ge(t, "snapshotInScopeOnly", e.snapshotInScopeOnly),
    bridgeEnabled: ge(t, "bridgeEnabled", e.bridgeEnabled),
    bridgeListenUrl: $e(t, "bridgeListenUrl", e.bridgeListenUrl),
    bridgeInScopeOnly: ge(t, "bridgeInScopeOnly", e.bridgeInScopeOnly)
  };
}
function $e(t, e, s) {
  return ys(e, u(t, e, s));
}
function er(t, e, s, n, r) {
  return Math.min(r, Math.max(n, Me(t, e, s)));
}
function tr(t) {
  if (!Array.isArray(t)) return qs.map((s) => ({ ...s }));
  const e = [];
  for (const s of t) {
    if (typeof s != "object" || s === null) continue;
    const n = s;
    typeof n.matchType != "string" || typeof n.relationship != "string" || $s(n.matchType, n.relationship) && e.push({
      enabled: n.enabled !== !1,
      operator: n.operator === "AND" || n.operator === "OR" ? n.operator : null,
      matchType: n.matchType,
      relationship: n.relationship,
      condition: typeof n.condition == "string" ? n.condition : ""
    });
  }
  return e;
}
const sr = 100, _s = _t;
function nr(t) {
  const e = [];
  let s = 0;
  for (; s < t.length; ) {
    const n = [];
    let r = 0;
    for (; s < t.length && n.length < sr; ) {
      const o = t[s];
      if (n.length > 0 && r + o.rawBytes > _s) break;
      n.push(o), r += o.rawBytes, s++;
    }
    e.push(n);
  }
  return e;
}
var ae, J, ce, W, Ae, Ge, Be, ue, le, M, Ss, ws, qe;
class rr {
  constructor(e, s, n, r) {
    p(this, M);
    p(this, ae);
    p(this, J);
    p(this, ce);
    p(this, W);
    p(this, Ae, /* @__PURE__ */ new Map());
    p(this, Ge);
    p(this, Be, !1);
    p(this, ue);
    p(this, le, We());
    h(this, ae, e), h(this, J, s), h(this, ce, n), h(this, W, r);
  }
  status() {
    return { ...i(this, le) };
  }
  start() {
    this.reschedule();
  }
  reschedule() {
    i(this, ue) !== void 0 && (clearInterval(i(this, ue)), h(this, ue, void 0));
    const e = i(this, J).get();
    if (!e.snapshotAutoEnabled) {
      m(this, M, qe).call(this, {
        ...i(this, le),
        state: "DISABLED",
        message: "Automatic snapshots disabled",
        nextRunAt: null
      });
      return;
    }
    h(this, ue, setInterval(
      () => void this.snapshotNow("Auto"),
      e.snapshotIntervalMinutes * 6e4
    )), this.snapshotNow("Auto");
  }
  async snapshotNow(e) {
    if (i(this, Be))
      return i(this, W).warn("[Sitemap Snapshot] Skipped: another snapshot is running"), this.status();
    h(this, Be, !0), m(this, M, qe).call(this, {
      ...We(),
      state: "RUNNING",
      message: "Reading the Caido Sitemap…",
      completedAt: i(this, le).completedAt
    });
    try {
      if (!i(this, ce).isConfigured())
        throw new Error("Vigolium server URL is not configured");
      await m(this, M, ws).call(this);
      const s = i(this, J).get(), { pending: n, discovered: r, oversized: o } = await m(this, M, Ss).call(this, s.snapshotInScopeOnly);
      let a = 0, c = 0, l = 0, d = o, f = 0;
      const g = ar(), S = (/* @__PURE__ */ new Date()).toISOString(), w = nr(n);
      for (let A = 0; A < w.length; A++) {
        const F = w[A], N = F.map(ir), $ = await i(this, ce).snapshotSitemap({
          snapshot_id: g,
          chunk_index: A,
          final_chunk: A === w.length - 1,
          captured_at: S,
          records: N
        });
        if (f += N.length, a += $.inserted, c += $.updated, l += $.unchanged, d += $.skipped, $.skipped === 0)
          for (const Ie of F)
            i(this, Ae).set(Ie.identityFingerprint, Ie.contentFingerprint);
      }
      const T = {
        ...We(),
        state: "SUCCESS",
        message: n.length === 0 && o === 0 ? "Sitemap already synchronized" : "Sitemap snapshot completed",
        discovered: r,
        uploaded: f,
        inserted: a,
        updated: c,
        unchanged: l,
        failed: d,
        completedAt: (/* @__PURE__ */ new Date()).toISOString(),
        nextRunAt: Xt(i(this, J).get())
      };
      return m(this, M, qe).call(this, T), i(this, W).info(
        `[Sitemap Snapshot:${e}] discovered=${r} uploaded=${f} inserted=${a} updated=${c} unchanged=${l} failed=${d}`
      ), T;
    } catch (s) {
      const n = B(s), r = {
        ...We(),
        state: "FAILED",
        message: `Snapshot failed: ${n}`,
        failed: 1,
        completedAt: (/* @__PURE__ */ new Date()).toISOString(),
        nextRunAt: Xt(i(this, J).get())
      };
      return m(this, M, qe).call(this, r), i(this, W).error(`[Sitemap Snapshot:${e}] ${n}`), r;
    } finally {
      h(this, Be, !1);
    }
  }
}
ae = new WeakMap(), J = new WeakMap(), ce = new WeakMap(), W = new WeakMap(), Ae = new WeakMap(), Ge = new WeakMap(), Be = new WeakMap(), ue = new WeakMap(), le = new WeakMap(), M = new WeakSet(), Ss = async function(e) {
  const s = [];
  let n = 0, r = 0, o;
  for (; ; ) {
    let a = i(this, ae).requests.query().first(es).ascending("req", "created_at");
    o && (a = a.after(o));
    const c = await a.execute();
    if (c.items.length === 0) break;
    for (const l of c.items) {
      if (e && !i(this, ae).requests.inScope(l.request)) continue;
      n++;
      const d = or(l.request, l.response);
      if (!d) {
        r++, i(this, W).warn(`[Sitemap Snapshot] Skipped oversized record: ${l.request.getUrl()}`);
        continue;
      }
      i(this, Ae).get(d.identityFingerprint) !== d.contentFingerprint && s.push(d);
    }
    if (o = c.pageInfo.endCursor, !c.pageInfo.hasNextPage) break;
  }
  return { pending: s, discovered: n, oversized: r };
}, ws = async function() {
  const e = await i(this, ce).destinationIdentity();
  i(this, Ge) !== e && (i(this, Ae).clear(), h(this, Ge, e));
}, qe = function(e) {
  h(this, le, e), rt(i(this, ae), xs, e);
};
function Xt(t) {
  return t.snapshotAutoEnabled ? new Date(Date.now() + t.snapshotIntervalMinutes * 6e4).toISOString() : null;
}
const zt = L.from([0]);
function or(t, e) {
  const s = t.getRaw().toBytes(), n = e ? e.getRaw().toBytes() : new Uint8Array(0), r = s.length + n.length;
  if (r > _s) return;
  const o = t.getUrl(), a = et("sha256").update(L.from(o, "utf-8")).update(zt).update(Ce(s)).digest("hex"), c = et("sha256").update(L.from(a, "ascii")).update(zt).update(Ce(n)).digest("hex");
  return { url: o, requestBytes: s, responseBytes: n, identityFingerprint: a, contentFingerprint: c, rawBytes: r };
}
function ir(t) {
  const e = {
    url: t.url,
    request_base64: C(t.requestBytes),
    identity_fingerprint: t.identityFingerprint,
    content_fingerprint: t.contentFingerprint
  };
  return t.responseBytes.length > 0 && (e.response_base64 = C(t.responseBytes)), e;
}
function We() {
  return {
    state: "IDLE",
    message: "Idle",
    discovered: 0,
    uploaded: 0,
    inserted: 0,
    updated: 0,
    unchanged: 0,
    failed: 0,
    completedAt: null,
    nextRunAt: null
  };
}
function ar() {
  const t = () => Math.random().toString(16).slice(2, 10);
  return `${t()}-${t()}-${t()}-${t()}`;
}
const Qt = 2, cr = [1e3, 2e3];
class me extends Error {
  constructor(s, n) {
    super(n);
    at(this, "statusCode");
    this.name = "VigoliumApiError", this.statusCode = s;
  }
}
var de, _, E;
class ur {
  constructor(e) {
    p(this, _);
    p(this, de);
    h(this, de, e);
  }
  // The settings store canonicalises `serverUrl` and `apiKey` on the way in, so
  // nothing here trims or strips a trailing slash. That is what keeps the
  // identity below hashing exactly the credentials requests are sent with -
  // trimming at some call sites and not others silently split the two apart.
  isConfigured() {
    return i(this, de).call(this).serverUrl.length > 0;
  }
  /** Stable identity of "where records are being sent", for snapshot cache invalidation. */
  async destinationIdentity() {
    const { serverUrl: e, apiKey: s } = i(this, de).call(this);
    return et("sha256").update(`${e}\0${s}`).digest("hex");
  }
  async health() {
    const e = Date.now(), s = await m(this, _, E).call(this, "GET", "/health"), n = I(s);
    return {
      status: u(n, "status", "unknown"),
      version: u(n, "version", "unknown"),
      latencyMs: Date.now() - e
    };
  }
  async ingest(e) {
    await m(this, _, E).call(this, "POST", "/api/ingest-http", e);
  }
  async scan(e) {
    const s = await m(this, _, E).call(this, "POST", "/api/scan-request", e), n = I(s);
    return {
      scanId: u(n, "scan_id", ""),
      message: u(n, "message", "")
    };
  }
  async agentScan(e) {
    return m(this, _, E).call(this, "POST", "/api/agent/run/swarm", e);
  }
  async scanAllRecords(e, s) {
    const n = {};
    e.length > 0 && (n.modules = e), s && s.trim() && (n.timeout = s.trim());
    const r = await m(this, _, E).call(this, "POST", "/api/scan-all-records", n), o = I(r);
    return u(o, "scan_uuid", "") || u(o, "scan_id", "");
  }
  async scanRecords(e, s) {
    const n = { record_uuids: e };
    s.length > 0 && (n.enable_modules = s);
    const r = await m(this, _, E).call(this, "POST", "/api/scan-records", n);
    return u(I(r), "scan_id", "");
  }
  async snapshotSitemap(e) {
    const s = await m(this, _, E).call(this, "POST", "/api/burp/sitemap/snapshot", e), n = I(s);
    return {
      inserted: b(n, "inserted", 0),
      updated: b(n, "updated", 0),
      unchanged: b(n, "unchanged", 0),
      skipped: b(n, "skipped", 0)
    };
  }
  // ---------------------------------------------------------------- Findings
  async findings(e) {
    const s = fe("/api/findings", {
      limit: e.limit,
      offset: e.offset,
      domain: e.domain,
      severity: e.severity,
      module_type: e.moduleType,
      finding_source: e.findingSource,
      scan_id: e.scanId,
      repo_name: e.repoName,
      search: e.search,
      sort: e.sort,
      order: e.order
    }), n = I(await m(this, _, E).call(this, "GET", s));
    return Ze(n, Jt, e.limit, e.offset);
  }
  async findingById(e) {
    return Jt(I(await m(this, _, E).call(this, "GET", `/api/findings/${e}`)));
  }
  async deleteFinding(e) {
    await m(this, _, E).call(this, "DELETE", `/api/findings/${e}`);
  }
  // ------------------------------------------------------------ HTTP records
  async httpRecords(e) {
    const s = fe("/api/http-records", {
      limit: e.limit,
      offset: e.offset,
      domain: e.domain,
      method: e.method,
      path: e.path,
      status_code: e.statusCode,
      content_type: e.contentType,
      search: e.search,
      source: e.source,
      min_risk: e.minRisk,
      sort: e.sort,
      order: e.order
    }), n = I(await m(this, _, E).call(this, "GET", s));
    return Ze(n, Wt, e.limit, e.offset);
  }
  async httpRecordByUuid(e) {
    return Wt(I(await m(this, _, E).call(this, "GET", `/api/http-records/${e}`)));
  }
  async deleteHttpRecord(e) {
    await m(this, _, E).call(this, "DELETE", `/api/http-records/${e}`);
  }
  // ------------------------------------------------------------------- Scans
  async scans(e, s) {
    const n = I(await m(this, _, E).call(this, "GET", fe("/api/scans", { limit: e, offset: s })));
    return Ze(n, dr, e, s);
  }
  async stopScan(e) {
    await m(this, _, E).call(this, "POST", `/api/scans/${e}/stop`, {});
  }
  async pauseScan(e) {
    await m(this, _, E).call(this, "POST", `/api/scans/${e}/pause`, {});
  }
  async resumeScan(e) {
    await m(this, _, E).call(this, "POST", `/api/scans/${e}/resume`, {});
  }
  async deleteScan(e) {
    await m(this, _, E).call(this, "DELETE", `/api/scans/${e}`);
  }
  async scanLogs(e, s, n, r, o) {
    const a = fe(`/api/scans/${e}/logs`, { limit: r, offset: o, level: s, phase: n }), c = I(await m(this, _, E).call(this, "GET", a)), l = Es(c.logs).map((d) => ({
      id: b(d, "id", 0),
      scanUuid: u(d, "scan_uuid", ""),
      level: u(d, "level", ""),
      phase: u(d, "phase", ""),
      message: u(d, "message", ""),
      createdAt: u(d, "created_at", "")
    }));
    return { logs: l, total: b(c, "total", l.length) };
  }
  // ---------------------------------------------------------- Agent sessions
  async agentSessions(e, s, n) {
    const r = fe("/api/agent/sessions", { limit: s, offset: n, mode: e }), o = I(await m(this, _, E).call(this, "GET", r));
    return Ze(o, hr, s, n);
  }
  async agentSessionLogs(e) {
    return m(this, _, E).call(this, "GET", fe(`/api/agent/sessions/${e}/logs`, { strip: 1 }));
  }
}
de = new WeakMap(), _ = new WeakSet(), E = async function(e, s, n) {
  const { serverUrl: r, apiKey: o } = i(this, de).call(this);
  if (!r) throw new me(0, "Vigolium server URL is not configured");
  const a = {
    // Set on every call rather than only on the ingest path: it is advisory
    // (the server allowlists it and falls back to `ingest-server`), and a
    // per-endpoint opt-in is the kind of thing a new dispatch route silently
    // forgets. Without it, traffic pushed from Caido is indistinguishable
    // from traffic pushed by curl.
    [Us]: ks
  };
  o && (a.Authorization = `Bearer ${o}`);
  let c = { method: e, headers: a };
  n !== void 0 && (a["Content-Type"] = "application/json", c = { ...c, body: JSON.stringify(n) });
  let l = "unknown error";
  for (let d = 0; d <= Qt; d++) {
    d > 0 && await lr(cr[d - 1] ?? 2e3);
    try {
      const f = await Is(`${r}${s}`, c), g = await f.text();
      if (f.ok) return g;
      if (f.status >= 400 && f.status < 500)
        throw new me(
          f.status,
          `API error: ${f.status} - ${g.trim()}`
        );
      l = `Server error: ${f.status} - ${g.trim()}`;
    } catch (f) {
      if (f instanceof me) throw f;
      l = B(f);
    }
  }
  throw new me(0, `Request failed after ${Qt} retries: ${l}`);
};
function lr(t) {
  return new Promise((e) => setTimeout(e, t));
}
function I(t) {
  if (!t.trim()) return {};
  try {
    const e = JSON.parse(t);
    return typeof e == "object" && e !== null ? e : {};
  } catch {
    return {};
  }
}
function Es(t) {
  return Array.isArray(t) ? t.filter((e) => typeof e == "object" && e !== null) : [];
}
function Ze(t, e, s, n) {
  return {
    data: Es(t.data).map(e),
    total: b(t, "total", 0),
    limit: b(t, "limit", s),
    offset: b(t, "offset", n),
    hasMore: ge(t, "has_more", !1)
  };
}
function Jt(t) {
  return {
    id: b(t, "id", 0),
    httpRecordUuids: te(t, "http_record_uuids"),
    scanUuid: u(t, "scan_uuid", ""),
    moduleId: u(t, "module_id", ""),
    moduleName: u(t, "module_name", ""),
    description: u(t, "description", ""),
    severity: Ls(u(t, "severity", "")),
    confidence: u(t, "confidence", ""),
    tags: te(t, "tags"),
    matchedAt: te(t, "matched_at"),
    foundAt: u(t, "found_at", ""),
    request: u(t, "request", ""),
    response: u(t, "response", ""),
    moduleType: u(t, "module_type", ""),
    moduleShort: u(t, "module_short", ""),
    findingSource: u(t, "finding_source", ""),
    sourceFile: u(t, "source_file", ""),
    repoName: u(t, "repo_name", ""),
    extractedResults: te(t, "extracted_results"),
    additionalEvidence: te(t, "additional_evidence"),
    findingHash: u(t, "finding_hash", ""),
    createdAt: u(t, "created_at", "")
  };
}
function Wt(t) {
  return {
    uuid: u(t, "uuid", ""),
    scheme: u(t, "scheme", ""),
    hostname: u(t, "hostname", ""),
    port: b(t, "port", 0),
    method: u(t, "method", ""),
    path: u(t, "path", ""),
    url: u(t, "url", ""),
    statusCode: b(t, "status_code", 0),
    statusPhrase: u(t, "status_phrase", ""),
    responseHttpVersion: u(t, "response_http_version", ""),
    responseContentLength: b(t, "response_content_length", 0),
    responseTimeMs: b(t, "response_time_ms", 0),
    sentAt: u(t, "sent_at", ""),
    createdAt: u(t, "created_at", ""),
    source: u(t, "source", ""),
    riskScore: b(t, "risk_score", 0),
    // Left base64-encoded: the frontend renders them through Caido's editors,
    // and decoding here would force a lossy string round trip.
    rawRequestBase64: u(t, "raw_request", ""),
    rawResponseBase64: u(t, "raw_response", "")
  };
}
function dr(t) {
  return {
    uuid: u(t, "uuid", ""),
    name: u(t, "name", ""),
    status: u(t, "status", ""),
    scanSource: u(t, "scan_source", ""),
    scanMode: u(t, "scan_mode", ""),
    sourceType: u(t, "source_type", ""),
    modules: u(t, "modules", ""),
    totalFindings: b(t, "total_findings", 0),
    processedCount: b(t, "processed_count", 0),
    startedAt: u(t, "started_at", ""),
    finishedAt: u(t, "finished_at", ""),
    createdAt: u(t, "created_at", "")
  };
}
function hr(t) {
  return {
    uuid: u(t, "uuid", ""),
    mode: u(t, "mode", ""),
    status: u(t, "status", ""),
    agentName: u(t, "agent_name", ""),
    templateId: u(t, "template_id", ""),
    targetUrl: u(t, "target_url", ""),
    inputType: u(t, "input_type", ""),
    currentPhase: u(t, "current_phase", ""),
    phasesRun: te(t, "phases_run"),
    findingCount: b(t, "finding_count", 0),
    recordCount: b(t, "record_count", 0),
    savedCount: b(t, "saved_count", 0),
    durationMs: b(t, "duration_ms", 0),
    startedAt: u(t, "started_at", ""),
    completedAt: u(t, "completed_at", ""),
    createdAt: u(t, "created_at", "")
  };
}
function fe(t, e) {
  const s = [];
  for (const [n, r] of Object.entries(e)) {
    if (r == null) continue;
    const o = String(r);
    o.trim() && s.push(`${encodeURIComponent(n)}=${encodeURIComponent(o)}`);
  }
  return s.length > 0 ? `${t}?${s.join("&")}` : t;
}
const pr = 8;
async function fr(t, e) {
  const s = new Array(e.length);
  let n = 0;
  const r = async () => {
    for (let a = n++; a < e.length; a = n++) {
      const c = await t.requests.get(e[a]);
      c != null && c.request && (s[a] = {
        url: c.request.getUrl(),
        requestBytes: c.request.getRaw().toBytes(),
        responseBytes: c.response ? c.response.getRaw().toBytes() : null
      });
    }
  }, o = Math.min(pr, e.length);
  return await Promise.all(Array.from({ length: o }, r)), s.filter((a) => a !== void 0);
}
var Ve, Z, H, Ye, Ke, Xe, v, wt, Et, Ts, bs;
class gr {
  constructor(e, s, n, r, o, a) {
    p(this, v);
    p(this, Ve);
    p(this, Z);
    p(this, H);
    p(this, Ye);
    p(this, Ke);
    p(this, Xe);
    h(this, Ve, e), h(this, Z, s), h(this, H, n), h(this, Ye, r), h(this, Ke, o), h(this, Xe, a);
  }
  /** Resolves Caido request IDs then dispatches - the row-selection entry point. */
  async dispatchIds(e, s, n) {
    return m(this, v, wt).call(this, n) ? m(this, v, Et).call(this, e, await fr(i(this, Ve), s), n) : 0;
  }
  /**
   * Dispatches requests carried as raw text - the request/response editor entry
   * point, where the message may be an unsaved draft with no id.
   */
  async dispatchRaw(e, s, n) {
    if (!m(this, v, wt).call(this, n)) return 0;
    const r = s.filter((o) => o.request.length > 0).map((o) => ({
      url: o.url,
      requestBytes: Lt(o.request),
      responseBytes: o.response ? Lt(o.response) : null
    }));
    return m(this, v, Et).call(this, e, r, n);
  }
}
Ve = new WeakMap(), Z = new WeakMap(), H = new WeakMap(), Ye = new WeakMap(), Ke = new WeakMap(), Xe = new WeakMap(), v = new WeakSet(), wt = function(e) {
  return i(this, Z).isConfigured() ? !0 : (i(this, H).error(`[${e}] Skipped: Vigolium server URL is not configured`), !1);
}, Et = async function(e, s, n) {
  var c, l, d, f;
  if (s.length === 0)
    return i(this, H).warn(`[${n}] Nothing to send: no request bytes available`), 0;
  const r = m(this, v, Ts).call(this, e), o = `[${n}:${r.label}]`;
  (c = r.counters) == null || c.incrementPending(s.length);
  let a = 0;
  for (const g of s) {
    if (m(this, v, bs).call(this, g, o)) {
      (l = r.counters) == null || l.markFailed();
      continue;
    }
    try {
      const S = await r.send(g);
      (d = r.counters) == null || d.markSent(), a++, S && i(this, H).info(`${o} ${S}`);
    } catch (S) {
      (f = r.counters) == null || f.markFailed();
      const w = r.describeError(S);
      i(this, H)[w.level](`${o} ${w.message}`);
    }
  }
  return i(this, H).info(`${o} Sent ${a}/${s.length} requests`), a;
}, Ts = function(e) {
  switch (e) {
    case "ingest":
      return {
        label: "Ingest",
        counters: i(this, Ke),
        send: async (s) => {
          await i(this, Z).ingest({
            input_mode: "burp_base64",
            url: s.url,
            http_request_base64: C(s.requestBytes),
            http_response_base64: s.responseBytes ? C(s.responseBytes) : null
          });
        },
        describeError: (s) => ({
          level: "error",
          message: `Failed to send request: ${B(s)}`
        })
      };
    case "scan": {
      const s = i(this, Ye).get(), n = St(s.customModules), r = St(s.scanTimeout);
      return {
        label: "Scan",
        counters: i(this, Xe),
        send: async (o) => {
          const a = await i(this, Z).scan({
            url: o.url,
            http_request_base64: C(o.requestBytes),
            http_response_base64: o.responseBytes ? C(o.responseBytes) : null,
            modules: n,
            timeout: r
          });
          return `${a.message} (scan_id: ${a.scanId})`;
        },
        describeError: (o) => o instanceof me && o.statusCode === 409 ? { level: "warn", message: "A scan is already running" } : { level: "error", message: `Scan failed: ${B(o)}` }
      };
    }
    case "agentScan":
      return {
        label: "AgentScan",
        counters: void 0,
        send: async (s) => `Started: ${await i(this, Z).agentScan({
          url: s.url,
          http_request_base64: C(s.requestBytes),
          http_response_base64: s.responseBytes ? C(s.responseBytes) : null,
          save_findings: !0,
          mode: "balanced"
        })}`,
        describeError: (s) => ({
          level: "error",
          message: `Agent scan failed: ${B(s)}`
        })
      };
  }
}, /**
 * Reports an over-limit record instead of letting the server answer 413.
 *
 * The raw status code says nothing about which record was at fault or by how
 * much, which makes a partial batch failure very hard to act on.
 */
bs = function(e, s) {
  var r;
  const n = e.requestBytes.length + (((r = e.responseBytes) == null ? void 0 : r.length) ?? 0);
  return n <= _t ? !1 : (i(this, H).warn(
    `${s} Skipped ${e.url}: ${Nt(n)} exceeds the ${Nt(_t)} the server accepts once base64-encoded`
  ), !0);
};
let Tt;
function y() {
  if (!Tt) throw new Error("Vigolium backend is not initialised");
  return Tt;
}
async function mr() {
  return y().settings.get();
}
async function yr(t, e) {
  return y().settings.update(e);
}
async function _r() {
  try {
    return { ok: !0, health: await y().api.health() };
  } catch (t) {
    return { ok: !1, message: B(t) };
  }
}
async function Sr() {
  return y().bridge.testConnection();
}
async function wr() {
  const { bridge: t } = y();
  return await t.restart(), t.status();
}
async function Er() {
  return y().bridge.status();
}
async function Tr() {
  return y().snapshot.status();
}
async function br(t, e) {
  return y().snapshot.snapshotNow(e || "Manual");
}
async function Rr() {
  const { snapshot: t } = y();
  return t.reschedule(), t.status();
}
async function Rs() {
  const { ingestCounters: t, scanCounters: e } = y();
  return { ingest: t.snapshot(), scan: e.snapshot() };
}
async function Ar() {
  const { ingestCounters: t, scanCounters: e } = y();
  return t.reset(), e.reset(), Rs();
}
async function Br() {
  return y().log.entries();
}
async function Cr() {
  y().log.clear();
}
async function Or(t, e, s, n) {
  return y().dispatch.dispatchIds(e, s, n);
}
async function Ir(t, e, s, n) {
  return y().dispatch.dispatchRaw(e, s, n);
}
async function vr(t, e) {
  return y().api.findings(e);
}
async function $r(t, e) {
  return y().api.findingById(e);
}
async function qr(t, e) {
  return y().api.deleteFinding(e);
}
async function Mr(t, e) {
  return y().api.httpRecords(e);
}
async function Lr(t, e) {
  return y().api.httpRecordByUuid(e);
}
async function Nr(t, e) {
  return y().api.deleteHttpRecord(e);
}
async function Ur(t, e) {
  const { api: s, settings: n } = y();
  return s.scanRecords([e], n.moduleList());
}
async function kr(t, e, s) {
  return y().api.scanAllRecords(ms(e), St(s));
}
async function Pr(t, e, s) {
  return y().api.scans(e, s);
}
async function xr(t, e, s, n, r, o) {
  return y().api.scanLogs(e, s || void 0, n || void 0, r, o);
}
async function Dr(t, e) {
  return y().api.pauseScan(e);
}
async function Hr(t, e) {
  return y().api.resumeScan(e);
}
async function Fr(t, e) {
  return y().api.stopScan(e);
}
async function Gr(t, e) {
  return y().api.deleteScan(e);
}
async function Vr(t, e, s, n) {
  return y().api.agentSessions(e || void 0, s, n);
}
async function Yr(t, e) {
  return y().api.agentSessionLogs(e);
}
async function Kr(t, e) {
  const { api: s, log: n } = y(), r = await s.httpRecordByUuid(e);
  if (!r.rawRequestBase64)
    throw new me(0, "Record has no raw request to replay");
  const o = await Ct(
    t,
    {
      url: r.url,
      requestBytes: yt(r.rawRequestBase64),
      responseBytes: r.rawResponseBase64 ? yt(r.rawResponseBase64) : null,
      roundtripTimeMs: r.responseTimeMs
    },
    `vigolium-${r.uuid.slice(0, 8)}`
  );
  return n.info(`[HTTP Records] Opened Replay session for ${r.url}`), o;
}
const Xr = {
  getSettings: mr,
  updateSettings: yr,
  testServerConnection: _r,
  testBridgeConnection: Sr,
  restartBridge: wr,
  getBridgeStatus: Er,
  getSnapshotStatus: Tr,
  snapshotNow: br,
  rescheduleSnapshot: Rr,
  getRequestStats: Rs,
  resetRequestStats: Ar,
  getLogs: Br,
  clearLogs: Cr,
  dispatch: Or,
  dispatchRaw: Ir,
  findings: vr,
  findingById: $r,
  deleteFinding: qr,
  httpRecords: Mr,
  httpRecordByUuid: Lr,
  deleteHttpRecord: Nr,
  scanRecord: Ur,
  scanAllRecords: kr,
  scans: Pr,
  scanLogs: xr,
  pauseScan: Dr,
  resumeScan: Hr,
  stopScan: Fr,
  deleteScan: Gr,
  agentSessions: Vr,
  agentSessionLogs: Yr,
  sendRecordToReplay: Kr
};
async function eo(t) {
  const e = new jn(t);
  await e.init();
  const s = new Vn(t), n = new ur(() => {
    const T = e.get();
    return { serverUrl: T.serverUrl, apiKey: T.apiKey };
  }), r = new Ft(), o = new Ft(), a = () => rt(t, Ds, {
    ingest: r.snapshot(),
    scan: o.snapshot()
  });
  r.setOnChange(a), o.setOnChange(a);
  const c = new Gn(t, e, s), l = new rr(t, e, n, s), d = new gr(
    t,
    n,
    s,
    e,
    r,
    o
  ), f = new Qn(n, s, e, r);
  Tt = {
    settings: e,
    log: s,
    api: n,
    bridge: c,
    snapshot: l,
    dispatch: d,
    ingestCounters: r,
    scanCounters: o
  };
  for (const [T, A] of Object.entries(Xr))
    t.api.register(T, A);
  t.events.onInterceptResponse(
    (T, A, F) => f.handle(T, A, F)
  ), t.events.onProjectChange((T, A) => {
    c.onProjectChange(A ? { id: A.getId(), name: A.getName() } : null);
  });
  let g = Zt(e.get()), S = jt(e.get());
  e.onChange((T) => {
    const A = Zt(T);
    A !== g && (g = A, c.restart());
    const F = jt(T);
    F !== S && (S = F, l.reschedule());
  });
  const [w] = await Promise.all([t.projects.getCurrent(), c.restart()]);
  c.onProjectChange(w ? { id: w.getId(), name: w.getName() } : null), l.start(), s.info(`Plugin v${t.meta.version()} loaded successfully.`);
}
function Zt(t) {
  return `${t.bridgeEnabled}|${t.bridgeListenUrl}`;
}
function jt(t) {
  return `${t.snapshotAutoEnabled}|${t.snapshotIntervalMinutes}`;
}
export {
  eo as init
};
