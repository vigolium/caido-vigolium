var Os = Object.defineProperty;
var qt = (t) => {
  throw TypeError(t);
};
var Cs = (t, e, s) => e in t ? Os(t, e, { enumerable: !0, configurable: !0, writable: !0, value: s }) : t[e] = s;
var ct = (t, e, s) => Cs(t, typeof e != "symbol" ? e + "" : e, s), ut = (t, e, s) => e.has(t) || qt("Cannot " + s);
var a = (t, e, s) => (ut(t, e, "read from private field"), s ? s.call(t) : e.get(t)), p = (t, e, s) => e.has(t) ? qt("Cannot add the same private member more than once") : e instanceof WeakSet ? e.add(t) : e.set(t, s), h = (t, e, s, n) => (ut(t, e, "write to private field"), n ? n.call(t, s) : e.set(t, s), s), m = (t, e, s) => (ut(t, e, "access private method"), s);
import { RequestSpecRaw as Is } from "caido:utils";
import { Buffer as v } from "buffer";
import { createHash as et } from "crypto";
import { createServer as vs } from "net";
import { fetch as $s } from "caido:http";
const fe = ["MATCHES", "DOES_NOT_MATCH", "EQUALS", "NOT_EQUALS"], qs = {
  FILE_EXTENSION: fe,
  HTTP_METHOD: fe,
  URL: [...fe, "IS_IN_TARGET_SCOPE", "IS_NOT_IN_TARGET_SCOPE"],
  CONTENT_TYPE: fe,
  STATUS_CODE: fe,
  HOST: fe,
  REQUEST: ["HAS_PARAMETERS", "HAS_BODY", "DOES_NOT_HAVE_PARAMETERS", "DOES_NOT_HAVE_BODY"]
};
function Ls(t, e) {
  const s = qs[t];
  return s !== void 0 && s.includes(e);
}
const Ms = [
  {
    enabled: !0,
    operator: null,
    matchType: "FILE_EXTENSION",
    relationship: "DOES_NOT_MATCH",
    condition: "woff|woff2|ttf|eot|otf|mp4|webm|ogg|mkv|flv|avi|mov|wmv|m3u8|svg|jpg|jpeg|png|gif|bmp|webp|ico|css|js|pdf|zip|exe|gz|rar|mp3"
  },
  {
    enabled: !0,
    operator: "AND",
    matchType: "HTTP_METHOD",
    relationship: "DOES_NOT_MATCH",
    condition: "OPTIONS|HEAD"
  }
], Ns = {
  serverUrl: "http://127.0.0.1:9002",
  apiKey: "",
  customModules: "",
  scanTimeout: "",
  proxyInScopeOnly: !0,
  snapshotAutoEnabled: !1,
  snapshotIntervalMinutes: 5,
  snapshotInScopeOnly: !1,
  // On by default so `--burp-bridge-url` / `--caido-bridge-url` work as soon as
  // the plugin is installed. The listener is unauthenticated, so it stays bound
  // to loopback only and still validates Host/Origin on every request; turn it
  // off in the Bridge tab if you would rather opt in per session.
  bridgeEnabled: !0,
  bridgeListenUrl: "http://127.0.0.1:9009",
  bridgeInScopeOnly: !1
};
function Us(t) {
  switch ((t ?? "").toLowerCase()) {
    case "critical":
      return "CRITICAL";
    case "high":
      return "HIGH";
    case "medium":
    case "med":
      return "MEDIUM";
    case "low":
      return "LOW";
    case "suspect":
      return "SUSPECT";
    default:
      return "INFO";
  }
}
const Lt = 2e3, yt = 30, ks = "vigolium-burp-bridge", Rt = "vigolium-caido-bridge", Ps = "X-Vigolium-Source", xs = "caido", Hs = "bridge-status", Ds = "snapshot-status", Fs = "request-stats", Gs = "log";
function B(t) {
  return t instanceof Error ? t.message : String(t);
}
function Ce(t) {
  return v.from(t.buffer, t.byteOffset, t.byteLength);
}
function O(t) {
  return Ce(t).toString("base64");
}
function _t(t) {
  return new Uint8Array(v.from(t, "base64"));
}
function Vs(t, e) {
  const s = t.trim();
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(s) || s.length % 4 !== 0)
    throw new Error(`${e} is not valid base64`);
  return _t(s);
}
function ze(t) {
  return et("sha256").update(Ce(t)).digest("hex");
}
function pe(t, e) {
  const s = e !== void 0 ? t.subarray(0, e) : t;
  return Ce(s).toString("latin1");
}
function Mt(t) {
  return new Uint8Array(v.from(t, "latin1"));
}
function Nt(t) {
  return new Uint8Array(v.from(t, "utf8"));
}
const Ys = 4 * 1024 * 1024, Ks = 4 / 3, Xs = 256 * 1024, wt = Math.floor(
  (Ys - Xs) / Ks
), ts = 500;
function Ut(t) {
  return t >= 1024 * 1024 ? `${(t / (1024 * 1024)).toFixed(1)} MB` : `${Math.round(t / 1024)} KB`;
}
function At(t) {
  return t >= 1024 * 1024 ? `${Math.floor(t / (1024 * 1024))} MiB` : `${Math.floor(t / 1024)} KiB`;
}
function ss(t) {
  const e = pe(t, 8192), s = e.search(/\r?\n/), r = (s >= 0 ? e.slice(0, s) : e).split(" "), o = (r[0] ?? "GET").trim() || "GET", i = (r[1] ?? "/").trim() || "/", c = i.indexOf("?");
  return c < 0 ? { method: o, path: i, query: "" } : {
    method: o,
    path: i.slice(0, c),
    query: i.slice(c + 1)
  };
}
function zs(t) {
  const e = pe(t, 256), s = /^HTTP\/\d(?:\.\d)?\s+(\d{3})/.exec(e);
  return s != null && s[1] ? Number(s[1]) : 0;
}
function Qs(t) {
  const s = pe(t, 8192).split(/\r?\n\r?\n/, 1)[0] ?? "", n = /^host:[ \t]*(\S+)[ \t]*$/im.exec(s);
  return (n == null ? void 0 : n[1]) ?? "";
}
function Js(t, e) {
  const { path: s, query: n } = ss(t), r = n ? `${s}?${n}` : s;
  if (/^https?:\/\//i.test(s)) return r;
  const o = Ws(e), i = Qs(t);
  if (!i) {
    if (!o) throw new Error("Cannot tell where this request was sent: no Host header");
    return `${o.origin}${r}`;
  }
  return `${i.endsWith(":80") ? "http" : i.endsWith(":443") ? "https" : (o == null ? void 0 : o.protocol.replace(":", "")) ?? "https"}://${i}${r}`;
}
function Ws(t) {
  try {
    const e = new URL(t);
    return e.protocol === "http:" || e.protocol === "https:" ? e : void 0;
  } catch {
    return;
  }
}
function Zs(t) {
  const e = new URL(t), s = e.protocol === "https:", n = e.port ? Number(e.port) : s ? 443 : 80;
  return { host: e.hostname, port: n, isTls: s };
}
function js(t) {
  let e;
  try {
    e = new URL(t);
  } catch {
    throw new Error("url must be an absolute http or https URL");
  }
  if (e.protocol !== "http:" && e.protocol !== "https:" || !e.hostname)
    throw new Error("url must be an absolute http or https URL");
  return t;
}
function u(t, e, s = "") {
  const n = t[e];
  return typeof n == "string" ? n : s;
}
function b(t, e, s) {
  const n = t[e];
  return typeof n == "number" && Number.isFinite(n) ? n : s;
}
function Le(t, e, s) {
  const n = t[e];
  return typeof n == "number" && Number.isFinite(n) ? Math.trunc(n) : s;
}
function ye(t, e, s = !1) {
  const n = t[e];
  return typeof n == "boolean" ? n : s;
}
function ee(t, e) {
  const s = t[e];
  return Array.isArray(s) ? s.filter((n) => typeof n == "string") : [];
}
function kt(t) {
  const e = (t ?? "").trim();
  let s;
  try {
    s = new URL(e);
  } catch {
    throw new Error("Bridge listener URL must be a valid http:// URL");
  }
  if (s.protocol !== "http:")
    throw new Error("Bridge listener URL must use http://");
  if (s.pathname && s.pathname !== "/")
    throw new Error("Bridge listener URL must not include a path");
  if (s.search || s.hash || s.username || s.password)
    throw new Error("Bridge listener URL must not include credentials, a query, or a fragment");
  const n = Number(s.port);
  if (!Number.isInteger(n) || n < 1 || n > 65535)
    throw new Error("Bridge listener URL must include a host and port");
  const r = Bt(s.hostname).toLowerCase(), o = en(r);
  if (o === void 0)
    throw new Error("Bridge listener must bind to a loopback address");
  return { host: o, port: n, configuredHost: r };
}
function en(t) {
  if (t === "localhost") return "127.0.0.1";
  if (t === "::1" || t === "0:0:0:0:0:0:0:1") return "::1";
  if (/^127\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(t) && t.split(".").map(Number).every((s) => s >= 0 && s <= 255))
    return t;
}
function Bt(t) {
  return t.startsWith("[") && t.endsWith("]") ? t.slice(1, -1) : t;
}
function _e(t) {
  let e = (t ?? "").trim().toLowerCase();
  for (e = Bt(e); e.endsWith("."); ) e = e.slice(0, -1);
  return e;
}
function tn(t, e) {
  if (!t || !t.trim() || t.includes(",")) return;
  let s;
  try {
    s = new URL(`http://${t.trim()}`);
  } catch {
    return;
  }
  if (!s.hostname || s.username || s.password || s.pathname && s.pathname !== "/" || s.search || s.hash || t.includes("/")) return;
  const n = s.port ? Number(s.port) : e;
  if (Number.isInteger(n))
    return { host: Bt(s.hostname), port: n };
}
var L;
class sn {
  constructor(e) {
    p(this, L);
    h(this, L, e);
  }
  acceptsHost(e) {
    const s = tn(e, 80);
    if (!s || s.port !== a(this, L).port) return !1;
    const n = _e(s.host);
    return n === _e(a(this, L).configuredHost) || n === _e(a(this, L).host);
  }
  acceptsOrigin(e) {
    if (!e || !e.trim()) return !0;
    let s;
    try {
      s = new URL(e.trim());
    } catch {
      return !1;
    }
    if (s.protocol !== "http:" || !s.hostname || s.username || s.password || s.pathname && s.pathname !== "/" || s.search || s.hash) return !1;
    const n = s.port ? Number(s.port) : 80;
    return this.acceptsHost(`${s.hostname}:${n}`);
  }
  displayUrl() {
    return `http://${a(this, L).host.includes(":") ? `[${a(this, L).host}]` : a(this, L).host}:${a(this, L).port}`;
  }
}
L = new WeakMap();
function nn(t, e) {
  const s = u(t, "location") === "proxy_history" ? "proxy_history" : "sitemap", n = /* @__PURE__ */ new Set();
  for (const d of lt(t, "methods")) n.add(d.toUpperCase());
  const r = /* @__PURE__ */ new Set();
  if (Array.isArray(t.status))
    for (const d of t.status) {
      const f = Number(d);
      Number.isInteger(f) && r.add(f);
    }
  const o = lt(t, "search_terms");
  ve(o, u(t, "text")), ve(o, u(t, "header")), ve(o, u(t, "body"));
  const i = lt(t, "exclude_terms");
  ve(i, u(t, "exclude_header")), ve(i, u(t, "exclude_body"));
  const c = Le(t, "limit", 50), l = Le(t, "offset", 0);
  return {
    location: s,
    host: u(t, "host"),
    methods: n,
    path: u(t, "path"),
    statuses: r,
    mimeType: u(t, "mime_type"),
    searchTerms: o,
    excludeTerms: i,
    fromTime: Ht(u(t, "from")),
    toTime: Ht(u(t, "to")),
    inScopeOnly: e || t.in_scope_only === !0,
    limit: Math.max(0, Math.min(c, 5e3)),
    offset: Math.max(0, l),
    sortBy: u(t, "sort"),
    sortAscending: u(t, "order").toLowerCase() === "asc"
  };
}
function rn(t) {
  return {
    criteria: t,
    host: un(t.host),
    // Burp treated `*` as decoration around a substring rather than a real glob.
    path: t.path.replace(/\*/g, "").toLowerCase(),
    mimeType: t.mimeType.toLowerCase(),
    searchTerms: t.searchTerms.filter(Boolean).map((e) => e.toLowerCase()),
    excludeTerms: t.excludeTerms.filter(Boolean).map((e) => e.toLowerCase())
  };
}
function on(t, e, s) {
  const { criteria: n } = t;
  if (n.inScopeOnly && !s || n.fromTime !== void 0 && e.createdAt < n.fromTime || n.toTime !== void 0 && e.createdAt > n.toTime || t.host && !t.host(e.request.getHost()) || n.methods.size > 0 && !n.methods.has(e.request.getMethod().toUpperCase()) || t.path && !e.request.getPath().toLowerCase().includes(t.path) || n.statuses.size > 0 && (!e.response || !n.statuses.has(e.response.getCode())) || t.mimeType && (!e.response || !ns(e.response, "content-type").toLowerCase().includes(t.mimeType)))
    return !1;
  for (const r of t.searchTerms)
    if (!Pt(e, r)) return !1;
  for (const r of t.excludeTerms)
    if (Pt(e, r)) return !1;
  return !0;
}
function Pt(t, e) {
  const s = an(t);
  return s.request.includes(e) || s.response.includes(e);
}
function an(t) {
  return t.text || (t.text = {
    request: pe(t.request.getRaw().toBytes()).toLowerCase(),
    response: t.response ? pe(t.response.getRaw().toBytes()).toLowerCase() : ""
  }), t.text;
}
function ns(t, e) {
  const s = t.getHeader(e);
  return (s == null ? void 0 : s[0]) ?? "";
}
const cn = /[\\.[\]{}()+\-^$|?]/g;
function un(t) {
  const e = _e(t);
  if (!e) return;
  if (!e.includes("*")) return (r) => _e(r) === e;
  const s = e.split("*").map((r) => r.replace(cn, "\\$&")).join(".*"), n = new RegExp(`^${s}$`);
  return (r) => n.test(_e(r));
}
function ln(t, e, s) {
  var r, o;
  let n;
  switch (t.sortBy) {
    case "method":
      n = Je(e.request.getMethod(), s.request.getMethod());
      break;
    case "path":
      n = Je(e.request.getPath(), s.request.getPath());
      break;
    case "status":
    case "status_code":
      n = (((r = e.response) == null ? void 0 : r.getCode()) ?? 0) - (((o = s.response) == null ? void 0 : o.getCode()) ?? 0);
      break;
    case "url":
      n = Je(e.request.getUrl(), s.request.getUrl());
      break;
    default:
      n = e.createdAt - s.createdAt;
      break;
  }
  return n === 0 && t.sortBy !== "url" && (n = Je(e.request.getUrl(), s.request.getUrl())), t.sortAscending ? n : -n;
}
function Je(t, e) {
  const s = t.toLowerCase(), n = e.toLowerCase();
  return s < n ? -1 : s > n ? 1 : 0;
}
function dn(t) {
  const e = [];
  if (t.location === "proxy_history" && e.push('source:"intercept"'), t.host && !t.host.includes("*") && e.push(`req.host.eq:${xt(t.host)}`), t.methods.size === 1) {
    const [s] = [...t.methods];
    e.push(`req.method.eq:${xt(s)}`);
  }
  if (t.statuses.size === 1) {
    const [s] = [...t.statuses];
    e.push(`resp.code.eq:${s}`);
  }
  return e.join(" and ");
}
function xt(t) {
  return `"${t.replace(/\\/g, "\\\\").replace(/"/g, '\\"')}"`;
}
function lt(t, e) {
  return ee(t, e).filter((s) => s.trim().length > 0);
}
function ve(t, e) {
  e && e.trim() && t.push(e);
}
function Ht(t) {
  if (!t || !t.trim()) return;
  const e = Date.parse(t);
  return Number.isNaN(e) ? void 0 : e;
}
const hn = 2e4;
async function pn(t, e) {
  const s = dn(e), n = rn(e);
  let r, o = 0, i = !1;
  const c = [];
  let l = s, d = !1;
  for (; ; ) {
    let f;
    try {
      let g = t.requests.query().first(ts);
      l && !d && (g = g.filter(l)), r && (g = g.after(r)), g = e.sortAscending ? g.ascending("req", "created_at") : g.descending("req", "created_at"), f = await g.execute();
    } catch (g) {
      if (!d && l) {
        t.console.warn(
          `[Vigolium] HTTPQL prefilter rejected (${B(g)}); scanning unfiltered`
        ), d = !0, r = void 0, o = 0, c.length = 0;
        continue;
      }
      throw g;
    }
    if (f.items.length === 0) break;
    for (const g of f.items) {
      o += 1;
      const w = rs(g.request, g.response), S = e.inScopeOnly ? t.requests.inScope(g.request) : !0;
      on(n, w, S) && c.push(w);
    }
    if (r = f.pageInfo.endCursor, !f.pageInfo.hasNextPage) break;
    if (o >= hn) {
      i = !0;
      break;
    }
  }
  return c.sort((f, g) => ln(e, f, g)), { candidates: c, truncated: i, scanned: o };
}
function rs(t, e) {
  return { request: t, response: e, createdAt: t.getCreatedAt().getTime() };
}
async function os(t, e) {
  const s = await t.requests.get(e);
  if (!(s != null && s.request)) throw new Error("Caido ref expired or unknown; search again");
  return rs(s.request, s.response);
}
const fn = `
  mutation VigoliumCreateRequest($input: CreateRequestInput!) {
    createRequest(input: $input) {
      id
      responseId
    }
  }
`, gn = `
  mutation VigoliumCreateSitemapEntries($requestId: ID!) {
    createSitemapEntries(requestId: $requestId) {
      __typename
    }
  }
`;
async function Ot(t, e) {
  var g, w, S;
  const { host: s, port: n, isTls: r } = Zs(e.url), { method: o, path: i, query: c } = ss(e.requestBytes), l = {
    input: {
      host: s,
      port: n,
      isTls: r,
      method: o,
      path: i,
      query: c,
      raw: O(e.requestBytes),
      source: "PLUGIN",
      alteration: "NONE",
      ...r ? { sni: s } : {},
      ...e.responseBytes && e.responseBytes.length > 0 ? {
        response: {
          raw: O(e.responseBytes),
          statusCode: zs(e.responseBytes),
          roundtripTime: Math.max(0, Math.trunc(e.roundtripTimeMs ?? 0)),
          source: "PLUGIN",
          alteration: "NONE"
        }
      } : {}
    }
  }, d = await t.graphql.execute(fn, l);
  if (d.errors && d.errors.length > 0)
    throw new Error(`Caido rejected the request import: ${((g = d.errors[0]) == null ? void 0 : g.message) ?? "unknown"}`);
  const f = (S = (w = d.data) == null ? void 0 : w.createRequest) == null ? void 0 : S.id;
  if (!f) throw new Error("Caido did not return an id for the imported request");
  return f;
}
async function is(t, e) {
  var n;
  const s = await t.graphql.execute(gn, { requestId: e });
  if (s.errors && s.errors.length > 0)
    throw new Error(`Caido rejected the sitemap entry: ${((n = s.errors[0]) == null ? void 0 : n.message) ?? "unknown"}`);
}
async function mn(t, e) {
  var i, c, l;
  const s = e.trim();
  if (!s) return;
  const r = (await t.replay.getCollections()).find((d) => d.getName() === s);
  if (r) return r.getId();
  const o = await t.graphql.execute(
    `mutation VigoliumCreateCollection($input: CreateReplaySessionCollectionInput!) {
       createReplaySessionCollection(input: $input) { collection { id } }
     }`,
    { input: { name: s } }
  );
  if (!(o.errors && o.errors.length > 0))
    return ((l = (c = (i = o.data) == null ? void 0 : i.createReplaySessionCollection) == null ? void 0 : c.collection) == null ? void 0 : l.id) ?? void 0;
}
async function yn(t, e, s) {
  const n = s.trim();
  n && await t.graphql.execute(
    `mutation VigoliumRenameSession($id: ID!, $name: String!) {
       renameReplaySession(id: $id, name: $name) { session { id } }
     }`,
    { id: e, name: n }
  );
}
async function rt(t, e, s, n) {
  const r = await Ot(t, e), o = n === void 0 ? await t.replay.createSession(r) : await t.replay.createSession(r, n);
  return await yn(t, o.getId(), s), o.getId();
}
const _n = {
  blocked: !0,
  sent: !1,
  statusCode: 0,
  responseBytes: new Uint8Array(0),
  elapsedMs: void 0,
  error: void 0
};
async function wn(t, e, s, n) {
  var i;
  const r = new Is(e);
  if (r.setRaw(s), n.enforceInScope && !t.requests.inScope(r.toSpec()))
    return _n;
  const o = Date.now();
  try {
    const l = (await t.requests.send(r, {
      timeouts: { global: n.timeoutMs },
      save: n.save
    })).response;
    return {
      blocked: !1,
      sent: !0,
      statusCode: (l == null ? void 0 : l.getCode()) ?? 0,
      responseBytes: l ? l.getRaw().toBytes() : new Uint8Array(0),
      elapsedMs: ((i = l == null ? void 0 : l.getRoundtripTime) == null ? void 0 : i.call(l)) ?? Date.now() - o,
      error: void 0
    };
  } catch (c) {
    return {
      blocked: !1,
      sent: !1,
      statusCode: 0,
      responseBytes: new Uint8Array(0),
      elapsedMs: void 0,
      error: B(c)
    };
  }
}
function ot(t, e, ...s) {
  try {
    t.api.send(e, ...s);
  } catch {
  }
}
const Sn = {
  200: "OK",
  400: "Bad Request",
  403: "Forbidden",
  404: "Not Found",
  405: "Method Not Allowed",
  413: "Payload Too Large",
  429: "Too Many Requests",
  500: "Internal Server Error",
  503: "Service Unavailable"
}, En = 64 * 1024, as = 4, Tn = 3e4;
function bn(t, e) {
  const s = Math.max(0, e - (as - 1));
  for (let n = s; n + 3 < t.length; n++)
    if (t[n] === 13 && t[n + 1] === 10 && t[n + 2] === 13 && t[n + 3] === 10)
      return n;
  return -1;
}
var we, Ue, ke, Se, tt, cs;
class Rn {
  constructor(e, s, n) {
    p(this, tt);
    p(this, we);
    p(this, Ue);
    p(this, ke);
    p(this, Se);
    h(this, Ue, e), h(this, ke, s), h(this, Se, n);
  }
  listen(e, s) {
    return new Promise((n, r) => {
      let o = !1;
      const i = vs((c) => m(this, tt, cs).call(this, c));
      i.on("error", (c) => {
        if (!o) {
          o = !0, r(c);
          return;
        }
        a(this, Se).call(this, c.message);
      }), i.listen(s, e, () => {
        o = !0, h(this, we, i), n();
      });
    });
  }
  close() {
    const e = a(this, we);
    if (h(this, we, void 0), !!e)
      try {
        e.close();
      } catch {
      }
  }
}
we = new WeakMap(), Ue = new WeakMap(), ke = new WeakMap(), Se = new WeakMap(), tt = new WeakSet(), cs = function(e) {
  const s = [];
  let n = 0, r = v.alloc(0), o = 0, i = -1, c = 0, l, d = !1;
  const f = setTimeout(() => {
    g({ status: 400, json: { error: "request timed out" } });
  }, Tn), g = (S) => {
    d || (d = !0, clearTimeout(f), Bn(e, S));
  };
  e.on("error", () => {
    d = !0, clearTimeout(f);
  });
  const w = () => s.length === 1 ? s[0] : v.concat(s, n);
  e.on("data", (S) => {
    if (d) return;
    if (s.push(S), n += S.length, i < 0) {
      if (r = w(), i = bn(r, o), o = r.length, i < 0) {
        n > En && g({ status: 400, json: { error: "request headers too large" } });
        return;
      }
      const N = An(r.toString("latin1", 0, i));
      if (!N) {
        g({ status: 400, json: { error: "malformed request line" } });
        return;
      }
      l = N;
      const q = a(this, ke).call(this, N.path), Ie = N.headers.get("content-length");
      if (N.method === "POST") {
        if (Ie === void 0) {
          g({ status: 400, json: { error: "content-length is required" } });
          return;
        }
        const Qe = Number(Ie);
        if (!Number.isInteger(Qe) || Qe < 0) {
          g({ status: 400, json: { error: "invalid content-length" } });
          return;
        }
        if (Qe > q) {
          g({ status: 400, json: { error: `request exceeds ${At(q)}` } });
          return;
        }
        c = Qe;
      }
    }
    const T = i + as;
    if (n - T < c) return;
    const A = w(), F = {
      method: l.method,
      path: l.path,
      headers: l.headers,
      body: new Uint8Array(A.subarray(T, T + c))
    };
    a(this, Ue).call(this, F).then(g).catch((N) => {
      const q = B(N);
      a(this, Se).call(this, `request failed: ${q}`), g({ status: 500, json: { error: q } });
    });
  });
};
function An(t) {
  const e = t.split(`\r
`), s = e.shift();
  if (!s) return;
  const n = s.split(" ");
  if (n.length < 3) return;
  const [r, o] = n;
  if (!r || !o) return;
  const i = /* @__PURE__ */ new Map();
  for (const d of e) {
    const f = d.indexOf(":");
    if (f <= 0) continue;
    const g = d.slice(0, f).trim().toLowerCase(), w = d.slice(f + 1).trim();
    i.has(g) || i.set(g, w);
  }
  const c = o.indexOf("?"), l = c >= 0 ? o.slice(0, c) : o;
  return { method: r.toUpperCase(), path: l, headers: i };
}
function Bn(t, e) {
  const s = v.from(JSON.stringify(e.json ?? {}), "utf-8"), n = Sn[e.status] ?? "Unknown", r = `HTTP/1.1 ${e.status} ${n}\r
Content-Type: application/json; charset=utf-8\r
Content-Length: ${s.length}\r
Cache-Control: no-store\r
X-Content-Type-Options: nosniff\r
Connection: close\r
\r
`;
  try {
    t.write(v.concat([v.from(r, "latin1"), s])), t.end();
  } catch {
  }
}
const On = 1e4;
var U, Pe, st, us;
class Cn {
  constructor() {
    p(this, st);
    p(this, U, /* @__PURE__ */ new Map());
    p(this, Pe, 0);
  }
  remember(e) {
    const s = m(this, st, us).call(this);
    for (a(this, U).set(s, e); a(this, U).size > On; ) {
      const n = a(this, U).keys().next();
      if (n.done) break;
      a(this, U).delete(n.value);
    }
    return s;
  }
  require(e) {
    const s = a(this, U).get(e);
    if (!s) throw new Error("Caido ref expired or unknown; search again");
    return s;
  }
  clear() {
    a(this, U).clear();
  }
  size() {
    return a(this, U).size;
  }
}
U = new WeakMap(), Pe = new WeakMap(), st = new WeakSet(), /**
 * Monotonic, unguessable-enough identifier. These never leave the loopback
 * interface and expire with the listener, so a counter plus randomness is
 * sufficient without pulling in a UUID dependency.
 */
us = function() {
  h(this, Pe, a(this, Pe) + 1);
  const e = Math.random().toString(36).slice(2, 10);
  return `${a(this, Pe).toString(36)}-${e}`;
};
const Me = 64 * 1024, ls = 4 * 1024 * 1024, dt = ls, Ne = 8 * 1024 * 1024, ht = 24 * 1024 * 1024, In = 1024 * 1024, vn = 2 * 1024 * 1024, $n = 3e4, qn = 12e4, ds = "target is out of Caido scope; disable in-scope-only or add it to the project scope";
class C extends Error {
  constructor(s, n) {
    super(n);
    ct(this, "status");
    this.name = "BridgeError", this.status = s;
  }
}
function Ln(t) {
  const e = t.project();
  return {
    status: "ok",
    // Kept as the Burp listener's identifier so existing tooling that sniffs
    // this field keeps working; `implementation` says what actually answered.
    service: ks,
    implementation: Rt,
    read_only: !1,
    loopback_only: !0,
    in_scope_only: t.inScopeOnly(),
    authentication: "none",
    // Derived from the route table rather than listed separately: a capability
    // the listener does not actually serve is a lie the CLI acts on.
    capabilities: Object.values(Ct).map((s) => s.capability),
    repeater_tabs_per_minute: yt,
    send_respects_in_scope_only: t.inScopeOnly(),
    // Caido scopes traffic per project, so which project is active changes what
    // /search returns. Reported here so CLI output stays explainable.
    project_id: e.id,
    project_name: e.name
  };
}
async function Mn(t, e) {
  const s = nn(e, t.inScopeOnly()), { candidates: n, truncated: r, scanned: o } = await pn(t.sdk, s), i = n.length, c = Math.min(s.offset, i), l = s.limit === 0 ? i : Math.min(i, c + s.limit), d = n.slice(c, l).map((f) => {
    var S;
    const w = {
      ref: t.refs.remember({
        requestId: f.request.getId(),
        url: f.request.getUrl()
      }),
      location: s.location,
      method: f.request.getMethod(),
      url: f.request.getUrl(),
      request_hash: ze(f.request.getRaw().toBytes()),
      status: f.response ? f.response.getCode() : 0,
      time: new Date(f.createdAt).toISOString()
    };
    if (f.response) {
      const T = ns(f.response, "content-type");
      T && (w.mime_type = ((S = T.split(";")[0]) == null ? void 0 : S.trim()) ?? T);
    }
    return w;
  });
  return r && t.log.warn(
    `[Bridge] Search examined the first ${o} requests and stopped at the scan cap; totals are a floor. Narrow the filter for exact counts.`
  ), {
    total: i,
    // Echoed per reply, not read once off /health, so Vigolium's read path pays
    // no extra round trip to learn that these records came from Caido.
    implementation: Rt,
    offset: c,
    returned: d.length,
    has_more: l < i,
    records: d,
    ...r ? { truncated: !0, scanned: o } : {}
  };
}
async function Nn(t, e) {
  const s = u(e, "ref");
  if (!s) throw new C(400, "ref is required");
  const n = t.refs.require(s), r = await os(t.sdk, n.requestId), o = Le(e, "max_bytes", 16384), i = Math.max(1024, Math.min(o, ls)), c = r.request.getRaw().toBytes(), l = r.response ? r.response.getRaw().toBytes() : new Uint8Array(0), d = {
    ref: s,
    // Repeated here rather than left to /search: an inspect can be the first
    // and only call of a session (Vigolium's single-record read has no
    // preceding search), and without it that record would fall back to `burp`.
    implementation: Rt,
    url: r.request.getUrl(),
    request_base64: O(c.subarray(0, Math.min(c.length, i))),
    request_truncated: c.length > i
  };
  return i <= Me && (d.request = pe(c, i)), r.response && (i <= Me && (d.response = pe(l, i)), d.response_base64 = O(
    l.subarray(0, Math.min(l.length, i))
  ), d.response_truncated = l.length > i), d;
}
async function Un(t, e) {
  const s = await it(t, e, Ne), n = hs(
    $t(e, "http_response_base64"),
    Ne,
    "response"
  );
  at(e, "source", 80, "vigolium");
  const r = await Ot(t.sdk, {
    url: s.url,
    requestBytes: s.requestBytes,
    responseBytes: n.length > 0 ? n : null
  });
  return await is(t.sdk, r), {
    added: 1,
    url: s.url,
    request_hash: ze(s.requestBytes),
    message: "added 1 item to Caido Sitemap"
  };
}
var G;
class kn {
  constructor() {
    p(this, G, []);
  }
  reserve() {
    const e = Date.now(), s = e - 6e4;
    for (; a(this, G).length > 0 && a(this, G)[0] < s; )
      a(this, G).shift();
    if (a(this, G).length >= yt)
      throw new C(
        429,
        `Replay session limit reached (${yt} per minute); retry shortly`
      );
    a(this, G).push(e);
  }
  clear() {
    h(this, G, []);
  }
}
G = new WeakMap();
async function Pn(t, e) {
  const s = await it(t, e, In), n = at(e, "tab_name", 64, "vigolium"), r = e.send === !0;
  t.limiter.reserve();
  const o = r ? await It(t, s, e, !1) : void 0;
  await rt(
    t.sdk,
    {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: o != null && o.responseBytes.length ? o.responseBytes : null,
      roundtripTimeMs: o == null ? void 0 : o.elapsedMs
    },
    n
  );
  const i = {
    sent: 1,
    url: s.url,
    tab_name: n,
    request_hash: ze(s.requestBytes)
  };
  return o && (o.blocked ? (i.executed = !1, i.error = "target is out of Caido scope; not auto-sent") : (i.executed = o.sent, vt(i, o))), i.message = "sent 1 request to Caido Replay", i;
}
async function xn(t, e) {
  const s = await it(t, e, Ne), n = Yn(u(e, "http_mode")), r = e.add_to_sitemap === !0, o = await It(t, s, e, r);
  if (o.blocked) throw new C(403, ds);
  const i = {
    sent: o.sent ? 1 : 0,
    url: s.url,
    request_hash: ze(s.requestBytes),
    http_mode: n
  };
  if (vt(i, o), r && o.sent) {
    const c = await Ot(t.sdk, {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: o.responseBytes.length > 0 ? o.responseBytes : null,
      source: at(e, "source", 80, "vigolium-send"),
      roundtripTimeMs: o.elapsedMs
    });
    await is(t.sdk, c), i.added_to_sitemap = !0;
  } else
    i.added_to_sitemap = !1;
  return o.sent || t.log.warn(
    `[Bridge] Send via Caido to ${s.url} failed: ${o.error ?? "unknown"}`
  ), i;
}
const Hn = /* @__PURE__ */ new Set([
  "none",
  "red",
  "orange",
  "yellow",
  "green",
  "cyan",
  "blue",
  "pink",
  "magenta",
  "gray"
]);
async function Dn(t, e) {
  const s = await it(t, e, Ne);
  let n = $t(e, "http_response_base64");
  const r = e.send === !0, o = u(e, "highlight").trim().toLowerCase();
  if (o && !Hn.has(o))
    throw new C(
      400,
      "highlight must be one of none, red, orange, yellow, green, cyan, blue, pink, magenta, gray"
    );
  let i;
  if (r && n.length === 0) {
    if (i = await It(t, s, e, !1), i.blocked) throw new C(403, ds);
    i.responseBytes.length > 0 && (n = i.responseBytes);
  }
  hs(n, Ne, "response");
  const c = ps(u(e, "notes"), 200), l = at(e, "source", 80, "vigolium"), d = c || (o && o !== "none" ? o : "") || "vigolium", f = await mn(t.sdk, d);
  await rt(
    t.sdk,
    {
      url: s.url,
      requestBytes: s.requestBytes,
      responseBytes: n.length > 0 ? n : null,
      roundtripTimeMs: i == null ? void 0 : i.elapsedMs
    },
    c || l,
    f
  );
  const g = {
    added: 1,
    url: s.url,
    request_hash: ze(s.requestBytes),
    has_response: n.length > 0,
    collection: d,
    message: `added 1 item to Caido Replay collection "${d}"`
  };
  return c && (g.notes = c), i && vt(g, i), g;
}
const Ct = {
  "/api/burp-bridge/search": {
    handler: Mn,
    bodyLimit: Me,
    capability: "search_burp_items"
  },
  "/api/burp-bridge/inspect": {
    handler: Nn,
    bodyLimit: Me,
    capability: "inspect_burp_item"
  },
  "/api/burp-bridge/sitemap": {
    handler: Un,
    bodyLimit: ht,
    capability: "add_sitemap_item"
  },
  "/api/burp-bridge/repeater": {
    handler: Pn,
    // Every call opens a visible tab, so this one is capped far lower.
    bodyLimit: vn,
    capability: "send_to_repeater"
  },
  "/api/burp-bridge/send": {
    handler: xn,
    bodyLimit: ht,
    capability: "send_request"
  },
  "/api/burp-bridge/organizer": {
    handler: Dn,
    bodyLimit: ht,
    capability: "add_organizer_item"
  }
};
function Fn(t) {
  var e;
  return ((e = Ct[t]) == null ? void 0 : e.bodyLimit) ?? Me;
}
async function it(t, e, s) {
  const n = u(e, "input_mode");
  if (n && n !== "burp_base64")
    throw new C(400, "input_mode must be burp_base64");
  const r = u(e, "ref").trim();
  let o, i;
  if (r) {
    const c = t.refs.require(r), l = await os(t.sdk, c.requestId);
    o = l.request.getUrl(), i = l.request.getRaw().toBytes();
  } else {
    if (o = u(e, "url"), !o.trim()) throw new C(400, "url is required when ref is not supplied");
    i = Kn(e, "http_request_base64");
  }
  try {
    js(o);
  } catch (c) {
    throw new C(400, B(c));
  }
  if (i.length > s)
    throw new C(400, `request exceeds ${At(s)}`);
  return { url: o, requestBytes: i };
}
async function It(t, e, s, n) {
  return wn(t.sdk, e.url, e.requestBytes, {
    timeoutMs: Gn(s),
    enforceInScope: t.inScopeOnly(),
    save: n
  });
}
function vt(t, e) {
  if (e.error && (t.error = e.error), e.responseBytes.length > 0) {
    const s = e.responseBytes;
    t.status_code = e.statusCode;
    const n = s.length <= dt ? s : s.subarray(0, dt);
    t.response_base64 = O(n), t.response_length = s.length, t.response_truncated = s.length > dt, e.elapsedMs !== void 0 && (t.elapsed_ms = e.elapsedMs);
  }
}
function Gn(t) {
  const e = Le(t, "timeout_ms", $n);
  return Math.max(1, Math.min(e, qn));
}
const Vn = /* @__PURE__ */ new Set([
  "",
  "auto",
  "http1",
  "http_1",
  "http/1",
  "http/1.1",
  "http2",
  "http_2",
  "http/2",
  "http2_ignore_alpn",
  "http_2_ignore_alpn"
]);
function Yn(t) {
  if (!Vn.has(t.toLowerCase()))
    throw new C(400, "http_mode must be one of auto, http1, http2, http2_ignore_alpn");
  return "HTTP_1";
}
function hs(t, e, s) {
  if (t.length > e) throw new C(400, `${s} exceeds ${At(e)}`);
  return t;
}
function $t(t, e) {
  const s = u(t, e);
  if (!s.trim()) return new Uint8Array(0);
  try {
    return Vs(s, e);
  } catch (n) {
    throw new C(400, B(n));
  }
}
function Kn(t, e) {
  const s = $t(t, e);
  if (s.length === 0) throw new C(400, `${e} is required`);
  return s;
}
function at(t, e, s, n) {
  return ps(u(t, e), s) || n;
}
function ps(t, e) {
  const s = t.replace(/[\r\n]/g, " ").trim();
  return s.length > e ? s.slice(0, e) : s;
}
var Ee, se, k, ne, xe, Te, re, P, oe, R, je, fs, gs, ms, j;
class Xn {
  constructor(e, s, n) {
    p(this, R);
    p(this, Ee);
    p(this, se);
    p(this, k);
    p(this, ne, new Cn());
    p(this, xe, new kn());
    p(this, Te);
    p(this, re);
    p(this, P);
    p(this, oe, { id: null, name: null });
    h(this, Ee, e), h(this, se, s), h(this, k, n), h(this, P, Dt(s.get().bridgeListenUrl));
  }
  status() {
    return { ...a(this, P) };
  }
  /**
   * Refs point at request IDs, which only mean something inside the project
   * they came from - so switching project invalidates every outstanding ref.
   */
  onProjectChange(e) {
    h(this, oe, e ? { id: e.id, name: e.name } : { id: null, name: null });
    const s = a(this, ne).size();
    a(this, ne).clear(), s > 0 && a(this, k).info(
      `[Bridge] Project changed to ${(e == null ? void 0 : e.name) ?? "none"}; expired ${s} search refs`
    ), m(this, R, j).call(this, { ...a(this, P), ...m(this, R, je).call(this) });
  }
  async restart() {
    m(this, R, ms).call(this);
    const e = a(this, se).get();
    if (!e.bridgeEnabled) {
      m(this, R, j).call(this, Dt(e.bridgeListenUrl));
      return;
    }
    m(this, R, j).call(this, {
      ...a(this, P),
      state: "STARTING",
      message: "Starting bridge listener…",
      listenUrl: e.bridgeListenUrl
    });
    try {
      const s = kt(e.bridgeListenUrl), n = new sn(s), r = new Rn(
        (i) => m(this, R, fs).call(this, i),
        Fn,
        (i) => a(this, k).error(`[Bridge] ${i}`)
      );
      await r.listen(s.host, s.port), h(this, re, n), h(this, Te, r);
      const o = n.displayUrl();
      m(this, R, j).call(this, {
        state: "LISTENING",
        message: `Bridge listening on ${o}`,
        listenUrl: o,
        startedAt: (/* @__PURE__ */ new Date()).toISOString(),
        lastRequestAt: null,
        ...m(this, R, je).call(this),
        inProcess: !0
      }), a(this, k).info(`[Bridge] Listening on ${o}`);
    } catch (s) {
      const n = B(s);
      h(this, re, void 0), m(this, R, j).call(this, {
        state: "ERROR",
        message: `Bridge listener failed: ${n}`,
        listenUrl: e.bridgeListenUrl,
        startedAt: null,
        lastRequestAt: null,
        ...m(this, R, je).call(this),
        inProcess: !0
      }), a(this, k).error(`[Bridge] ${n}`);
    }
  }
  /** Probes the configured listener the same way the Vigolium client would. */
  async testConnection() {
    const e = a(this, se).get();
    try {
      const s = kt(e.bridgeListenUrl), n = s.host.includes(":") ? `[${s.host}]` : s.host, { fetch: r } = await import("caido:http"), o = await r(`http://${n}:${s.port}/health`);
      return o.status !== 200 ? { successful: !1, message: `Bridge connection failed: HTTP ${o.status}` } : (await o.json()).status !== "ok" ? {
        successful: !1,
        message: "Bridge connection failed: unexpected health response"
      } : { successful: !0, message: "Bridge connection successful" };
    } catch (s) {
      return { successful: !1, message: `Bridge connection failed: ${B(s)}` };
    }
  }
}
Ee = new WeakMap(), se = new WeakMap(), k = new WeakMap(), ne = new WeakMap(), xe = new WeakMap(), Te = new WeakMap(), re = new WeakMap(), P = new WeakMap(), oe = new WeakMap(), R = new WeakSet(), je = function() {
  return { projectId: a(this, oe).id, projectName: a(this, oe).name };
}, fs = async function(e) {
  const s = a(this, re);
  if (!s)
    return pt(503, "bridge is not ready");
  if (!s.acceptsHost(e.headers.get("host")))
    return pt(403, "unexpected Host header");
  if (!s.acceptsOrigin(e.headers.get("origin")))
    return pt(403, "unexpected Origin header");
  const n = {
    sdk: a(this, Ee),
    log: a(this, k),
    refs: a(this, ne),
    limiter: a(this, xe),
    inScopeOnly: () => a(this, se).get().bridgeInScopeOnly,
    project: () => a(this, oe)
  };
  if (e.path === "/" || e.path === "/health")
    return e.method !== "GET" ? Z(405, "method not allowed") : Ft(Ln(n));
  const r = Ct[e.path];
  if (!r) return Z(404, "not found");
  if (e.method !== "POST") return Z(405, "method not allowed");
  let o;
  try {
    const i = Ce(e.body).toString("utf-8"), c = i.trim() ? JSON.parse(i) : {};
    if (typeof c != "object" || c === null || Array.isArray(c))
      return Z(400, "request body must be a JSON object");
    o = c;
  } catch {
    return Z(400, "request body is not valid JSON");
  }
  try {
    const i = await r.handler(n, o);
    return m(this, R, gs).call(this), Ft(i);
  } catch (i) {
    if (i instanceof C) return Z(i.status, i.message);
    const c = B(i);
    return a(this, k).error(`[Bridge] Request failed: ${c}`), Z(500, c);
  }
}, gs = function() {
  a(this, P).state === "LISTENING" && m(this, R, j).call(this, { ...a(this, P), lastRequestAt: (/* @__PURE__ */ new Date()).toISOString() });
}, ms = function() {
  var e;
  (e = a(this, Te)) == null || e.close(), h(this, Te, void 0), h(this, re, void 0), a(this, ne).clear(), a(this, xe).clear();
}, j = function(e) {
  h(this, P, e), ot(a(this, Ee), Hs, e);
};
function Dt(t) {
  return {
    state: "DISABLED",
    message: "Bridge disabled",
    listenUrl: t,
    startedAt: null,
    lastRequestAt: null,
    projectId: null,
    projectName: null,
    inProcess: !0
  };
}
function Ft(t) {
  return { status: 200, json: t };
}
function Z(t, e) {
  return { status: t, json: { error: e } };
}
function pt(t, e) {
  return { status: t, json: { error: e }, close: !0 };
}
var be, x, Re, Y;
class Gt {
  constructor() {
    p(this, be, 0);
    p(this, x, 0);
    p(this, Re, 0);
    p(this, Y);
  }
  setOnChange(e) {
    h(this, Y, e);
  }
  /** Queues `count` requests as pending in one step, so a batch fires one event. */
  incrementPending(e = 1) {
    var s;
    h(this, x, a(this, x) + e), (s = a(this, Y)) == null || s.call(this);
  }
  markSent() {
    var e;
    a(this, x) > 0 && h(this, x, a(this, x) - 1), h(this, be, a(this, be) + 1), (e = a(this, Y)) == null || e.call(this);
  }
  markFailed() {
    var e;
    a(this, x) > 0 && h(this, x, a(this, x) - 1), h(this, Re, a(this, Re) + 1), (e = a(this, Y)) == null || e.call(this);
  }
  reset() {
    var e;
    h(this, be, 0), h(this, x, 0), h(this, Re, 0), (e = a(this, Y)) == null || e.call(this);
  }
  snapshot() {
    return { sent: a(this, be), pending: a(this, x), failed: a(this, Re) };
  }
}
be = new WeakMap(), x = new WeakMap(), Re = new WeakMap(), Y = new WeakMap();
var K, V;
class zn {
  constructor(e) {
    p(this, K);
    p(this, V, []);
    h(this, K, e);
  }
  add(e, s) {
    const n = {
      timestamp: (/* @__PURE__ */ new Date()).toISOString(),
      level: e,
      message: s
    };
    a(this, V).push(n), a(this, V).length > Lt && a(this, V).splice(0, a(this, V).length - Lt);
    const r = `[Vigolium] ${s}`;
    e === "ERROR" ? a(this, K).console.error(r) : e === "WARN" ? a(this, K).console.warn(r) : a(this, K).console.log(r), ot(a(this, K), Gs, n);
  }
  info(e) {
    this.add("INFO", e);
  }
  warn(e) {
    this.add("WARN", e);
  }
  error(e) {
    this.add("ERROR", e);
  }
  entries() {
    return [...a(this, V)];
  }
  clear() {
    h(this, V, []);
  }
}
K = new WeakMap(), V = new WeakMap();
function Qn(t, e) {
  const s = t.filter((r) => r.enabled);
  if (s.length === 0) return !0;
  let n = Yt(s[0], e);
  for (let r = 1; r < s.length; r++) {
    const o = s[r], i = Yt(o, e);
    n = o.operator === "OR" ? n || i : n && i;
  }
  return n;
}
const Vt = /* @__PURE__ */ new Set(["DOES_NOT_MATCH", "NOT_EQUALS"]);
function Yt(t, e) {
  switch (t.matchType) {
    case "FILE_EXTENSION":
      return ge(t.relationship, t.condition, Jn(e.path), !0);
    case "HTTP_METHOD":
      return ge(t.relationship, t.condition, e.method, !0);
    case "URL":
      return t.relationship === "IS_IN_TARGET_SCOPE" ? e.inScope : t.relationship === "IS_NOT_IN_TARGET_SCOPE" ? !e.inScope : ge(t.relationship, t.condition, e.url, !1);
    case "CONTENT_TYPE":
      return e.contentType === void 0 ? Vt.has(t.relationship) : ge(t.relationship, t.condition, e.contentType, !0, !0);
    case "STATUS_CODE":
      return e.statusCode === void 0 ? Vt.has(t.relationship) : ge(t.relationship, t.condition, String(e.statusCode), !1);
    case "HOST":
      return ge(t.relationship, t.condition, e.host, !0);
    case "REQUEST":
      return Wn(t.relationship, e);
    default:
      return !1;
  }
}
function Jn(t) {
  const e = t.lastIndexOf(".");
  return e < 0 || e >= t.length - 1 || t.indexOf("/", e) >= 0 ? "" : t.slice(e + 1).toLowerCase();
}
function Wn(t, e) {
  const s = e.query.length > 0 || e.hasBody || e.hasCookies;
  switch (t) {
    case "HAS_PARAMETERS":
      return s;
    case "DOES_NOT_HAVE_PARAMETERS":
      return !s;
    case "HAS_BODY":
      return e.hasBody;
    case "DOES_NOT_HAVE_BODY":
      return !e.hasBody;
    default:
      return !1;
  }
}
function ge(t, e, s, n, r = !1) {
  switch (t) {
    case "MATCHES":
      return Kt(e, s, n, r);
    case "DOES_NOT_MATCH":
      return !Kt(e, s, n, r);
    case "EQUALS":
      return n ? s.toLowerCase() === e.toLowerCase() : s === e;
    case "NOT_EQUALS":
      return n ? s.toLowerCase() !== e.toLowerCase() : s !== e;
    default:
      return !1;
  }
}
function Kt(t, e, s, n) {
  const r = Zn(n ? t : `^(?:${t})$`, s);
  return r ? r.test(e) : !1;
}
const ft = /* @__PURE__ */ new Map();
function Zn(t, e) {
  const s = e ? "i" : "", n = `${s}\0${t}`;
  if (ft.has(n)) return ft.get(n);
  let r;
  try {
    r = new RegExp(t, s);
  } catch {
    r = void 0;
  }
  return ft.set(n, r), r;
}
var Ae, ie, He, ae;
class jn {
  constructor(e, s, n, r) {
    p(this, Ae);
    p(this, ie);
    p(this, He);
    p(this, ae);
    h(this, Ae, e), h(this, ie, s), h(this, He, n), h(this, ae, r);
  }
  async handle(e, s, n) {
    const r = a(this, He).get();
    if (r.proxyEnabled)
      try {
        const o = e.requests.inScope(s);
        if (r.proxyInScopeOnly && !o) return;
        if (!a(this, Ae).isConfigured()) {
          a(this, ie).error("[Proxy] Skipped: Vigolium server URL is not configured");
          return;
        }
        if (!Qn(r.proxyFilterRules, er(s, n, o))) return;
        const i = s.getUrl(), c = O(s.getRaw().toBytes()), l = O(n.getRaw().toBytes());
        a(this, ae).incrementPending();
        try {
          await a(this, Ae).ingest({
            input_mode: "burp_base64",
            url: i,
            http_request_base64: c,
            http_response_base64: l
          }), a(this, ae).markSent();
        } catch (d) {
          a(this, ae).markFailed(), a(this, ie).error(`[Proxy] Request failed: ${B(d)}`);
        }
      } catch (o) {
        a(this, ie).error(`[Proxy] Handler error: ${B(o)}`);
      }
  }
}
Ae = new WeakMap(), ie = new WeakMap(), He = new WeakMap(), ae = new WeakMap();
function er(t, e, s) {
  return {
    method: t.getMethod(),
    url: t.getUrl(),
    path: t.getPath(),
    query: t.getQuery() ?? "",
    host: t.getHost(),
    get hasBody() {
      var n;
      return (((n = t.getBody()) == null ? void 0 : n.toRaw().length) ?? 0) > 0;
    },
    get hasCookies() {
      return (t.getHeader("Cookie") ?? []).length > 0;
    },
    statusCode: e == null ? void 0 : e.getCode(),
    get contentType() {
      var n;
      return (n = e == null ? void 0 : e.getHeader("Content-Type")) == null ? void 0 : n[0];
    },
    inScope: s
  };
}
const gt = "settings", tr = [
  "serverUrl",
  "apiKey",
  "customModules",
  "scanTimeout",
  "bridgeListenUrl"
], sr = ["serverUrl", "bridgeListenUrl"];
var X, H, z, De, Fe, nt, ys;
class nr {
  constructor(e) {
    p(this, nt);
    p(this, X);
    p(this, H, Xt({}));
    /**
     * The object handed to every `get()` caller, rebuilt on write rather than
     * cloned on read. `get()` sits on the proxy interception path, where
     * serialising and reparsing the whole object once per exchange is pure waste.
     */
    p(this, z);
    p(this, De, []);
    p(this, Fe, !1);
    h(this, X, e), h(this, z, mt(a(this, H)));
  }
  async init() {
    const e = await a(this, X).meta.db();
    await e.exec(
      `CREATE TABLE IF NOT EXISTS ${gt} (key TEXT PRIMARY KEY, value TEXT NOT NULL)`
    );
    const n = await (await e.prepare(`SELECT key, value FROM ${gt}`)).all(), r = {};
    for (const o of n)
      try {
        r[o.key] = JSON.parse(o.value);
      } catch {
        a(this, X).console.warn(`[Vigolium] Ignoring unreadable setting "${o.key}"`);
      }
    h(this, H, Xt(r)), h(this, z, mt(a(this, H))), h(this, Fe, !0);
  }
  /**
   * The current settings. Callers must treat the result as read-only: it is one
   * shared object rather than a per-call copy.
   */
  get() {
    return a(this, z);
  }
  /** Applies a partial update, persists only the changed keys, and notifies listeners. */
  async update(e) {
    a(this, Fe) || await this.init();
    const s = [];
    for (const o of Object.keys(e)) {
      const i = ws(o, e[o]);
      i !== void 0 && JSON.stringify(i) !== JSON.stringify(a(this, H)[o]) && (a(this, H)[o] = i, s.push(o));
    }
    if (s.length === 0) return this.get();
    h(this, z, mt(a(this, H)));
    const r = await (await a(this, X).meta.db()).prepare(
      `INSERT INTO ${gt} (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`
    );
    for (const o of s)
      await r.run(o, JSON.stringify(a(this, H)[o]));
    return m(this, nt, ys).call(this), this.get();
  }
  /** The configured scan modules, split once here rather than at each call site. */
  moduleList() {
    return _s(a(this, z).customModules);
  }
  onChange(e) {
    a(this, De).push(e);
  }
}
X = new WeakMap(), H = new WeakMap(), z = new WeakMap(), De = new WeakMap(), Fe = new WeakMap(), nt = new WeakSet(), ys = function() {
  const e = this.get();
  for (const s of a(this, De))
    try {
      s(e);
    } catch (n) {
      a(this, X).console.error(`[Vigolium] settings listener failed: ${B(n)}`);
    }
};
function _s(t) {
  return t.split(",").map((e) => e.trim()).filter(Boolean);
}
function St(t) {
  return t.trim() || null;
}
function mt(t) {
  return JSON.parse(JSON.stringify(t));
}
function ws(t, e) {
  if (typeof e != "string" || !tr.includes(t)) return e;
  const s = e.trim();
  return sr.includes(t) ? s.replace(/\/+$/, "") : s;
}
function Xt(t) {
  const e = Ns;
  return {
    serverUrl: $e(t, "serverUrl", e.serverUrl),
    apiKey: $e(t, "apiKey", e.apiKey),
    customModules: $e(t, "customModules", e.customModules),
    scanTimeout: $e(t, "scanTimeout", e.scanTimeout),
    // Deliberately not restored from disk: forwarding restarts off on every
    // load, matching the Burp extension, so a reload never silently resumes
    // shipping traffic to a scanner.
    proxyEnabled: !1,
    proxyInScopeOnly: ye(t, "proxyInScopeOnly", e.proxyInScopeOnly),
    proxyFilterRules: or(t.proxyFilterRules),
    snapshotAutoEnabled: ye(t, "snapshotAutoEnabled", e.snapshotAutoEnabled),
    snapshotIntervalMinutes: rr(
      t,
      "snapshotIntervalMinutes",
      e.snapshotIntervalMinutes,
      1,
      1440
    ),
    snapshotInScopeOnly: ye(t, "snapshotInScopeOnly", e.snapshotInScopeOnly),
    bridgeEnabled: ye(t, "bridgeEnabled", e.bridgeEnabled),
    bridgeListenUrl: $e(t, "bridgeListenUrl", e.bridgeListenUrl),
    bridgeInScopeOnly: ye(t, "bridgeInScopeOnly", e.bridgeInScopeOnly)
  };
}
function $e(t, e, s) {
  return ws(e, u(t, e, s));
}
function rr(t, e, s, n, r) {
  return Math.min(r, Math.max(n, Le(t, e, s)));
}
function or(t) {
  if (!Array.isArray(t)) return Ms.map((s) => ({ ...s }));
  const e = [];
  for (const s of t) {
    if (typeof s != "object" || s === null) continue;
    const n = s;
    typeof n.matchType != "string" || typeof n.relationship != "string" || Ls(n.matchType, n.relationship) && e.push({
      enabled: n.enabled !== !1,
      operator: n.operator === "AND" || n.operator === "OR" ? n.operator : null,
      matchType: n.matchType,
      relationship: n.relationship,
      condition: typeof n.condition == "string" ? n.condition : ""
    });
  }
  return e;
}
const ir = 100, Ss = wt;
function ar(t) {
  const e = [];
  let s = 0;
  for (; s < t.length; ) {
    const n = [];
    let r = 0;
    for (; s < t.length && n.length < ir; ) {
      const o = t[s];
      if (n.length > 0 && r + o.rawBytes > Ss) break;
      n.push(o), r += o.rawBytes, s++;
    }
    e.push(n);
  }
  return e;
}
var ce, Q, ue, J, Be, Ge, Oe, le, de, M, Es, Ts, qe;
class cr {
  constructor(e, s, n, r) {
    p(this, M);
    p(this, ce);
    p(this, Q);
    p(this, ue);
    p(this, J);
    p(this, Be, /* @__PURE__ */ new Map());
    p(this, Ge);
    p(this, Oe, !1);
    p(this, le);
    p(this, de, We());
    h(this, ce, e), h(this, Q, s), h(this, ue, n), h(this, J, r);
  }
  status() {
    return { ...a(this, de) };
  }
  start() {
    this.reschedule();
  }
  reschedule() {
    a(this, le) !== void 0 && (clearInterval(a(this, le)), h(this, le, void 0));
    const e = a(this, Q).get();
    if (!e.snapshotAutoEnabled) {
      m(this, M, qe).call(this, {
        ...a(this, de),
        state: "DISABLED",
        message: "Automatic snapshots disabled",
        nextRunAt: null
      });
      return;
    }
    h(this, le, setInterval(
      () => void this.snapshotNow("Auto"),
      e.snapshotIntervalMinutes * 6e4
    )), this.snapshotNow("Auto");
  }
  async snapshotNow(e) {
    if (a(this, Oe))
      return a(this, J).warn("[Sitemap Snapshot] Skipped: another snapshot is running"), this.status();
    h(this, Oe, !0), m(this, M, qe).call(this, {
      ...We(),
      state: "RUNNING",
      message: "Reading the Caido Sitemap…",
      completedAt: a(this, de).completedAt
    });
    try {
      if (!a(this, ue).isConfigured())
        throw new Error("Vigolium server URL is not configured");
      await m(this, M, Ts).call(this);
      const s = a(this, Q).get(), { pending: n, discovered: r, oversized: o } = await m(this, M, Es).call(this, s.snapshotInScopeOnly);
      let i = 0, c = 0, l = 0, d = o, f = 0;
      const g = dr(), w = (/* @__PURE__ */ new Date()).toISOString(), S = ar(n);
      for (let A = 0; A < S.length; A++) {
        const F = S[A], N = F.map(lr), q = await a(this, ue).snapshotSitemap({
          snapshot_id: g,
          chunk_index: A,
          final_chunk: A === S.length - 1,
          captured_at: w,
          records: N
        });
        if (f += N.length, i += q.inserted, c += q.updated, l += q.unchanged, d += q.skipped, q.skipped === 0)
          for (const Ie of F)
            a(this, Be).set(Ie.identityFingerprint, Ie.contentFingerprint);
      }
      const T = {
        ...We(),
        state: "SUCCESS",
        message: n.length === 0 && o === 0 ? "Sitemap already synchronized" : "Sitemap snapshot completed",
        discovered: r,
        uploaded: f,
        inserted: i,
        updated: c,
        unchanged: l,
        failed: d,
        completedAt: (/* @__PURE__ */ new Date()).toISOString(),
        nextRunAt: zt(a(this, Q).get())
      };
      return m(this, M, qe).call(this, T), a(this, J).info(
        `[Sitemap Snapshot:${e}] discovered=${r} uploaded=${f} inserted=${i} updated=${c} unchanged=${l} failed=${d}`
      ), T;
    } catch (s) {
      const n = B(s), r = {
        ...We(),
        state: "FAILED",
        message: `Snapshot failed: ${n}`,
        failed: 1,
        completedAt: (/* @__PURE__ */ new Date()).toISOString(),
        nextRunAt: zt(a(this, Q).get())
      };
      return m(this, M, qe).call(this, r), a(this, J).error(`[Sitemap Snapshot:${e}] ${n}`), r;
    } finally {
      h(this, Oe, !1);
    }
  }
}
ce = new WeakMap(), Q = new WeakMap(), ue = new WeakMap(), J = new WeakMap(), Be = new WeakMap(), Ge = new WeakMap(), Oe = new WeakMap(), le = new WeakMap(), de = new WeakMap(), M = new WeakSet(), Es = async function(e) {
  const s = [];
  let n = 0, r = 0, o;
  for (; ; ) {
    let i = a(this, ce).requests.query().first(ts).ascending("req", "created_at");
    o && (i = i.after(o));
    const c = await i.execute();
    if (c.items.length === 0) break;
    for (const l of c.items) {
      if (e && !a(this, ce).requests.inScope(l.request)) continue;
      n++;
      const d = ur(l.request, l.response);
      if (!d) {
        r++, a(this, J).warn(`[Sitemap Snapshot] Skipped oversized record: ${l.request.getUrl()}`);
        continue;
      }
      a(this, Be).get(d.identityFingerprint) !== d.contentFingerprint && s.push(d);
    }
    if (o = c.pageInfo.endCursor, !c.pageInfo.hasNextPage) break;
  }
  return { pending: s, discovered: n, oversized: r };
}, Ts = async function() {
  const e = await a(this, ue).destinationIdentity();
  a(this, Ge) !== e && (a(this, Be).clear(), h(this, Ge, e));
}, qe = function(e) {
  h(this, de, e), ot(a(this, ce), Ds, e);
};
function zt(t) {
  return t.snapshotAutoEnabled ? new Date(Date.now() + t.snapshotIntervalMinutes * 6e4).toISOString() : null;
}
const Qt = v.from([0]);
function ur(t, e) {
  const s = t.getRaw().toBytes(), n = e ? e.getRaw().toBytes() : new Uint8Array(0), r = s.length + n.length;
  if (r > Ss) return;
  const o = t.getUrl(), i = et("sha256").update(v.from(o, "utf-8")).update(Qt).update(Ce(s)).digest("hex"), c = et("sha256").update(v.from(i, "ascii")).update(Qt).update(Ce(n)).digest("hex");
  return { url: o, requestBytes: s, responseBytes: n, identityFingerprint: i, contentFingerprint: c, rawBytes: r };
}
function lr(t) {
  const e = {
    url: t.url,
    request_base64: O(t.requestBytes),
    identity_fingerprint: t.identityFingerprint,
    content_fingerprint: t.contentFingerprint
  };
  return t.responseBytes.length > 0 && (e.response_base64 = O(t.responseBytes)), e;
}
function We() {
  return {
    state: "IDLE",
    message: "Idle",
    discovered: 0,
    uploaded: 0,
    inserted: 0,
    updated: 0,
    unchanged: 0,
    failed: 0,
    completedAt: null,
    nextRunAt: null
  };
}
function dr() {
  const t = () => Math.random().toString(16).slice(2, 10);
  return `${t()}-${t()}-${t()}-${t()}`;
}
const Jt = 2, hr = [1e3, 2e3];
class te extends Error {
  constructor(s, n) {
    super(n);
    ct(this, "statusCode");
    this.name = "VigoliumApiError", this.statusCode = s;
  }
}
var he, _, E;
class pr {
  constructor(e) {
    p(this, _);
    p(this, he);
    h(this, he, e);
  }
  // The settings store canonicalises `serverUrl` and `apiKey` on the way in, so
  // nothing here trims or strips a trailing slash. That is what keeps the
  // identity below hashing exactly the credentials requests are sent with -
  // trimming at some call sites and not others silently split the two apart.
  isConfigured() {
    return a(this, he).call(this).serverUrl.length > 0;
  }
  /** Stable identity of "where records are being sent", for snapshot cache invalidation. */
  async destinationIdentity() {
    const { serverUrl: e, apiKey: s } = a(this, he).call(this);
    return et("sha256").update(`${e}\0${s}`).digest("hex");
  }
  async health() {
    const e = Date.now(), s = await m(this, _, E).call(this, "GET", "/health"), n = I(s);
    return {
      status: u(n, "status", "unknown"),
      version: u(n, "version", "unknown"),
      latencyMs: Date.now() - e
    };
  }
  async ingest(e) {
    await m(this, _, E).call(this, "POST", "/api/ingest-http", e);
  }
  async scan(e) {
    const s = await m(this, _, E).call(this, "POST", "/api/scan-request", e), n = I(s);
    return {
      scanId: u(n, "scan_id", ""),
      message: u(n, "message", "")
    };
  }
  async agentScan(e) {
    return m(this, _, E).call(this, "POST", "/api/agent/run/swarm", e);
  }
  async scanAllRecords(e, s) {
    const n = {};
    e.length > 0 && (n.modules = e), s && s.trim() && (n.timeout = s.trim());
    const r = await m(this, _, E).call(this, "POST", "/api/scan-all-records", n), o = I(r);
    return u(o, "scan_uuid", "") || u(o, "scan_id", "");
  }
  async scanRecords(e, s) {
    const n = { record_uuids: e };
    s.length > 0 && (n.enable_modules = s);
    const r = await m(this, _, E).call(this, "POST", "/api/scan-records", n);
    return u(I(r), "scan_id", "");
  }
  async snapshotSitemap(e) {
    const s = await m(this, _, E).call(this, "POST", "/api/burp/sitemap/snapshot", e), n = I(s);
    return {
      inserted: b(n, "inserted", 0),
      updated: b(n, "updated", 0),
      unchanged: b(n, "unchanged", 0),
      skipped: b(n, "skipped", 0)
    };
  }
  // ---------------------------------------------------------------- Findings
  async findings(e) {
    const s = me("/api/findings", {
      limit: e.limit,
      offset: e.offset,
      domain: e.domain,
      severity: e.severity,
      module_type: e.moduleType,
      finding_source: e.findingSource,
      scan_id: e.scanId,
      repo_name: e.repoName,
      search: e.search,
      sort: e.sort,
      order: e.order
    }), n = I(await m(this, _, E).call(this, "GET", s));
    return Ze(n, Wt, e.limit, e.offset);
  }
  async findingById(e) {
    return Wt(I(await m(this, _, E).call(this, "GET", `/api/findings/${e}`)));
  }
  async deleteFinding(e) {
    await m(this, _, E).call(this, "DELETE", `/api/findings/${e}`);
  }
  // ------------------------------------------------------------ HTTP records
  async httpRecords(e) {
    const s = me("/api/http-records", {
      limit: e.limit,
      offset: e.offset,
      domain: e.domain,
      method: e.method,
      path: e.path,
      status_code: e.statusCode,
      content_type: e.contentType,
      search: e.search,
      source: e.source,
      min_risk: e.minRisk,
      sort: e.sort,
      order: e.order
    }), n = I(await m(this, _, E).call(this, "GET", s));
    return Ze(n, Zt, e.limit, e.offset);
  }
  async httpRecordByUuid(e) {
    return Zt(I(await m(this, _, E).call(this, "GET", `/api/http-records/${e}`)));
  }
  async deleteHttpRecord(e) {
    await m(this, _, E).call(this, "DELETE", `/api/http-records/${e}`);
  }
  // ------------------------------------------------------------------- Scans
  async scans(e, s) {
    const n = I(await m(this, _, E).call(this, "GET", me("/api/scans", { limit: e, offset: s })));
    return Ze(n, gr, e, s);
  }
  async stopScan(e) {
    await m(this, _, E).call(this, "POST", `/api/scans/${e}/stop`, {});
  }
  async pauseScan(e) {
    await m(this, _, E).call(this, "POST", `/api/scans/${e}/pause`, {});
  }
  async resumeScan(e) {
    await m(this, _, E).call(this, "POST", `/api/scans/${e}/resume`, {});
  }
  async deleteScan(e) {
    await m(this, _, E).call(this, "DELETE", `/api/scans/${e}`);
  }
  async scanLogs(e, s, n, r, o) {
    const i = me(`/api/scans/${e}/logs`, { limit: r, offset: o, level: s, phase: n }), c = I(await m(this, _, E).call(this, "GET", i)), l = bs(c.logs).map((d) => ({
      id: b(d, "id", 0),
      scanUuid: u(d, "scan_uuid", ""),
      level: u(d, "level", ""),
      phase: u(d, "phase", ""),
      message: u(d, "message", ""),
      createdAt: u(d, "created_at", "")
    }));
    return { logs: l, total: b(c, "total", l.length) };
  }
  // ---------------------------------------------------------- Agent sessions
  async agentSessions(e, s, n) {
    const r = me("/api/agent/sessions", { limit: s, offset: n, mode: e }), o = I(await m(this, _, E).call(this, "GET", r));
    return Ze(o, mr, s, n);
  }
  async agentSessionLogs(e) {
    return m(this, _, E).call(this, "GET", me(`/api/agent/sessions/${e}/logs`, { strip: 1 }));
  }
}
he = new WeakMap(), _ = new WeakSet(), E = async function(e, s, n) {
  const { serverUrl: r, apiKey: o } = a(this, he).call(this);
  if (!r) throw new te(0, "Vigolium server URL is not configured");
  const i = {
    // Set on every call rather than only on the ingest path: it is advisory
    // (the server allowlists it and falls back to `ingest-server`), and a
    // per-endpoint opt-in is the kind of thing a new dispatch route silently
    // forgets. Without it, traffic pushed from Caido is indistinguishable
    // from traffic pushed by curl.
    [Ps]: xs
  };
  o && (i.Authorization = `Bearer ${o}`);
  let c = { method: e, headers: i };
  n !== void 0 && (i["Content-Type"] = "application/json", c = { ...c, body: JSON.stringify(n) });
  let l = "unknown error";
  for (let d = 0; d <= Jt; d++) {
    d > 0 && await fr(hr[d - 1] ?? 2e3);
    try {
      const f = await $s(`${r}${s}`, c), g = await f.text();
      if (f.ok) return g;
      if (f.status >= 400 && f.status < 500)
        throw new te(
          f.status,
          `API error: ${f.status} - ${g.trim()}`
        );
      l = `Server error: ${f.status} - ${g.trim()}`;
    } catch (f) {
      if (f instanceof te) throw f;
      l = B(f);
    }
  }
  throw new te(0, `Request failed after ${Jt} retries: ${l}`);
};
function fr(t) {
  return new Promise((e) => setTimeout(e, t));
}
function I(t) {
  if (!t.trim()) return {};
  try {
    const e = JSON.parse(t);
    return typeof e == "object" && e !== null ? e : {};
  } catch {
    return {};
  }
}
function bs(t) {
  return Array.isArray(t) ? t.filter((e) => typeof e == "object" && e !== null) : [];
}
function Ze(t, e, s, n) {
  return {
    data: bs(t.data).map(e),
    total: b(t, "total", 0),
    limit: b(t, "limit", s),
    offset: b(t, "offset", n),
    hasMore: ye(t, "has_more", !1)
  };
}
function Wt(t) {
  return {
    id: b(t, "id", 0),
    httpRecordUuids: ee(t, "http_record_uuids"),
    scanUuid: u(t, "scan_uuid", ""),
    moduleId: u(t, "module_id", ""),
    moduleName: u(t, "module_name", ""),
    description: u(t, "description", ""),
    severity: Us(u(t, "severity", "")),
    confidence: u(t, "confidence", ""),
    tags: ee(t, "tags"),
    matchedAt: ee(t, "matched_at"),
    foundAt: u(t, "found_at", ""),
    request: u(t, "request", ""),
    response: u(t, "response", ""),
    moduleType: u(t, "module_type", ""),
    moduleShort: u(t, "module_short", ""),
    findingSource: u(t, "finding_source", ""),
    sourceFile: u(t, "source_file", ""),
    repoName: u(t, "repo_name", ""),
    extractedResults: ee(t, "extracted_results"),
    additionalEvidence: ee(t, "additional_evidence"),
    findingHash: u(t, "finding_hash", ""),
    createdAt: u(t, "created_at", "")
  };
}
function Zt(t) {
  return {
    uuid: u(t, "uuid", ""),
    scheme: u(t, "scheme", ""),
    hostname: u(t, "hostname", ""),
    port: b(t, "port", 0),
    method: u(t, "method", ""),
    path: u(t, "path", ""),
    url: u(t, "url", ""),
    statusCode: b(t, "status_code", 0),
    statusPhrase: u(t, "status_phrase", ""),
    responseHttpVersion: u(t, "response_http_version", ""),
    responseContentLength: b(t, "response_content_length", 0),
    responseTimeMs: b(t, "response_time_ms", 0),
    sentAt: u(t, "sent_at", ""),
    createdAt: u(t, "created_at", ""),
    source: u(t, "source", ""),
    riskScore: b(t, "risk_score", 0),
    // Left base64-encoded: the frontend renders them through Caido's editors,
    // and decoding here would force a lossy string round trip.
    rawRequestBase64: u(t, "raw_request", ""),
    rawResponseBase64: u(t, "raw_response", "")
  };
}
function gr(t) {
  return {
    uuid: u(t, "uuid", ""),
    name: u(t, "name", ""),
    status: u(t, "status", ""),
    scanSource: u(t, "scan_source", ""),
    scanMode: u(t, "scan_mode", ""),
    sourceType: u(t, "source_type", ""),
    modules: u(t, "modules", ""),
    totalFindings: b(t, "total_findings", 0),
    processedCount: b(t, "processed_count", 0),
    startedAt: u(t, "started_at", ""),
    finishedAt: u(t, "finished_at", ""),
    createdAt: u(t, "created_at", "")
  };
}
function mr(t) {
  return {
    uuid: u(t, "uuid", ""),
    mode: u(t, "mode", ""),
    status: u(t, "status", ""),
    agentName: u(t, "agent_name", ""),
    templateId: u(t, "template_id", ""),
    targetUrl: u(t, "target_url", ""),
    inputType: u(t, "input_type", ""),
    currentPhase: u(t, "current_phase", ""),
    phasesRun: ee(t, "phases_run"),
    findingCount: b(t, "finding_count", 0),
    recordCount: b(t, "record_count", 0),
    savedCount: b(t, "saved_count", 0),
    durationMs: b(t, "duration_ms", 0),
    startedAt: u(t, "started_at", ""),
    completedAt: u(t, "completed_at", ""),
    createdAt: u(t, "created_at", "")
  };
}
function me(t, e) {
  const s = [];
  for (const [n, r] of Object.entries(e)) {
    if (r == null) continue;
    const o = String(r);
    o.trim() && s.push(`${encodeURIComponent(n)}=${encodeURIComponent(o)}`);
  }
  return s.length > 0 ? `${t}?${s.join("&")}` : t;
}
const yr = 8;
async function _r(t, e) {
  const s = new Array(e.length);
  let n = 0;
  const r = async () => {
    for (let i = n++; i < e.length; i = n++) {
      const c = await t.requests.get(e[i]);
      c != null && c.request && (s[i] = {
        url: c.request.getUrl(),
        requestBytes: c.request.getRaw().toBytes(),
        responseBytes: c.response ? c.response.getRaw().toBytes() : null
      });
    }
  }, o = Math.min(yr, e.length);
  return await Promise.all(Array.from({ length: o }, r)), s.filter((i) => i !== void 0);
}
var Ve, W, D, Ye, Ke, Xe, $, Et, Tt, Rs, As;
class wr {
  constructor(e, s, n, r, o, i) {
    p(this, $);
    p(this, Ve);
    p(this, W);
    p(this, D);
    p(this, Ye);
    p(this, Ke);
    p(this, Xe);
    h(this, Ve, e), h(this, W, s), h(this, D, n), h(this, Ye, r), h(this, Ke, o), h(this, Xe, i);
  }
  /** Resolves Caido request IDs then dispatches - the row-selection entry point. */
  async dispatchIds(e, s, n) {
    return m(this, $, Et).call(this, n) ? m(this, $, Tt).call(this, e, await _r(a(this, Ve), s), n) : 0;
  }
  /**
   * Dispatches requests carried as raw text - the request/response editor entry
   * point, where the message may be an unsaved draft with no id.
   */
  async dispatchRaw(e, s, n) {
    if (!m(this, $, Et).call(this, n)) return 0;
    const r = s.filter((o) => o.request.length > 0).map((o) => ({
      url: o.url,
      requestBytes: Mt(o.request),
      responseBytes: o.response ? Mt(o.response) : null
    }));
    return m(this, $, Tt).call(this, e, r, n);
  }
}
Ve = new WeakMap(), W = new WeakMap(), D = new WeakMap(), Ye = new WeakMap(), Ke = new WeakMap(), Xe = new WeakMap(), $ = new WeakSet(), Et = function(e) {
  return a(this, W).isConfigured() ? !0 : (a(this, D).error(`[${e}] Skipped: Vigolium server URL is not configured`), !1);
}, Tt = async function(e, s, n) {
  var c, l, d, f;
  if (s.length === 0)
    return a(this, D).warn(`[${n}] Nothing to send: no request bytes available`), 0;
  const r = m(this, $, Rs).call(this, e), o = `[${n}:${r.label}]`;
  (c = r.counters) == null || c.incrementPending(s.length);
  let i = 0;
  for (const g of s) {
    if (m(this, $, As).call(this, g, o)) {
      (l = r.counters) == null || l.markFailed();
      continue;
    }
    try {
      const w = await r.send(g);
      (d = r.counters) == null || d.markSent(), i++, w && a(this, D).info(`${o} ${w}`);
    } catch (w) {
      (f = r.counters) == null || f.markFailed();
      const S = r.describeError(w);
      a(this, D)[S.level](`${o} ${S.message}`);
    }
  }
  return a(this, D).info(`${o} Sent ${i}/${s.length} requests`), i;
}, Rs = function(e) {
  switch (e) {
    case "ingest":
      return {
        label: "Ingest",
        counters: a(this, Ke),
        send: async (s) => {
          await a(this, W).ingest({
            input_mode: "burp_base64",
            url: s.url,
            http_request_base64: O(s.requestBytes),
            http_response_base64: s.responseBytes ? O(s.responseBytes) : null
          });
        },
        describeError: (s) => ({
          level: "error",
          message: `Failed to send request: ${B(s)}`
        })
      };
    case "scan": {
      const s = a(this, Ye).get(), n = St(s.customModules), r = St(s.scanTimeout);
      return {
        label: "Scan",
        counters: a(this, Xe),
        send: async (o) => {
          const i = await a(this, W).scan({
            url: o.url,
            http_request_base64: O(o.requestBytes),
            http_response_base64: o.responseBytes ? O(o.responseBytes) : null,
            modules: n,
            timeout: r
          });
          return `${i.message} (scan_id: ${i.scanId})`;
        },
        describeError: (o) => o instanceof te && o.statusCode === 409 ? { level: "warn", message: "A scan is already running" } : { level: "error", message: `Scan failed: ${B(o)}` }
      };
    }
    case "agentScan":
      return {
        label: "AgentScan",
        counters: void 0,
        send: async (s) => `Started: ${await a(this, W).agentScan({
          url: s.url,
          http_request_base64: O(s.requestBytes),
          http_response_base64: s.responseBytes ? O(s.responseBytes) : null,
          save_findings: !0,
          mode: "balanced"
        })}`,
        describeError: (s) => ({
          level: "error",
          message: `Agent scan failed: ${B(s)}`
        })
      };
  }
}, /**
 * Reports an over-limit record instead of letting the server answer 413.
 *
 * The raw status code says nothing about which record was at fault or by how
 * much, which makes a partial batch failure very hard to act on.
 */
As = function(e, s) {
  var r;
  const n = e.requestBytes.length + (((r = e.responseBytes) == null ? void 0 : r.length) ?? 0);
  return n <= wt ? !1 : (a(this, D).warn(
    `${s} Skipped ${e.url}: ${Ut(n)} exceeds the ${Ut(wt)} the server accepts once base64-encoded`
  ), !0);
};
let bt;
function y() {
  if (!bt) throw new Error("Vigolium backend is not initialised");
  return bt;
}
async function Sr() {
  return y().settings.get();
}
async function Er(t, e) {
  return y().settings.update(e);
}
async function Tr() {
  try {
    return { ok: !0, health: await y().api.health() };
  } catch (t) {
    return { ok: !1, message: B(t) };
  }
}
async function br() {
  return y().bridge.testConnection();
}
async function Rr() {
  const { bridge: t } = y();
  return await t.restart(), t.status();
}
async function Ar() {
  return y().bridge.status();
}
async function Br() {
  return y().snapshot.status();
}
async function Or(t, e) {
  return y().snapshot.snapshotNow(e || "Manual");
}
async function Cr() {
  const { snapshot: t } = y();
  return t.reschedule(), t.status();
}
async function Bs() {
  const { ingestCounters: t, scanCounters: e } = y();
  return { ingest: t.snapshot(), scan: e.snapshot() };
}
async function Ir() {
  const { ingestCounters: t, scanCounters: e } = y();
  return t.reset(), e.reset(), Bs();
}
async function vr() {
  return y().log.entries();
}
async function $r() {
  y().log.clear();
}
async function qr(t, e, s, n) {
  return y().dispatch.dispatchIds(e, s, n);
}
async function Lr(t, e, s, n) {
  return y().dispatch.dispatchRaw(e, s, n);
}
async function Mr(t, e) {
  return y().api.findings(e);
}
async function Nr(t, e) {
  return y().api.findingById(e);
}
async function Ur(t, e) {
  return y().api.deleteFinding(e);
}
async function kr(t, e) {
  return y().api.httpRecords(e);
}
async function Pr(t, e) {
  return y().api.httpRecordByUuid(e);
}
async function xr(t, e) {
  return y().api.deleteHttpRecord(e);
}
async function Hr(t, e) {
  const { api: s, settings: n } = y();
  return s.scanRecords([e], n.moduleList());
}
async function Dr(t, e, s) {
  return y().api.scanAllRecords(_s(e), St(s));
}
async function Fr(t, e, s) {
  return y().api.scans(e, s);
}
async function Gr(t, e, s, n, r, o) {
  return y().api.scanLogs(e, s || void 0, n || void 0, r, o);
}
async function Vr(t, e) {
  return y().api.pauseScan(e);
}
async function Yr(t, e) {
  return y().api.resumeScan(e);
}
async function Kr(t, e) {
  return y().api.stopScan(e);
}
async function Xr(t, e) {
  return y().api.deleteScan(e);
}
async function zr(t, e, s, n) {
  return y().api.agentSessions(e || void 0, s, n);
}
async function Qr(t, e) {
  return y().api.agentSessionLogs(e);
}
async function Jr(t, e) {
  const { api: s, log: n } = y(), r = await s.httpRecordByUuid(e);
  if (!r.rawRequestBase64)
    throw new te(0, "Record has no raw request to replay");
  const o = await rt(
    t,
    {
      url: r.url,
      requestBytes: _t(r.rawRequestBase64),
      responseBytes: r.rawResponseBase64 ? _t(r.rawResponseBase64) : null,
      roundtripTimeMs: r.responseTimeMs
    },
    `vigolium-${r.uuid.slice(0, 8)}`
  );
  return n.info(`[HTTP Records] Opened Replay session for ${r.url}`), o;
}
async function Wr(t, e, s, n, r) {
  const { log: o } = y(), i = Nt(s);
  if (i.length === 0)
    throw new te(0, "There is no request to replay");
  const c = Js(i, e), l = n ? Nt(n) : null, d = await rt(
    t,
    {
      url: c,
      requestBytes: i,
      responseBytes: l && l.length > 0 ? l : null
    },
    r || "vigolium"
  );
  return o.info(`[Findings] Opened Replay session for ${c}`), d;
}
const Zr = {
  getSettings: Sr,
  updateSettings: Er,
  testServerConnection: Tr,
  testBridgeConnection: br,
  restartBridge: Rr,
  getBridgeStatus: Ar,
  getSnapshotStatus: Br,
  snapshotNow: Or,
  rescheduleSnapshot: Cr,
  getRequestStats: Bs,
  resetRequestStats: Ir,
  getLogs: vr,
  clearLogs: $r,
  dispatch: qr,
  dispatchRaw: Lr,
  findings: Mr,
  findingById: Nr,
  deleteFinding: Ur,
  httpRecords: kr,
  httpRecordByUuid: Pr,
  deleteHttpRecord: xr,
  scanRecord: Hr,
  scanAllRecords: Dr,
  scans: Fr,
  scanLogs: Gr,
  pauseScan: Vr,
  resumeScan: Yr,
  stopScan: Kr,
  deleteScan: Xr,
  agentSessions: zr,
  agentSessionLogs: Qr,
  sendRecordToReplay: Jr,
  sendRawToReplay: Wr
};
async function oo(t) {
  const e = new nr(t);
  await e.init();
  const s = new zn(t), n = new pr(() => {
    const T = e.get();
    return { serverUrl: T.serverUrl, apiKey: T.apiKey };
  }), r = new Gt(), o = new Gt(), i = () => ot(t, Fs, {
    ingest: r.snapshot(),
    scan: o.snapshot()
  });
  r.setOnChange(i), o.setOnChange(i);
  const c = new Xn(t, e, s), l = new cr(t, e, n, s), d = new wr(
    t,
    n,
    s,
    e,
    r,
    o
  ), f = new jn(n, s, e, r);
  bt = {
    settings: e,
    log: s,
    api: n,
    bridge: c,
    snapshot: l,
    dispatch: d,
    ingestCounters: r,
    scanCounters: o
  };
  for (const [T, A] of Object.entries(Zr))
    t.api.register(T, A);
  t.events.onInterceptResponse(
    (T, A, F) => f.handle(T, A, F)
  ), t.events.onProjectChange((T, A) => {
    c.onProjectChange(A ? { id: A.getId(), name: A.getName() } : null);
  });
  let g = jt(e.get()), w = es(e.get());
  e.onChange((T) => {
    const A = jt(T);
    A !== g && (g = A, c.restart());
    const F = es(T);
    F !== w && (w = F, l.reschedule());
  });
  const [S] = await Promise.all([t.projects.getCurrent(), c.restart()]);
  c.onProjectChange(S ? { id: S.getId(), name: S.getName() } : null), l.start(), s.info(`Plugin v${t.meta.version()} loaded successfully.`);
}
function jt(t) {
  return `${t.bridgeEnabled}|${t.bridgeListenUrl}`;
}
function es(t) {
  return `${t.snapshotAutoEnabled}|${t.snapshotIntervalMinutes}`;
}
export {
  oo as init
};
